# DELTA-144: Flow → load test

Session Tier 2 · Day 27 · M17 · 2026-09-30

## Summary
**One click from a functional run to a load run.** In the Trace Viewer, **⚡ Load test this flow** does three things:
1. Posts the trace's `network.har` to `/import?type=flow&save=true`.
2. Saves `<script>-load.xml` in the test directory.
3. Switches to Execute with that file selected, and starts it as an API run.

In the generated file, each flow step is a case named `METHOD /path` (the HAR import's naming) with a `perfConfig` (vegeta, 10 users, 30 s by default), so the run load-tests every step through the Δ140 perf-engine SPI. For vegeta with no rate, the case also carries `extras closed=1`, so "10 users" really means 10 concurrent workers (`-rate=0 -max-workers=10`) rather than vegeta's default 50 req/s. A side file `<script>-load.targets.jsonl` holds the whole flow as vegeta JSON targets, for a single mixed attack. The import also returns the `loadConfig` keys for a concurrent-users run of the flow.

The HAR importer's filtering is reused unchanged: documents/XHR/fetch only; static assets, preflights, `sec-*` headers and cookies dropped; 304 treated as 200.

## Changes
| Path | A/M | Note |
|---|---|---|
| `alldep-jar/src/main/java/com/gatf/imports/FlowToLoad.java` | A | Pure converter: `HarImporter` → `Importers.toTestCases`, then a `perfConfig` per case, the vegeta JSON targets (headers kept, body base64; multipart and relative URLs skipped with a note), `loadConfig`, and stats including a ready `vegetaCommand`. `Options` covers users, duration, rate and engine (vegeta, autocannon, wrk, wrk2, wperfk), validated. |
| `alldep-jar/src/main/java/com/gatf/executor/ext/VegetaRunner.java`, `VegetaTestCaseExecutor.java` | M | Opt-in `perfConfig.extras` `closed=1` (with no rate): native vegeta runs a closed loop of `connections` workers. Existing perf configs run unchanged. |
| `alldep-jar/src/main/java/com/gatf/imports/ImportResult.java` | M | `sideFiles` (suffix → content) and `sideFileName(testFile, suffix)`, for files saved beside the test file. |
| `alldep-jar/src/main/java/com/gatf/imports/Importers.java` | M | Type `flow` added to `TYPES` and the switch, with default options. |
| `alldep-jar/src/main/java/com/gatf/ui/GatfImportHandler.java` | M | `type=flow` takes `users`, `duration`, `rate` and `engine` (bad values give 400). The response lists `sideFiles`, and `save=true` writes them beside the `.xml`. A saved flow never overwrites: it goes to `x-load-2.xml` and so on, unless `overwrite=true`. A malformed source gets 400 instead of 500. |
| `alldep-jar/src/main/java/com/gatf/generator/core/ImportCli.java` | M | `gatf import flow <har> [--users] [--duration] [--rate] [--engine]`. Side files are written beside `-o`, and `--force` applies to them too. |
| `alldep-jar/src/test/java/com/gatf/imports/FlowToLoadTest.java` | A | 4 tests on the `recording.har` fixture, including `closed=1` and free names. |
| `alldep-jar/src/test/java/com/gatf/executor/ext/VegetaClosedLoopTest.java` | A | 2 tests: when the closed loop applies, and the resulting `-rate 0 -max-workers N` argv. |
| `frontend/src/api.ts` | M | `ImportType` gains `'flow'`; adds `api.flowToLoad(har, fileName, opts)` and `flowLoadFileName(selFile, runId)`. |
| `frontend/src/App.tsx`, `components/Header.tsx` | M | The ⚡ button, shown only when the trace has network entries, with busy and error text. |
| `frontend/src/Shell.tsx` | M | `pendingRun` hands the saved file to Execute. |
| `frontend/src/views/ExecuteView.tsx` | M | `autoRun` prop: once the file list loads, it selects the file (an exact path match first) and sets the mode, then starts on the next render. If the file is missing it says so. |
| `frontend/src/views/ImportView.tsx` | M | A "Flow → load" type, with the URL filter. |
| `frontend/src/views/flowToLoad.test.tsx` | A | 5 tests: naming, request shape, server refusal, the header button, and Execute auto-starting an API run. |
| `README.md` | M | A Flow → load bullet and the import row. |

## Deleted
None.

## How to apply
```
unzip -oq gatf-delta-144-flow-to-load.zip && git add -A && git commit -m "Δ144 M17: flow → load test"
mvn -B -q compile
```

## Verification
- **Blind verifier: PASS-WITH-FIXES.** It found 1 MAJOR and 4 MINOR issues:
  - **MAJOR:** native vegeta ignored `connections` as concurrency, so the default was vegeta's 50 req/s rather than "10 users". Fixed with the opt-in `closed=1`.
  - **MINOR, fixed:** a second click overwrote a tuned load test (free names now); auto-run could pick `sub/x-load.xml` over `x-load.xml` (exact match first); a malformed HAR returned 500 (now 400).
  - **MINOR, accepted:** a repeated HAR header keeps only its last value. That is the reused HAR rule; see Gaps.
- **R2 (Java).** `VegetaClosedLoopTest` ran 2/2 against the real `VegetaRunner` (with a stub `PerfToolProvisioner.exec`). These compiled with `-Xlint:all` (0 warnings) and `FlowToLoadTest` ran **4/4** under the JUnit 5 shim, on the real `recording.har` fixture:
  - the real `FlowToLoad`, `HarImporter`, `ApiRequest`, `ImportResult` and `PerformanceConfig`;
  - `Importers.toTestCases`, `safeName` and `TYPES`, **extracted verbatim** from the shipped `Importers.java` by script (R3);
  - a `TestCase` stub bean with the used accessors, and a stub `@JacksonXmlRootElement`.

  The tests confirm:
  - six steps named like the HAR import, each with `perfConfig` vegeta, 25 users, 60 s;
  - cookies dropped, and 5 vegeta targets with the multipart upload reported;
  - base64 bodies, the full URL with query, and a ready vegeta command;
  - filter, rate and engine options, rejection of bad options, and "nothing to load-test" when nothing matches.
- **Frontend.** `npx tsc -b --noEmit` is clean. `npx vitest run`: **122/122** (117 before plus 5 new).
- **R4.** `Importers`, `GatfImportHandler`, `ImportCli` and `VegetaTestCaseExecutor` pass `JavacTask.parse()` with 0 errors.
- **Not run:**
  - `mvn`;
  - the real `Importers` switch, handler and CLI paths (parse-checked only);
  - XML round-trip of `perfConfig` through `XOM` (jackson-dataformat-xml isn't in the container; `perfConfig` is an existing `TestCase` field);
  - a live click from a real trace to a real vegeta run. To check: run a UI script with trace on, open its trace, click ⚡, and Execute should start `…-load.xml`. vegeta must be installed (`gatf tools install vegeta`).

## Gaps
- **Cookies are dropped** (the HAR importer's rule, which the card asked to reuse). Steps that need a session need a login case plus captured tokens, or `browserApiSession`.
- **Budgets aren't per request.** `perfBudgets` are page metrics (LCP, requests, transfer…), so there is no per-request budget to pair with. The load cases share the HAR import's `METHOD /path` naming instead.
- **The button uses the defaults** (10 users, 30 s). Tune them in the saved `.xml`, or use the Import view or the CLI flags.
- **Repeated headers:** a HAR header that repeats (e.g. two `X-M` values) keeps only its last value. That is the HAR importer's rule, reused here.
- **Per-step load only.** The API run load-tests each step on its own. The whole-flow attack is the vegeta targets file, or `loadConfig` in gatf-config for a concurrent-users replay.

## Next
Δ145: Tier 2 close-out.
