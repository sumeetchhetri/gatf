# DELTA-145a: fix the gatfjdb breakpoint race (Tier 2 audit)

Session Tier 2 audit fix · 2026-09-30 · reported by Sumeet's `mvn -B clean verify`

## Summary
`GatfSelDebuggerIT.breakpointsStepContinueAndTeardown:70` failed: `unsetBreakPoint(6)` returned false.

Cause: a race in `GatfSelDebugger`, in delta-075-era code that Δ141–Δ145 did not touch. The event thread handles ClassPrepare in two steps: `cpe = event`, then `applyPendingBreakpoints()`. An `unsetBreakPoint` that landed between them saw `cpe != null`, found no request yet and returned false. The pending apply then installed the breakpoint the user had just removed. Whether it fails depends on timing.

Fix: user breakpoint set/unset and the ClassPrepare hand-off (`cpe` + `applyPendingBreakpoints()` + the initial temp breakpoint) now run under one lock (`bpLock`), and `cpe` is `volatile`.

## Changes
| Path | A/M | Note |
|---|---|---|
| `alldep-jar/src/main/java/com/gatf/selenium/gatfjdb/GatfSelDebugger.java` | M | `bpLock`; `setBreakPoint`/`unsetBreakPoint` are synchronized wrappers around the old bodies; ClassPrepare block under the same lock; `volatile cpe` |

## How to apply
```
unzip -oq gatf-delta-145a-gatfjdb-race.zip && git add -A && git commit -m "Δ145a gatfjdb: breakpoint set/unset atomic vs ClassPrepare"
mvn -B clean verify
```

## Verification
- **Reproduced, R2:** the real `GatfSelDebugger`, `GatfJdiLauncher` and `DebuggerSupport` ran over real JDI against the real `DebuggeeToy`. Stubbed: log4j, `SeleniumTest`, `Command`.
- **Test:** set(6)/unset(6) hammered across the ClassPrepare hand-off, 40 runs.
  - Old code: `unsetBreakPoint` returned false **9 times**.
  - New code: **0 times**.
- **Regression:** the IT's whole sequence ran 15/15 on the new code with no deadlock. The sequence is set/unset before prepare → initial pause → set/unset/set → step over → continue to breakpoint 5 → run to end → idle reaper.
- **R4:** `JavacTask.parse()` on the edited file gives 0 errors.
- **Not run:** mvn and failsafe.
