# Paste-ready prompts (developer account, Claude Code)

## 1. Builder session (one per card)
Set the model per `TIER3-CARDS.md` (`/model opus` or `/model sonnet`). Attach the latest `gatf-src-*.zip` and any newer deltas, then paste:

```
go <NNN>
Repo: <path>. CLAUDE.md at the root has the rules; TIER3-CARDS.md has the card.
Pending deltas to apply on top of the source zip, in order: <list or "none">.
Compile error from the last merge (fix first, as a suffixed delta): <paste or "none">.
Follow the session procedure in CLAUDE.md end to end. The blind Opus verifier is mandatory.
Deliver gatf-delta-<NNN>-<slug>.zip, gatf-<NNN>.sha256 and DELTA-<NNN>.md to <outdir>.
```

## 2. Blind verifier (the builder spawns it as a fresh Opus subagent)
```
You are a blind verifier for GATF at <repo>. Review ONLY commit <sha> (diff <base>..<sha>). Do not modify the repo; use a scratch dir.
Card Δ<NNN> <title>. Scope: <…>. Accept: <…>. Verify: <…>.
The delta's claims are in docs/deltas/DELTA-<NNN>.md: check them, don't trust them.
Check:
(1) correctness and edge cases in every changed file;
(2) the accept line is plausibly met, and what's missing;
(3) Apache-2.0 headers on new source files; CRLF preserved (diff stats small, `file`);
(4) no secret or key reaches reports/traces/logs;
(5) existing behaviour unchanged unless the card asks for it;
(6) run the tests yourself and add adversarial cases.
Report: PASS / PASS-WITH-FIXES / FAIL, findings tagged BLOCKER/MAJOR/MINOR with file:line and a concrete fix. Under 700 words; verified issues only.
```

## 3. Explore agent (Sonnet)
```
Map touchpoints for card Δ<NNN> (<title>) in <repo>: the files, line numbers, signatures and short excerpts for <list from TIER3-CARDS.md>,
which of them are CRLF (`file`), existing tests to copy conventions from, and how the feature would be invoked end to end.
Facts only, under 1000 words.
```
