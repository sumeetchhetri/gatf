# GATF Tier 3 handoff pack

## Upload to the developer account
1. **This pack.**
2. **`gatf-src-<date>.zip`:** Sumeet builds it with `tools/package-source.sh` **after merging Δ141–Δ145a** and a green Tier 2 audit.
3. **`GATF_REVIEW_AND_ROADMAP.md`:** git-ignored, so it isn't in the source zip. It has §7.3 background for the H-items. Recommended.

Nothing else is needed: no board, project memory or orchestrator access.

## Setup (once)
- Unzip the source into a repo and `git init && git add -A && git commit -m base`.
- Copy `CLAUDE.md` to the repo root and add it to `.git/info/exclude`.
- Keep `TIER3-CARDS.md`, `PROMPTS.md`, `devkit/` and `examples/` beside the repo, not inside it.

## Per card
1. Open a session with the card's model (`TIER3-CARDS.md`) and paste prompt 1 from `PROMPTS.md`.
2. The session runs: explore → build → test → blind Opus verifier → fix → `eol.sh` → `chaincheck.sh` → `pack.sh`.
3. Hand Sumeet the three files: zip, sha256, DELTA md.

## Gate (Sumeet's side)
Upload the three files to the orchestrator session and say `review <NNN>`. The orchestrator then:
- re-runs a blind review against the card's accept line;
- runs the chain check;
- updates the board;
- returns **merge** or **fix list**.

On merge, run `mvn -B -q compile`. A failure goes back to the developer as a suffixed delta (`Δ<NNN>a`).

Audits run after Δ154 and Δ163.

## devkit/
| File | Use |
|---|---|
| `ParseCheck.java` | `javac ParseCheck.java && java ParseCheck <files…>`: a `JavacTask.parse()` check, 0 errors expected |
| `junit5-shim/` + `run-shim-tests.sh` | Run JUnit 5 tests (Assertions/Test/TempDir only) without Maven |
| `eol.sh <repo> <base>` | CRLF/LF preserved on every changed file |
| `pack.sh <repo> <NNN> <slug> <out>` | zip + sha256 + DELTA md from the last commit |
| `chaincheck.sh <src.zip> <repo> <deltas…>` | snapshot + deltas == working tree |
