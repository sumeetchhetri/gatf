#!/usr/bin/env bash
# usage: devkit/eol.sh <repo> <base-commit>
# Every file changed since <base-commit> must keep its CRLF/LF style. Python text-mode writes silently turn CRLF into LF.
cd "$1" || exit 2; B=$2; bad=0
for f in $(git diff --name-only "$B" -- . ; git ls-files -o --exclude-standard); do
  [ -f "$f" ] || continue
  if git cat-file -e "$B:$f" 2>/dev/null; then
    was=$(git show "$B:$f" | grep -c $'\r$'); now=$(grep -c $'\r$' "$f"); tot=$(wc -l < "$f")
    if [ "$was" -gt 0 ] && [ "$now" -lt "$tot" ]; then echo "CRLF LOST: $f ($now/$tot)"; bad=1; fi
    if [ "$was" -eq 0 ] && [ "$now" -gt 0 ]; then echo "CRLF ADDED: $f"; bad=1; fi
  fi
done
[ $bad = 0 ] && echo "eol ok"; exit $bad
