#!/usr/bin/env bash
# usage: devkit/chaincheck.sh <gatf-src-*.zip> <repo> <delta.zip>...   (deltas in apply order)
# snapshot + deltas must equal the working tree.
set -e; SNAP=$1; R=$2; shift 2; T=$(mktemp -d); cd "$T"; unzip -q "$SNAP"
for z in "$@"; do unzip -oq "$z" -d "$T"; done
diff -rq --exclude=.git --exclude=node_modules --exclude=target --exclude=logs "$T" "$R" && echo "CHAIN OK"
