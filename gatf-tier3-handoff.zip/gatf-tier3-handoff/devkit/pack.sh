#!/usr/bin/env bash
# usage: devkit/pack.sh <repo> <NNN> <slug> <outdir>
# Packs the last commit (HEAD~1..HEAD) as gatf-delta-NNN-<slug>.zip + gatf-NNN.sha256 + DELTA-NNN.md.
# docs/deltas/ is git-ignored, so commit DELTA-NNN.md with `git add -f`.
set -e; R=$1; N=$2; SLUG=$3; OUT=$4; mkdir -p "$OUT"; cd "$R"
Z="$OUT/gatf-delta-$N-$SLUG.zip"; rm -f "$Z"
[ -f "docs/deltas/DELTA-$N.md" ] || { echo "missing docs/deltas/DELTA-$N.md"; exit 1; }
FILES=$(git diff --name-only --diff-filter=AMR HEAD~1 HEAD)
DEL=$(git diff --name-only --diff-filter=D HEAD~1 HEAD)
[ -n "$DEL" ] && echo "DELETED (list them under 'Deleted' in the DELTA md): $DEL"
if echo "$FILES" | grep -qE 'tsbuildinfo|node_modules/|/target/'; then echo "refusing: build output in the delta"; exit 1; fi
zip -q -X "$Z" $FILES "docs/deltas/DELTA-$N.md"
cp "docs/deltas/DELTA-$N.md" "$OUT/"
( cd "$OUT" && sha256sum "gatf-delta-$N-$SLUG.zip" > "gatf-$N.sha256" && cat "gatf-$N.sha256" )
unzip -l "$Z" | tail -1
