#!/usr/bin/env bash
# Fallback when Maven is unavailable: compile pure classes + their JUnit 5 tests against a tiny shim and run them.
# usage: devkit/run-shim-tests.sh "<classpath jars or ''>" "<test class names>" <java files...>
# Tests must use org.junit.jupiter.api.{Test,Assertions} and io.TempDir only (no AssertJ) for this path.
set -e; D=$(cd "$(dirname "$0")" && pwd); CP=$1; TESTS=$2; shift 2; O=$(mktemp -d)
javac -Xlint:all -d "$O" ${CP:+-cp "$CP"} $(find "$D/junit5-shim" -name '*.java') "$@"
java -cp "$O${CP:+:$CP}" Run $TESTS
