import java.lang.reflect.*; import java.nio.file.*;
public class Run { public static void main(String[] a) throws Exception { int ok=0,bad=0;
 for(String cn:a){ Class<?> c=Class.forName(cn); for(Method m:c.getDeclaredMethods()){ if(!m.isAnnotationPresent(org.junit.jupiter.api.Test.class)) continue;
  Constructor<?> k=c.getDeclaredConstructor(); k.setAccessible(true); Object o=k.newInstance(); m.setAccessible(true);
  Object[] args=new Object[m.getParameterCount()]; for(int i=0;i<args.length;i++) args[i]=Files.createTempDirectory("t");
  try{ m.invoke(o,args); ok++; System.out.println("PASS "+c.getSimpleName()+"."+m.getName()); }catch(InvocationTargetException e){ bad++; System.out.println("FAIL "+c.getSimpleName()+"."+m.getName()+": "+e.getCause()); e.getCause().printStackTrace(System.out);} }}
 System.out.println("== "+ok+" passed, "+bad+" failed"); System.exit(bad>0?1:0);}}
