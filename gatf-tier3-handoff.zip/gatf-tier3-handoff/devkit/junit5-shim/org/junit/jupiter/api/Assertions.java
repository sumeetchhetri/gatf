package org.junit.jupiter.api;
import java.util.Objects;
public final class Assertions {
  static void f(String m){ throw new AssertionError(m); }
  public static void assertEquals(Object e, Object a){ if(!Objects.equals(e,a)) f("expected <"+e+"> but was <"+a+">"); }
  public static void assertEquals(Object e, Object a, String m){ if(!Objects.equals(e,a)) f(m+" ==> expected <"+e+"> but was <"+a+">"); }
  public static void assertEquals(long e, long a){ if(e!=a) f("expected <"+e+"> but was <"+a+">"); }
  public static void assertEquals(long e, long a, String m){ if(e!=a) f(m+" ==> expected <"+e+"> but was <"+a+">"); }
  public static void assertEquals(double e, double a, double d){ if(Math.abs(e-a)>d) f("expected <"+e+"> but was <"+a+">"); }
  public static void assertTrue(boolean c){ if(!c) f("expected true"); }
  public static void assertTrue(boolean c, String m){ if(!c) f(m); }
  public static void assertFalse(boolean c){ if(c) f("expected false"); }
  public static void assertFalse(boolean c, String m){ if(c) f(m); }
  public static void assertNull(Object o){ if(o!=null) f("expected null but was <"+o+">"); }
  public static void assertNull(Object o, String m){ if(o!=null) f(m); }
  public static void assertNotNull(Object o){ if(o==null) f("expected not null"); }
  public static void assertNotNull(Object o, String m){ if(o==null) f(m); }
  public static void fail(String m){ f(m); }
  public interface Exec { void run() throws Throwable; }
  public static <T extends Throwable> T assertThrows(Class<T> c, Exec e){ try{ e.run(); }catch(Throwable t){ if(c.isInstance(t)) return c.cast(t); f("expected "+c.getName()+" but got "+t); } f("expected "+c.getName()+" to be thrown"); return null; }
}
