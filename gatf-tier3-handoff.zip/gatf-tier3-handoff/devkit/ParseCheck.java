import javax.tools.*; import com.sun.source.util.JavacTask; import java.util.*;
public class ParseCheck { public static void main(String[] a) throws Exception {
  JavaCompiler c = ToolProvider.getSystemJavaCompiler(); DiagnosticCollector<JavaFileObject> d = new DiagnosticCollector<>();
  StandardJavaFileManager fm = c.getStandardFileManager(d, null, null);
  JavacTask t = (JavacTask) c.getTask(null, fm, d, List.of("-proc:none"), null, fm.getJavaFileObjects(a));
  t.parse(); int e=0; for (Diagnostic<?> x : d.getDiagnostics()) if (x.getKind()==Diagnostic.Kind.ERROR) { e++; System.out.println(x); }
  System.out.println("parsed " + a.length + " files, " + e + " errors"); System.exit(e>0?1:0); } }
