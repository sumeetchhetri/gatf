# GATF Tier 3 cards (Δ146–Δ163)

Build strictly in delta order: one card per session, one delta per card. Each card's *accept* line is what the orchestrator reviews against. **Model** is the builder session's model. The Explore agent can always be Sonnet, and the blind verifier is always a fresh **Opus** agent.

| Δ | Card | Model | Why |
|---|---|---|---|
| 146 | H2 DOM snapshot capture per action | **Opus** | Cross-transport (CDP + BiDi) plus trace format v2 compatibility |
| 147 | H2 Trace Viewer styled time-travel | **Opus** | Rebuilding DOMSnapshot output safely in a sandboxed iframe |
| 148 | H2 Pick locator | Sonnet | Reuses the existing resolver; UI wiring |
| 149 | H1 AI provider SPI + healer core | **Opus** | API design, secret handling, validation against snapshots |
| 150 | H1 Healer in editor + MCP | Sonnet | Follows 149 and the existing MCP tool pattern |
| 151 | H1 Planner | Sonnet | Fake-provider pipeline over an existing crawl map |
| 152 | H1 Generator | Sonnet | Gate + bounded loop; a well-specified loop |
| 153 | H3 Per-test browser contexts | **Opus** | `BrowserControl` / transport core, capability matrix |
| 154 | H3 Workers on contexts | **Opus** | Scheduler + fallback in the executor's concurrency code |
| 155 | H6 Coverage merge + untested map | Sonnet | Data merge + report page |
| 156 | H6 Test-impact selection | **Opus** | Source maps + coverage index correctness |
| 157 | H5 Device-cloud presets | Sonnet | Capability builders, env credentials |
| 158 | H5 Appium 2 behind touch commands | **Opus** | Driver acquisition core in `SeleniumTest`; regression risk |
| 159 | H4 WebKit / Safari in CI | Sonnet | CI YAML + an honest parity note |
| 160 | H7 Export → Playwright TS | **Opus** | Maps seleasy semantics broadly; sets the pattern 161 copies |
| 161 | H7 Export → Selenium Java | Sonnet | Same pattern as 160 |
| 162 | H8 Distributed functional traces | Sonnet | Follows the existing distributed transport |
| 163 | Tier 3 close-out | **Orchestrator** (Sumeet's account) | Audit, re-score, release notes; must be independent of the builders |

Split: **8 Opus builders, 9 Sonnet builders, 1 orchestrator card.** An Opus verifier runs on all 17.

---

## H2: DOM time-travel (Δ146–Δ148)

### Δ146: DOM snapshot capture per action
- **Scope:**
  - CDP `DOMSnapshot.captureSnapshot` before/after each action.
  - BiDi fallback: serialized DOM + stylesheets by script.
  - Resources go into `ResourceStore` (sha1 dedup).
  - Trace format v2; lite snapshots stay readable.
- **Accept:** the snapshot bundle carries styles and resources.
- **Verify:** R1 snapshot serializer · R2 fake transport.
- **Touchpoints:**
  - Trace classes: `selenium/trace/{SnapshotRecorder,ResourceStore,BrowserControl,CdpTransport,BiDiTransport,Capability,TraceRecorder,Transports}.java`.
  - Per-action events: `SeleniumTest` action sinks (`__traceAction__`).
  - Viewer parsing: `frontend/src/trace/{loadTrace.ts,types.ts}`.
- **Pitfalls:**
  - Capture must never break or noticeably slow a run (cap the size, catch everything).
  - Bump the format version in `metadata.json`, and keep `snapshots.ndjson` + `snapshots/*.html` readable by the current viewer.
  - Before/after pairs are keyed to the action event.

### Δ147: Trace Viewer styled time-travel
- **Scope:** rebuild the snapshot in a **sandboxed iframe** from zip resources; before/after toggle; target highlight.
- **Accept:** a snapshot renders styled, not as lite outerHTML.
- **Verify:** tsc + vitest on a fixture bundle.
- **Touchpoints:** `frontend/src/components/Stage.tsx`, `trace/loadTrace.ts`, `EventsTab.tsx`; resources via the zip `files` map (object URLs).
- **Pitfalls:**
  - `sandbox` with no `allow-scripts`; strip scripts and event handlers.
  - Rewrite resource URLs to blob URLs.
  - Lite snapshots from old traces still render.

### Δ148: Pick locator
- **Scope:**
  - Hover a snapshot to get a ranked semantic locator via the existing resolver.
  - The same picker against the live browser from the editor.
- **Accept:** the picked locator pastes into the editor and resolves strictly.
- **Verify:** vitest · resolver reuse.
- **Touchpoints:**
  - Resolver and ranking: `selenium/SemanticLocators.java` (the injected resolver JS) and `selenium/LocatorRanking.java` (testid → role → label → css).
  - Editor: `frontend/src/components/SelCodeMirror.tsx`.
  - Recorder: `record/RecordSession.java` (live browser).

## H1: AI agents, opt-in and provider-pluggable (Δ149–Δ152)

### Δ149: AI provider SPI + healer core
- **Scope:**
  - Opt-in `ai` config: provider (anthropic / openai / local); key from env, **never** written to reports.
  - Healer: failed step + trace + snapshot → ranked locator/wait candidates, validated against the snapshot.
  - Deterministic candidates first, LLM second.
- **Accept:** the healer proposes a working locator for a recorded failure.
- **Verify:** R1 with a fake provider.
- **Touchpoints:**
  - Prior art for plugin discovery: `com.gatf.selenium.plugins.sdk.*` (ServiceLoader SPI pattern), `executor/perf/PerfEngineRegistry`.
  - Inputs: `mcp/TraceSummary.java` (failure context), Δ146 snapshots, `SemanticLocators`/`LocatorRanking`.
  - Config: `GatfExecutorConfig` (CRLF).
- **Pitfalls:**
  - The provider SPI is a plain interface + ServiceLoader.
  - HTTP via `java.net.http.HttpClient` (no SDK dependency).
  - Model name and endpoint come from config.
  - Add a test that greps reports/traces for the key.

### Δ150: Healer in editor + MCP
- **Scope:** the patch shows as an editor diff (accept/reject, never auto-commit); an MCP `heal` tool.
- **Accept:** the healer fixes a broken locator from a real trace.
- **Verify:** vitest · R1 MCP handler.
- **Touchpoints:**
  - `mcp/{McpServer,McpTool,GatfMcpTools}.java`: register like the existing tools, which take `McpTool.schema` triples and throw `ToolError` for bad input.
  - `frontend/src/views/TestFilesView.tsx`, `SelCodeMirror.tsx`.

### Δ151: Planner
- **Scope:** crawler map + LLM → test plan (md + json).
- **Accept:** the plan covers every crawled route.
- **Verify:** R1 with a fake provider on a canned crawl.
- **Touchpoints:** `crawler/{SpaCrawler,PortalCrawler,CrawlSession}.java` (`coveragePlan`), the `-coverage.json` written by crawl save.

### Δ152: Generator
- **Scope:** plan → seleasy, gated by `validateSel` + a dry run; bounded repair loop.
- **Accept:** the generated suite lints clean and dry-runs.
- **Verify:** R1 gate + loop with a fake provider.
- **Touchpoints:** `Command.validateSel` (returns a JSON string; it prints to `System.out`), `mcp/GatfMcpTools.lint`.
- **Pitfalls:** hard cap on iterations and tokens; the loop stops on repeated identical errors.

## H3: browser contexts (Δ153–Δ154)

### Δ153: Per-test browser contexts
- **Scope:** BiDi `browser.createUserContext` + CDP `Target.createBrowserContext` behind `BrowserControl`; capability matrix.
- **Accept:** fresh cookies/storage per test without a new browser.
- **Verify:** R2 fake transports.
- **Touchpoints:** `trace/{BrowserControl,CdpTransport,BiDiTransport,Capability,Transports}.java`, `selenium/StorageState.java`, `docs/browser-modes.md` (capability matrix).

### Δ154: Workers on contexts
- **Scope:** workers reuse one browser with a context per test, falling back to a browser per worker; measure the launch-cost savings.
- **Accept:** per-test isolation at a fraction of the launch cost.
- **Verify:** R1 scheduler · timing on Sumeet's side.
- **Touchpoints:**
  - UI dispatch and worker pool in `executor/core/GatfTestCaseExecutorUtil.java` (CRLF); `executor/core/ShardSplitter.java`, `RunOverrides`.
  - `log/RunConsole.java` must stay line-atomic.
- **After Δ154, Sumeet and the orchestrator run the mid-tier audit.**

## H6: coverage insight (Δ155–Δ156)

### Δ155: Coverage merge + untested map
- **Scope:** merge per-test JS/CSS coverage with crawler routes; a report page of untested routes/components.
- **Accept:** the report lists untested routes.
- **Verify:** R1 merge · vitest.
- **Touchpoints:**
  - `trace/CoverageRecorder.java` (raw CDP → `coverage.json`), `frontend/src/components/CoverageTab.tsx`.
  - Crawler `-coverage.json`.
  - Reports listing: `ui/GatfApiHandler.java` (`/api/reports`).

### Δ156: Test-impact selection
- **Scope:** `gatf test --changed <git-range>` via source maps + a per-test coverage index.
- **Accept:** a changed file runs only the affected tests.
- **Verify:** R1 index + selector on fixtures.
- **Touchpoints:** `generator/core/{TestCommandArgs,GatfCli}.java` (GatfCli is CRLF), `executor/core/TestFilter.java`.
- **Pitfalls:** an unknown or unmapped change → run everything, and say so.

## H5: devices and clouds (Δ157–Δ158)

### Δ157: Device-cloud presets
- **Scope:** BrowserStack / Sauce / LambdaTest capability presets, credentials from env; a status callback to the cloud dashboard.
- **Accept:** the same `.sel` runs on a cloud browser.
- **Verify:** R1 preset builder · one live cloud run on Sumeet's side.
- **Touchpoints:** the Grid branch in `SeleniumTest.addWdm` (`SELENIUM_REMOTE_URL`), `selenium/emulation/{Devices,Emulation}.java`.

### Δ158: Appium 2 behind touch commands
- **Scope:** the existing touch commands drive Appium 2 (UiAutomator2 / XCUITest).
- **Accept:** the same `.sel` runs on a cloud device.
- **Verify:** R2 proxy driver.
- **Touchpoints:** `selenium/{MTapCommand,MTouchActionCommand}.java`, touch handling in `SeleniumTest`/`Command.java`.
- **Pitfalls:** no regression for desktop runs; Appium is opt-in by capability.

## H4: Δ159 WebKit / Safari in CI
- **Scope:** a macOS safaridriver matrix job; a WebKitGTK / WPE evaluation note; an honest parity statement.
- **Accept:** Safari runs in CI on macOS.
- **Verify:** a CI run on Sumeet's side.
- **Touchpoints:** `.github/workflows/ci-build.yml`, `docs/browser-modes.md`.

## H7: export (Δ160–Δ161)

### Δ160: Export → Playwright TS
- **Scope:** a seleasy → Playwright TS exporter (semantic locators map 1:1); golden tests.
- **Accept:** the exported spec runs green in Playwright.
- **Verify:** R1 exporter + goldens.
- **Touchpoints:**
  - `imports/PlaywrightImporter.java` (the reverse mapping, the best reference).
  - `docs/seleasy/commands.json` + `REFERENCE.md` (the full command set).
  - CLI: `gatf export playwright <sel>`, beside `ImportCli`.
- **Pitfalls:** unsupported constructs are listed, never silently dropped (same rule as the importers).

### Δ161: Export → Selenium Java
- **Scope:** seleasy → Selenium Java (JUnit 5).
- **Accept:** the exported class compiles and runs.
- **Verify:** R1 exporter + javac of the output.

## H8: Δ162 Distributed functional traces
- **Scope:** write on the worker + a reference; merged links across workers.
- **Accept:** a distributed run links every trace.
- **Verify:** R1 reference/merge.
- **Touchpoints:**
  - `executor/distributed/{DistributedGatfListener,DistributedGatfTester}.java` (JSON transport, TLS + shared secret, protocol version stamp).
  - Trace zip naming in `GatfTestCaseExecutorUtil` (~line 1320); `log/ReportMerger.java`.

## Δ163: Tier 3 close-out (orchestrator)
- **Scope:** re-score the scorecard, release notes, roadmap status.
- **Accept:** every Tier 3 card is Done on Sumeet's green run.

---

## Carried-open items (fold into the card that touches the area; don't start them separately)
- Δ139: plugin name shadowing a built-in (define the rule first); a jar rebuilt with the same size and mtime is not reloaded.
- Δ140: wperfk is not auto-downloaded.
- Δ141: MCP progress notifications and cancel during `run`; `lint` returns one message, not a diagnostics list. Fits Δ150.
- Δ142: live frames need `traceVideo`; watch focus is off when the user passes `--grep`/`--tag`.
- Δ144: flow load tests drop cookies; `loadConfig` is returned, not applied.
