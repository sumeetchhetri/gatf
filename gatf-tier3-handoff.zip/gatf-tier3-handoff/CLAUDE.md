# GATF Tier 3: working rules for every session and agent

Copy this file to the repo root and add `CLAUDE.md` to `.git/info/exclude`, so it never ships in a delta.

## What GATF is
- GATF is a Java 21 + React test tool: API, UI (the seleasy DSL), load, perf and RPA, delivered as one shaded jar.
- seleasy is **transpiled**. `Command.java` (~9k lines, CRLF) parses `.sel` and emits Java; ECJ compiles that Java to a `SeleniumTest` subclass.
- Traces are streamed by `com.gatf.selenium.trace.*`. Two transports, CDP and BiDi, sit behind `BrowserControl` (decision D-2). Never call a transport directly from feature code; check `Capability` first.
- The React SPA (`frontend/`, Vite + TS + vitest) is the whole UI, served at `/app`.

You are building **Phase 13 Tier 3** (Δ146–Δ163), one card per session, from `TIER3-CARDS.md`. Sumeet's orchestrator session reviews every delta before he merges it.

## Session procedure (follow it in order)
1. **Base.**
   1. Unzip the latest `gatf-src-*.zip`.
   2. Apply any deltas not yet in it, in order, with `unzip -oq <zip> -d <repo>`.
   3. `git init && git add -A && git commit -m base`. Take every diff against that commit.

   If you already keep a repo from earlier sessions, commit the last delta and branch from it.
2. **Read the card** in `TIER3-CARDS.md`: scope, accept, verify, deps, touchpoints.
   - Stop and ask if `go <delta>` names a card whose deps aren't shipped.
   - Stop and ask if the scope is ambiguous enough that a wrong guess means rework.
3. **Map.** Launch one Explore agent (Sonnet) for touchpoints: files, line numbers, signatures, CRLF status (`file`). It reports facts only; don't read 9k-line files yourself.
4. **Build.** Delta-only edits, no rewrites. Put new logic in **pure classes**, with no Selenium or Grizzly types where avoidable, so it can be tested without a browser. Each pure class gets a JUnit 5 test (+ vitest for UI).
5. **Verify** with the highest rung that applies, and record which one in the DELTA md:
   - **R0:** `mvn -B -q -pl alldep-jar -am verify` (or `-DskipFrontend=true` + targeted `-Dtest=`). Use it if Maven works in your environment.
   - **R1:** real compile and run of pure classes, `javac -Xlint:all`. Without Maven, use `devkit/run-shim-tests.sh` (JUnit 5 shim; tests then use `Assertions`, not AssertJ).
   - **R2:** real compile against small stubs (Selenium, log4j, etc.) and fake transports/drivers via `java.lang.reflect.Proxy`.
   - **R3:** extract the changed methods verbatim into a harness.
   - **R4:** `devkit/ParseCheck.java`: `javac ParseCheck.java && java ParseCheck <files>` must report 0 errors for every edited `.java` file.
   - **Frontend:** `npx tsc -b --noEmit && npx vitest run`, green. Delete `frontend/tsconfig*.tsbuildinfo` afterwards.
   - **Injected JS:** run it in `node` with DOM mocks (see `tools/smoke/test-*.mjs`).
6. **Blind verifier: mandatory.** Spawn a fresh **Opus** agent that has not seen your work. Give it:
   - the commit to review;
   - the card's scope/accept/verify lines;
   - an instruction to check the DELTA md claims rather than trust them, run the tests itself, add adversarial cases, and report BLOCKER/MAJOR/MINOR with file:line.

   Fix everything it finds inside the same delta, and record the round in the DELTA md. (In Tier 2 this caught two blockers the author's own tests missed: log4j's `direct=true` console bypassing `System.setOut`, and xmlunit's `XMLAssert extends junit.framework.Assert`.)
7. **Pack.**
   - `devkit/eol.sh <repo> base` must print `eol ok`.
   - Then `devkit/chaincheck.sh <src.zip> <repo> <all deltas since the zip>`.
   - Then `devkit/pack.sh <repo> NNN <slug> <outdir>`.
8. **Return** three files to Sumeet: `gatf-delta-NNN-<slug>.zip`, `gatf-NNN.sha256` and `DELTA-NNN.md`. Nothing else.

## Hard rules
- **Headers.** Source files (java, ts, tsx, js, mjs, css, sh, ps1, py) carry the Apache-2.0 header with **"Copyright 2013-2026, Sumeet Chhetri"**. Copy it from any existing file. md, xml, json, properties, sel, har and config files never carry it.
- **CRLF.** Many files are CRLF: `Command.java`, `FindCommand.java`, `SeleniumTest`-adjacent code, `GatfTestCaseExecutorUtil`, `TestCaseExecutorUtil`, `GatfExecutorConfig`, `GatfCli`, `ReportHandler`, `pom.xml`, `log4j2.properties`, and others. Edit them binary-safe: read bytes, normalise, edit, restore CRLF. Never use Python text mode, `sed -i` on mixed files, or editors that re-encode. Run `eol.sh` before packing.
- **Codegen goldens.** Never edit an existing corpus `.sel` in `alldep-jar/src/test/resources/codegen-corpus/tests/`; add a new numbered file instead. A new `.sel` has no golden until Sumeet runs `mvn verify -Dgatf.golden.update=true`, so say so in the DELTA md. If codegen output changes, update the affected goldens with the same transform and state it.
- **Dependencies.** No new runtime dependency without saying why in the DELTA md. Prefer the JDK, Jackson, and what is already in `pom.xml`.
- **Secrets.** Secrets (H1 AI keys, H5 cloud credentials) come only from env/config. Never write them to reports, traces, logs or the DELTA md, and add a test that checks this.
- **Behaviour.** No behavioural change to existing configs unless the card asks for it. New behaviour is opt-in, or default-on only for new configs.
- **Docs.** README / `docs/seleasy/REFERENCE.md` / `docs/*.md`: one short entry per user-visible feature. No other new docs.
- **Honesty.** The DELTA md states exactly what ran and what didn't. "Not run" is fine; claiming a run that didn't happen is not.

## DELTA-NNN.md format (see examples/)
`# DELTA-NNN: <title>`, then a session line (`Session Tier 3 · Day N · <item> · <date>`), then these sections:
- **Summary**
- **Changes** table: path | A/M/D | note, with CRLF noted where kept.
- **Deleted:** explicit list; a zip can't delete, so give the `rm` lines.
- **How to apply:** `unzip -oq … && git add -A && git commit -m "…"` then `mvn -B -q compile`.
- **Verification:** rung by rung, plus the verifier round.
- **Gaps:** honest.
- **Next.**

## Container limits you may hit
If Maven Central is blocked (403), don't retry: drop to R1–R4. JDK 21, `node`, npm registry and `bash` are normally available. Jackson 2.16 jars are often in `/opt/gradle-*/lib`.

## Merge and audit model
- **Every delta:** Sumeet merges only after the orchestrator review, then runs `mvn -B -q compile`. A compile failure comes back to you as the next session's fix, a suffixed delta (`Δ150a`), so numbering never shifts.
- **Audits after Δ154 and Δ163:** `mvn -B clean verify`, the e2e suite and smoke on Sumeet's side, plus a blind range audit by the orchestrator.
