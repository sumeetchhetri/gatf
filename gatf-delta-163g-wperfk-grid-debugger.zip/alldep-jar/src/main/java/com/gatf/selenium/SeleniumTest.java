/*
    Copyright 2013-2026, Sumeet Chhetri

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/
package com.gatf.selenium;

import java.awt.AWTException;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.security.Security;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.Stack;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Pdf;
import org.openqa.selenium.Point;
import org.openqa.selenium.PrintsPage;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v150.dom.DOM;
import org.openqa.selenium.devtools.v150.dom.model.Node;
import org.openqa.selenium.devtools.v150.dom.model.NodeId;
import org.openqa.selenium.devtools.v150.fetch.Fetch;
import org.openqa.selenium.devtools.v150.fetch.model.HeaderEntry;
import org.openqa.selenium.devtools.v150.fetch.model.RequestPattern;
import org.openqa.selenium.devtools.v150.fetch.model.RequestStage;
import org.openqa.selenium.devtools.v150.log.Log;
import org.openqa.selenium.devtools.v150.network.Network;
import org.openqa.selenium.devtools.v150.page.Page.PrintToPDFResponse;
import org.openqa.selenium.devtools.v150.target.Target;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.print.PrintOptions;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gatf.executor.core.AcceptanceTestContext;
import com.gatf.executor.core.GatfExecutorConfig;
import com.gatf.executor.core.WorkflowContextHandler;
import com.gatf.executor.dataprovider.FileTestDataProvider;
import com.gatf.executor.dataprovider.MongoDBTestDataSource;
import com.gatf.executor.dataprovider.SQLDatabaseTestDataSource;
import com.gatf.executor.dataprovider.TestDataSource;
import com.gatf.executor.executor.TestCaseExecutorUtil;
import com.gatf.selenium.Command.FindCommandImpl;
import com.gatf.selenium.Command.GatfSelCodeParseError;
import com.gatf.selenium.SeleniumTestSession.SeleniumResult;
import com.google.common.io.Resources;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import com.jayway.jsonpath.JsonPath;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import jakarta.xml.bind.DatatypeConverter;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract1;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import technology.tabula.ObjectExtractor;
import technology.tabula.Page;
import technology.tabula.PageIterator;
import technology.tabula.RectangularTextContainer;
import technology.tabula.Table;
import technology.tabula.extractors.SpreadsheetExtractionAlgorithm;

public abstract class SeleniumTest {
	protected final static Map<String, Level> LOG_LEVEL_BY_NAME_MAP = new HashMap<String, Level>(){{
		put(Level.ALL.getName().toLowerCase(), Level.ALL);
		put(Level.CONFIG.getName().toLowerCase(), Level.CONFIG);
		put(Level.FINE.getName().toLowerCase(), Level.FINE);
		put(Level.FINER.getName().toLowerCase(), Level.FINER);
		put(Level.FINEST.getName().toLowerCase(), Level.FINEST);
		put(Level.INFO.getName().toLowerCase(), Level.INFO);
		put(Level.OFF.getName().toLowerCase(), Level.OFF);
		put(Level.SEVERE.getName().toLowerCase(), Level.SEVERE);
		put(Level.WARNING.getName().toLowerCase(), Level.WARNING);
	}};
	protected final static HashSet<String> LOG_TYPES_SET = new HashSet<String>() {{
		add(LogType.BROWSER);
		//add(LogType.CLIENT);
		add(LogType.DRIVER);
		add(LogType.PERFORMANCE);
		//add(LogType.PROFILER);
		//add(LogType.SERVER);
	}};

	private static final String TOP_LEVEL_PROV_NAME = UUID.randomUUID().toString();
	private static final Map<String, Map<String, String>> DRV_FEATURES = new ConcurrentHashMap<String, Map<String,String>>();
	static final Map<String, List<List<Map<String, String>>>> _pdtTables = new HashMap<>();   // G8: package-private (PdfTables aliases it)
	// Tesseract1 wraps a native, non-thread-safe handle; keep one per thread so concurrent
	// OCR under the load/concurrent engines never shares a single native instance.
	private static final ThreadLocal<ITesseract> instance = new ThreadLocal<>();
	private static final Pattern p = Pattern.compile("\\$(p|P)\\{([\"'a-zA-Z0-9_\\.]+)\\.([0-9]+)\\.([a-zA-Z0-9_\\.]+)\\}");
	public static boolean CONC_WD = false;
	
	private TestState state = new TestState();
	private transient AcceptanceTestContext ___cxt___ = null;
	
	protected void addPossInvXpath(String xpath, String cmd, String line, String file) {
		state.possibleInvXpathExprs.add(new String[] {xpath, cmd, line, file});
	}
	
	public static Lock createLock() {
		if(CONC_WD) {
			return new ReentrantLock();
		} else {
			return new Lock() {
				@Override
				public void unlock() {
				}
				@Override
				public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
					return false;
				}
				@Override
				public boolean tryLock() {
					return false;
				}
				@Override
				public Condition newCondition() {
					return null;
				}
				@Override
				public void lockInterruptibly() throws InterruptedException {
				}
				@Override
				public void lock() {
				}
			};
		}
	}
	
	//public static ThreadLocal<>
	
	/*public void setUpCC(SeleniumTestSession sess) {
		sess.ccStatus = true;
		try {
			sess.ccServer = new ServerSocket();
			System.out.println("Command Server Listening on port " + sess.ccServer.getLocalPort());
			sess.ccThrd = new Thread(new Runnable() {
				@Override
				public void run() {
					while(sess.ccStatus) {
						try {
							Socket c = sess.ccServer.accept();
							System.out.println("Agent Connected from " + c.getRemoteSocketAddress().toString());
							BufferedReader bio = new BufferedReader(new InputStreamReader(c.getInputStream()));
							String command = bio.readLine();
							switch (command) {
								case "screenshot":
									screenshotAsFile(get___d___(), command);
									break;
								default:
									break;
							}
						} catch (Exception e) {
						}
					}
					try {
						sess.ccServer.close();
					} catch (Exception e) {
					}
				}
			});
			sess.ccThrd.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void cleanUpCC(SeleniumTestSession sess) {
		sess.ccStatus = false;
	}*/
	
	protected String addWdm(String browserName, Capabilities capabilities) {
		if(browserName.endsWith("-rec")) {
			browserName= browserName.replaceFirst("-rec", "");
		} else if(browserName.endsWith("-dkr")) {
			browserName= browserName.replaceFirst("-dkr", "");
		} else if(browserName.endsWith("-hdl")) {
			browserName= browserName.replaceFirst("-hdl", "");
		}
		
		switch(browserName) {
			case "chrome": case "firefox": case "ie": case "edge": case "safari": case "opera":
				break;
			default:
				throw new RuntimeException("Invalid browser name specified for browser");
		}
		// M4: route on Firefox/Safari needs WebDriver BiDi. Chromium intercepts over CDP, except where it has none:
		// a Grid session (a plain RemoteWebDriver), traceProtocol bidi or -Dgatf.routeProtocol=bidi, which then need the BiDi socket too.
		boolean chromium = browserName.equals("chrome") || browserName.equals("edge") || browserName.equals("opera");
		GatfExecutorConfig rcfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		boolean chromiumNeedsBidi = System.getenv("SELENIUM_REMOTE_URL") != null || System.getProperty("gatf.selenium.remoteUrl") != null
				|| "bidi".equalsIgnoreCase(__routeProtocol__(rcfg));
		// H3: per-test contexts are created over WebDriver BiDi on Chromium and Firefox (CDP refuses Target.*Context on a
		// page target; its browser-level fallback is used only when the session has no BiDi socket)
		boolean ctxOn = rcfg != null && "subtest".equals(rcfg.browserContextMode());
		if(((__routeBidi__ && (!chromium || chromiumNeedsBidi)) || (ctxOn && (chromium || browserName.equals("firefox"))))
				&& capabilities instanceof org.openqa.selenium.MutableCapabilities) {
			((org.openqa.selenium.MutableCapabilities) capabilities).setCapability("webSocketUrl", true);
		}
		// Store the built capabilities; the driver is created in getDockerDriver -- a Grid
		// RemoteWebDriver when SELENIUM_REMOTE_URL is set, else a local driver whose driver AND browser
		// (Chrome for Testing) Selenium Manager provisions on demand -- no docker, no manual setup.
		state.driverCaps.put(browserName, capabilities);
		return browserName;
	}
	
	protected WebDriver getDockerDriver(String browserName) {
		return BrowserDrivers.create(browserName, state.driverCaps.get(browserName), ___cxt___);   // G8: moved to BrowserDrivers
	}
	
	protected void __set__cln__(String line_) {
		try {
			state.cfileName = line_.split(":")[0];
			state.line = Integer.valueOf(line_.split(":")[1]);
		} catch (Exception e) {
		}
	}
	
	protected void setSleepGranularity(long timeoutSleepGranularity) {
		state.timeoutSleepGranularity = timeoutSleepGranularity; 
	}

	protected void nextSession() {
		if(state.sessions.size()>state.sessionNum+1) {
			state.sessionNum++;
		}
	}

	protected Set<String> addTest(String sessionName, String browserName) {
		final SeleniumTestSession s = new SeleniumTestSession();
		s.sessionName = sessionName==null?Integer.toHexString(state.sessionNum+1):sessionName;
		s.browserName = browserName;
		state.sessions.add(s);
		if(!s.__result__.containsKey(browserName)) {
			SeleniumResult r = new SeleniumResult();
			r.browserName = browserName;
			s.__result__.put(browserName, r);
		} else {
			//throw new RuntimeException("Duplicate browser defined");
		}
		return new HashSet<String>(){{add(s.sessionName); add((state.sessions.size()-1)+"");}};
	}

	protected void setSession(String sns, int sn, boolean startFlag) {
		if(sn>=0 && state.sessions.size()>sn) {
			state.sessionNum = sn;
		} else if(sns!=null) {
			sn = 0;
			for (SeleniumTestSession s : state.sessions) {
				if(s.sessionName.equalsIgnoreCase(sns)) {
					state.sessionNum = sn; 
				}
				sn++;
			}
		} else if(sn==-1 && sns==null) {
			state.sessionNum = 0;
		}
		if(startFlag) {
			startTest();
		}
	}
	
	protected void addSubTest(String stname) {
		for (SeleniumTestSession s : state.sessions) {
			s.__result__.get(s.browserName).__cresult_or__.put(stname, null);
		}
	}

	protected void startTest() {
		if(getSession().__teststarttime__==0) {
			getSession().__teststarttime__ = System.nanoTime();
		}
	}

	public void pushResult(SeleniumTestResult result)
	{
		if(result.cause!=null && (result.cause instanceof PassSubTestException || result.cause instanceof WarnSubTestException)) {
			result.executionTime = System.nanoTime() - getSession().__subtestexecutiontime__;
			getSession().__result__.get(getSession().browserName).__cresult__.put(getSession().__subtestname__ + " ["+result.cause.getMessage()+"]", result);
		} else if(getSession().__subtestname__==null) {
			result.executionTime = System.nanoTime() - getSession().__teststarttime__;
			getSession().__result__.get(getSession().browserName).result = result;
		} else {
			result.executionTime = System.nanoTime() - getSession().__subtestexecutiontime__;
			getSession().__result__.get(getSession().browserName).__cresult__.put(getSession().__subtestname__, result);
		}
		CloudDrivers.onResult(getSession(), state.name);   // Δ157 (H5): status to the device-cloud dashboard; no-op without GATF_CLOUD
		if(result!=null && ((!result.isStatus() && !result.isContinue) || result.cause instanceof WarnSubTestException)) {
			FailureException fe = new FailureException(result.getCause());
			if(state.cfileName!=null) {
				String relName = state.cfileName.replace(state.basePath, "");
			    if(relName.startsWith(File.separator)) {
			    	relName = relName.substring(1);
	        	}
			    String cmd = "";
				try {
					cmd = Files.readAllLines(Paths.get(state.name)).get(state.line-1);
				} catch (Exception e) {
				}
				fe.details = new Object[] {cmd, state.line, relName, result.getCause().getMessage()};
			} else {
				fe.details = new Object[] {"", 0, "", result.getCause().getMessage()};
			}
			if(!result.isContinue) {
				throw fe;
			}
		}
	}

	protected void newTopLevelProvider() {
		if(!getSession().providerTestDataMap.containsKey(TOP_LEVEL_PROV_NAME)) {
			getSession().providerTestDataMap.put(TOP_LEVEL_PROV_NAME, new ArrayList<Map<String,String>>());
			getSession().providerTestDataMap.get(TOP_LEVEL_PROV_NAME).add(new HashMap<String, String>());
		}
	}

	protected void addToTopLevelProviderTestDataMap(String name, String value) {
		getSession().providerTestDataMap.get(TOP_LEVEL_PROV_NAME).get(0).put(name, value);
	}

	protected void newProvider(String name) {
		name = getPn(name);
		if(!getSession().providerTestDataMap.containsKey(name)) {
			getSession().providerTestDataMap.put(name, new ArrayList<Map<String,String>>());
		}
	}
	
	protected List<Map<String, String>> setProviderTestDataMap(String pname, List<Map<String, String>> values) {
		pname = getPn(pname);
		getSession().providerTestDataMap.put(pname, values);
		return values;
	}

	protected void addToProviderTestDataMap(String pname, String name, String value) {
		pname = getPn(pname);
		if(getSession().providerTestDataMap.containsKey(pname)) {
			getSession().providerTestDataMap.get(pname).get(0).put(name, value);
		}
	}

	protected void delProvider(String name) {
		name = getPn(name);
		if(getSession().providerTestDataMap.containsKey(name)) {
			getSession().providerTestDataMap.remove(name);
		}
	}

	protected List<Map<String, String>> getProviderTestDataMap(String name) {
		return getAllProviderData(getPn(name));
	}

	protected List<Map<String, String>> getSQLProviderTestDataMap(String name, String dsn, String query, String vars) {
		SQLDatabaseTestDataSource sdt = ___cxt___.getSQLDSN(dsn);
		if(sdt!=null) {
			return setProviderTestDataMap(name, sdt.provide(query, vars, ___cxt___));
		}
		throw new RuntimeException("No SQL DSN found with the name " + dsn);
	}

	protected List<Map<String, String>> getMongoProviderTestDataMap(String name, String dsn, String query, String collName, String properties, String vars) {
		MongoDBTestDataSource sdt = ___cxt___.getMongoDSN(dsn);
		if(sdt!=null) {
			return setProviderTestDataMap(name, sdt.provide(query, collName, properties, vars, ___cxt___));
		}
		throw new RuntimeException("No Mongo DSN found with the name " + dsn);
	}

	protected List<Map<String, String>> getFileProviderTestDataMap(String name, String filePath, String vars) {
		if(!new File(filePath).exists()) throw new RuntimeException("No file found with at path " + filePath);
		return setProviderTestDataMap(name, FileTestDataProvider.provide(filePath, vars, ___cxt___));
	}
	
	protected boolean executeQuery(String dsn, String query) {
		TestDataSource tds = ___cxt___.getDSN(dsn);
		if(tds!=null) {
			return tds.execute(query);
		}
		return false;
	}

	protected String getFileProviderHash(String name) {
		return ___cxt___.getFileProviderHash(name);
	}

	protected String getBrowserName() {
		return getSession().browserName;
	}

	protected String getSessionName() {
		return getSession().sessionName;
	}

	protected boolean isBrowserName(String bn) {
		if(StringUtils.isNotBlank(bn)) {
			bn = bn.trim();
			if(bn.charAt(0)==bn.charAt(bn.length()-1)) {
                if(bn.charAt(0)=='"' || bn.charAt(0)=='\'') {
                	bn = bn.substring(1, bn.length()-1);
                }
            }
		}
		return getSession().browserName.equals(bn);
	}

	protected boolean isSessionName(String bn) {
		return getSession().browserName.equals(bn);
	}

	private SeleniumTestSession getSession() {
		return state.sessions.get(state.sessionNum);
	}

	protected boolean matchesSessionId(String sname, int sessionId) {
		if(sname==null && sessionId==-1)return true;
		if(StringUtils.isBlank(sname)) {
			return state.sessionNum==sessionId;
		} else {
			int sn = 0;
			for (SeleniumTestSession s : state.sessions) {
				if(s.sessionName.equalsIgnoreCase(sname)) {
					return state.sessionNum==sn; 
				}
				sn++;
			}
		}
		return false;
	}

	private List<Map<String, String>> getAllProviderData(String pn) {
		List<Map<String, String>> ep = pn!=null?___cxt___.getAnyProviderData(pn, null):null;
		List<Map<String, String>> tp = pn!=null?getSession().providerTestDataMap.get(pn):null;
		List<Map<String, String>> fp = null;
		if((ep!=null && tp!=null) || tp!=null) {
			fp = tp;
		} else if(ep!=null) {
			fp = ep;
		}
		return fp;
	}

	private Map<String, Object> getFinalDataMap(String pn, Integer pp) {
		Map<String, Object> _mt = new HashMap<String, Object>();
		List<Map<String, String>> fp = getAllProviderData(pn);
		_mt.putAll(___cxt___.getWorkflowContextHandler().getGlobalSuiteAndTestLevelParameters(null, CollectionUtils.isEmpty(fp)?null:fp.get(pp), state.index));
		if(getSession().providerTestDataMap.containsKey(TOP_LEVEL_PROV_NAME) && getSession().providerTestDataMap.get(TOP_LEVEL_PROV_NAME).get(0)!=null) {
			_mt.putAll(getSession().providerTestDataMap.get(TOP_LEVEL_PROV_NAME).get(0));
		}
		return _mt;
	}
	
	private void initTmplMap(Map<String, Object> _mt) {
		_mt.put("M", Math.class);
		_mt.put("U", Util.class);
		_mt.put("today", Util.today);
		_mt.put("yesterday", Util.yesterday);
		_mt.put("tomorrow", Util.tomorrow);
		_mt.put("day", Util.day);
		_mt.put("lastWeek", Util.lastWeek);
		_mt.put("nextWeek", Util.nextWeek);
		_mt.put("week", Util.week);
		_mt.put("lastMonth", Util.lastMonth);
		_mt.put("nextMonth", Util.nextMonth);
		_mt.put("month", Util.month);
		_mt.put("lastYear", Util.lastYear);
		_mt.put("nextYear", Util.nextYear);
		_mt.put("year", Util.year);
		_mt.put("now", Util.now);
		_mt.put("lastSecond", Util.lastSecond);
		_mt.put("nextSecond", Util.nextSecond);
		_mt.put("second", Util.second);
		_mt.put("lastMinute", Util.lastMinute);
		_mt.put("nextMinute", Util.nextMinute);
		_mt.put("minute", Util.minute);
		_mt.put("lastHour", Util.lastHour);
		_mt.put("nextHour", Util.nextHour);
		_mt.put("hour", Util.hour);
		_mt.put("S", StringUtils.class);
		_mt.put("D", DateUtils.class);
	}

	/*
	 * Three types of template variables can be evaluated
	 * 1. ${var-name} - a value inside a provider slot or a top-level variable
	 * 2. $v{var-name} - a current context java variable
	 * 3. $p{prov-name.position.var-name} - a direct reference to a variable in provider at a positional map of values
	 */
	protected String evaluate(String tmpl) {
		if(tmpl.indexOf("$")==-1)return tmpl;
		try
		{
			if(getSession().__provdetails__.size()>0) {
				ArrayList<String> keys = new ArrayList<String>(getSession().__provdetails__.keySet());
				for (int i=keys.size()-1;i>=0;i--)
				{
					String pn = keys.get(i);
					Integer pp = getSession().__provdetails__.get(pn);
					Map<String, Object> _mt = getFinalDataMap(pn, pp);
					if(tmpl.indexOf("$v{")!=-1) {
						tmpl = tmpl.replace("$v", "$");
						for(String vn: getSession().__vars__.keySet()) {
							if(!getSession().__vars__.get(vn).isEmpty() ) {
								_mt.put(vn, getSession().__vars__.get(vn).peek());
							}
						}
					}
					initTmplMap(_mt);
					tmpl = ___cxt___.getWorkflowContextHandler().templatize(_mt, tmpl);
				}
			} else {
				Map<String, Object> _mt = getFinalDataMap(null, null);
				if(tmpl.indexOf("$v{")!=-1) {
					tmpl = tmpl.replace("$v", "$");
					for(String vn: getSession().__vars__.keySet()) {
						if(!getSession().__vars__.get(vn).isEmpty() ) {
							_mt.put(vn, getSession().__vars__.get(vn).peek());
						}
					}
				}
				initTmplMap(_mt);
				tmpl = ___cxt___.getWorkflowContextHandler().templatize(_mt, tmpl);
			}
			String tmpln = tmpl;
			Matcher m = p.matcher(tmpl);
			Map<String, Object> _mt = new HashMap<String, Object>();
			boolean foundProvRef = false;
			while(m.find()) {
				String[] parts = m.group(4).split("\\.");
				if(parts.length>1) {
					String ivp = parts[0];
					for (int i = 1; i < parts.length; i++) {
						ivp += "." + parts[i];
					}
					String provName = m.group(2);
					if((provName.startsWith("\"") && provName.endsWith("\"")) || (provName.startsWith("'") && provName.endsWith("'"))) {
						provName = provName.substring(1, provName.length()-1);
					}
					provName = getPn(provName);
					if(getSession().providerTestDataMap.containsKey(provName)) {
						foundProvRef = true;
						tmpln = tmpln.replace(tmpl.substring(m.start(), m.end()), "${"+ivp+"}");
						_mt.putAll(getSession().providerTestDataMap.get(provName).get(Integer.valueOf(m.group(3))));
					}
				}
			}
			if(foundProvRef) {
				initTmplMap(_mt);
				tmpl = ___cxt___.getWorkflowContextHandler().templatize(_mt, tmpln);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return tmpl;
	}
	
	protected boolean doEvalIf(String eval) {
		Map<String, Object> _mt = new HashMap<String, Object>();
		try {
			initTmplMap(_mt);
			System.out.println("Evaluating expression ["+evaluate(eval)+"]");
			String ret = ___cxt___.getWorkflowContextHandler().templatize(_mt, "#if("+evaluate(eval) + ") true #else false #end");
			if(!ret.toLowerCase().trim().equals("true")) {
				System.out.println("Failing condition -- " + evaluate(eval));
			}
			return ret.toLowerCase().trim().equals("true");
		} catch (Exception e) {
		}
		return false;
	}

	protected String getProviderDataValue(String key, boolean isVar) {
		if(isVar) {
			Object o = ___get_var__(key);
			if(o!=null && o instanceof String) {
				return o.toString();
			}
			return null;
		}
		if(getSession().providerTestDataMap.containsKey(TOP_LEVEL_PROV_NAME) && getSession().providerTestDataMap.get(TOP_LEVEL_PROV_NAME).get(0).containsKey(key)) {
			return getSession().providerTestDataMap.get(TOP_LEVEL_PROV_NAME).get(0).get(key);
		}
		if(getSession().__provdetails__.size()>0) {
			ArrayList<String> keys = new ArrayList<String>(getSession().__provdetails__.keySet());
			for (int i=keys.size()-1;i>=0;i--)
			{
				String pn = keys.get(i);
				Integer pp = getSession().__provdetails__.get(pn);
				List<Map<String, String>> _t = getAllProviderData(pn);
				if(_t!=null && _t.get(pp)!=null) {
					Map<String, String> _mt = ___cxt___.getWorkflowContextHandler().getGlobalSuiteAndTestLevelParameters(null, _t.get(pp), state.index);
					if(_mt.containsKey(key)) {
						return _mt.get(key);
					}
				}
			}
			return null;
		} else {
			Map<String, String> _mt = ___cxt___.getWorkflowContextHandler().getGlobalSuiteAndTestLevelParameters(null, null, state.index);
			return _mt.get(key);
		}
	}

	protected Object getProviderDataValueO(String key, boolean isVar) {
		if(isVar) {
			return ___get_var__(key);
		}
		if(getSession().providerTestDataMap.containsKey(TOP_LEVEL_PROV_NAME) && getSession().providerTestDataMap.get(TOP_LEVEL_PROV_NAME).get(0).containsKey(key)) {
			return getSession().providerTestDataMap.get(TOP_LEVEL_PROV_NAME).get(0).get(key);
		}
		if(getSession().__provdetails__.size()>0) {
			ArrayList<String> keys = new ArrayList<String>(getSession().__provdetails__.keySet());
			for (int i=keys.size()-1;i>=0;i--)
			{
				String pn = keys.get(i);
				Integer pp = getSession().__provdetails__.get(pn);
				List<Map<String, String>> _t = getAllProviderData(pn);
				if(_t!=null && _t.get(pp)!=null) {
					Map<String, String> _mt = ___cxt___.getWorkflowContextHandler().getGlobalSuiteAndTestLevelParameters(null, _t.get(pp), state.index);
					if(_mt.containsKey(key)) {
						return _mt.get(key);
					}
				}
			}
			return null;
		} else {
			Map<String, String> _mt = ___cxt___.getWorkflowContextHandler().getGlobalSuiteAndTestLevelParameters(null, null, state.index);
			return _mt.get(key);
		}
	}

	protected void ___add_var__(String name, Object val) {
		if(!getSession().__vars__.containsKey(name)) {
			getSession().__vars__.put(name, new Stack<>());
		}
		getSession().__vars__.get(name).push(val);
	}

	protected Object ___get_var__(String name) {
		if(!getSession().__vars__.containsKey(name) || getSession().__vars__.get(name).isEmpty() ) {
			throw new RuntimeException("Variable " + name + " not defined");
		}
		return getSession().__vars__.get(name).peek();
	}

	protected void ___del_var__(String name) {
		if(getSession().__vars__.containsKey(name)) {
			if(!getSession().__vars__.get(name).isEmpty()) {
				getSession().__vars__.get(name).pop();
			}
			getSession().__vars__.remove(name);
		}
	}

	protected WebDriver get___d___()
	{
		if(getSession().___d___.size()==0)return null;
		return getSession().___d___.get(getSession().__wpos__);
	}

	protected void set___d___(WebDriver ___d___)
	{
		if(___d___ instanceof RemoteWebDriver) {
			try {
				((RemoteWebDriver)___d___).setFileDetector(new LocalFileDetector());
			} catch(Exception e) {
			}
		}
		try {
			___d___.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(100));
		} catch (org.openqa.selenium.WebDriverException e) {
			if (AppiumTouch.platform(___d___) == null) throw e;   // Δ158: Appium native contexts have no pageLoad timeout
		}
		getSession().___d___.add(___d___);
		getSession().___dqs___.add(false);
	}

	protected class PrettyPrintingMap<K, V> {
		private Map<K, V> map;

		public PrettyPrintingMap(Map<K, V> map) {
			this.map = map;
		}

		public String toString() {
			StringBuilder sb = new StringBuilder();
			Iterator<Entry<K, V>> iter = map.entrySet().iterator();
			while (iter.hasNext()) {
				Entry<K, V> entry = iter.next();
				sb.append(entry.getKey());
				sb.append('=').append('"');
				sb.append(entry.getValue());
				sb.append('"');
				if (iter.hasNext()) {
					sb.append(',').append(' ');
				}
			}
			return sb.toString();

		}
	}

	private String getPn(String name) {
		String pn = name;
		if(state.index>0) {
			pn += state.index;
		}
		return pn;
	}

	protected void ___cxt___add_param__(String name, Object value)
	{
		___cxt___.getWorkflowContextHandler().addSuiteLevelParameter(state.index, name, value==null?null:value.toString());
	}

	protected void ___cxt___print_provider__(String name)
	{
		System.out.println(getAllProviderData(getPn(name)));
	}

	protected void ___cxt___print_provider__json(String name)
	{
		try
		{
			System.out.println(WorkflowContextHandler.OM.writerWithDefaultPrettyPrinter().writeValueAsString(getAllProviderData(getPn(name))));
		}
		catch (Exception e)
		{
		}
	}

	protected AcceptanceTestContext get___cxt___()
	{
		return ___cxt___;
	}

	protected void set___cxt___(AcceptanceTestContext ___cxt___)
	{
		this.___cxt___ = ___cxt___;
	}

	public List<SeleniumTestSession> get__sessions__()
	{
		return state.sessions;
	}

	protected void set__provname__(String __provname__)
	{
		getSession().__provdetails__.put(getPn(__provname__), -1);
	}

	protected void set__provpos__(String __provname__, int __provpos__)
	{
		getSession().__provdetails__.put(getPn(__provname__), __provpos__);
	}

	protected void rem__provname__(String __provname__)
	{
		getSession().__provdetails__.remove(getPn(__provname__));
	}

	protected void set__subtestname__(String stname, String __subtestname__)
	{
		if(__subtestname__!=null) {
			getSession().__result__.get(getSession().browserName).__cresult_or__.remove(stname);
			if(getSession().__provdetails__.size()>0) {
				String fstn = "";
				ArrayList<String> keys = new ArrayList<String>(getSession().__provdetails__.keySet());
				for (int i=keys.size()-1;i>=0;i--)
				{
					String pn = keys.get(i);
					Integer pp = getSession().__provdetails__.get(pn);
					fstn += "(" + pn + "@" + pp + ") ";
				}
				__subtestname__ += " " + fstn;
			}
		}
		getSession().__subtestexecutiontime__ = System.nanoTime();
		String prior = getSession().__subtestname__;
		getSession().__subtestname__ = __subtestname__;
		// M2: soft failures recorded before the call belong to the caller, not to this subtest
		__softStack__.push(new java.util.AbstractMap.SimpleEntry<String, List<String>>(prior, __soft__.drain()));
		if(prior == null && __subtestname__ != null) __ctxEnter__();   // H3: a top-level subtest gets a fresh context
	}
	
	protected void reset__subtestname__(String __subtestname__)
	{
		if(__subtestname__ == null) __ctxExit__();   // H3: back from a top-level subtest (runs in its finally)
		getSession().__subtestname__ = __subtestname__;
		// pops only the entry its set__subtestname__ pushed (a set that threw pushed nothing)
		Entry<String, List<String>> top = __softStack__.peek();
		if(top != null && java.util.Objects.equals(top.getKey(), __subtestname__)) __soft__.restore(__softStack__.pop().getValue());
	}
	
	protected String get__subtestname__() {
		return getSession().__subtestname__;
	}
	
	protected void set__funcname__(String stname, String __funcname__)
	{
		getSession().__funcname__ = __funcname__;
	}
	
	protected void reset__funcname__(String __funcname__)
	{
		getSession().__funcname__ = __funcname__;
	}
	
	protected String get__funcname__() {
		return getSession().__funcname__;
	}
	
	protected void set__loopcontext__(Map<String, Object> __loopcontext__)
	{
		getSession().__loopcontext__ = __loopcontext__;
		if(!get__loopcontext__var("n").equals("n") && get__loopcontext__var("ft").equals("t")) {
			rem__provname__(get__loopcontext__var("n")+"_rf");
			delProvider(get__loopcontext__var("n")+"_rf");
		}
	}
	
	protected String get__loopcontext__var(String n) {
		if(!getSession().__loopcontext__.containsKey(n)) {
			return n;
			//throw new RuntimeException("No Loop Context available");
		}
		return (String)getSession().__loopcontext__.get(n);
	}
	
	protected int get__loopcontext__indx() {
		if(!getSession().__loopcontext__.containsKey("i")) {
			return -1;
		}
		return (Integer)getSession().__loopcontext__.get("i");
	}
	
	protected void set__loopcontext__(String name)
	{
		getSession().__loopcontext__ = new HashMap<>();
		getSession().__loopcontext__.put("n", name);
	}
	
	protected void add__loopcontext__arg(String n, Object v)
	{
		getSession().__loopcontext__.put(n, v);
	}
	
	protected Map<String, Object> get__loopcontext__() {
		return getSession().__loopcontext__;
	}

	protected WebDriver getWebDriver() {
		return getSession().___d___.get(getSession().__wpos__);
	}

	protected AndroidDriver getAndroidDriver() {
		if(getSession().___d___ instanceof AndroidDriver) {
			return (AndroidDriver)getSession().___d___;
		}
		return null;
	}

	protected IOSDriver getIOSDriver() {
		if(getSession().___d___ instanceof IOSDriver) {
			return (IOSDriver)getSession().___d___;
		}
		return null;
	}

	/*protected SelendroidDriver getSelendroidDriver() {
		if(getSession().___d___ instanceof SelendroidDriver) {
			return (SelendroidDriver)getSession().___d___;
		}
		return null;
	}*/

	public SeleniumTest(String name_, AcceptanceTestContext ___cxt___, int index) {
		this.___cxt___ = ___cxt___;
	    state.name = name_;
		try {
            BasicFileAttributes attr = Files.readAttributes(Paths.get(name_), BasicFileAttributes.class);
			state.lastModifFileTime = attr.lastModifiedTime();
			File basePath_ = new File(___cxt___.getGatfExecutorConfig().getTestCasesBasePath());
			if(___cxt___.getGatfExecutorConfig().getTestCaseDir()!=null) {
			    File testPath = new File(basePath_, ___cxt___.getGatfExecutorConfig().getTestCaseDir());
			    state.basePath = testPath.getAbsolutePath();
			} else {
				state.basePath = basePath_.getAbsolutePath();
			}
		} catch (Exception e) {
		}
		state.index = index;
		//this.properties = ___cxt___.getGatfExecutorConfig().getSelDriverConfigMap().get(name).getProperties();
	}

	public String getName() {
		return state.name;
	}

	public static interface Functor<I, O> {
		O f(I i, I j);
	}

	public static interface CondFunc {
		Integer f(Object[] args);
	}
	
	/** H3 (Δ154): this run's worker pool (browserContexts=worker), or null: never for the loginOnce script. */
	private com.gatf.selenium.context.WorkerPool<WebDriver> __workerPool__() {
		if(___cxt___ == null || Boolean.TRUE.equals(LOGIN_ONCE_RUN.get())) return null;
		return com.gatf.selenium.context.WorkerDrivers.pool(___cxt___);
	}

	/** H3 (Δ154): the pooling key of the browser {@code bkey} is about to launch (BiDi socket requested first). */
	private String __workerKey__(String bkey) {
		Capabilities c = state.driverCaps.get(bkey);
		if(com.gatf.selenium.context.WorkerDrivers.wantsBidi(bkey) && c instanceof org.openqa.selenium.MutableCapabilities) {
			((org.openqa.selenium.MutableCapabilities) c).setCapability("webSocketUrl", true);
		}
		return com.gatf.selenium.context.WorkerPool.fingerprint(bkey, c == null ? null : c.asMap());
	}

	/** H3 (Δ154): open this script's fresh context in a worker browser and make its tab current (null = refused). */
	private String __workerOpen__(WebDriver d) {
		String ctx = __ctxScope__(d).open();
		if(ctx != null) BrowserState.userContext(d, ctx);
		return ctx;
	}

	/**
	 * H3 (Δ154): emitted by codegen before a browser is launched: this worker's pooled browser, its fresh context open
	 * and current, or null (launch one and pass it to {@link #__workerAdopt__}). Always null unless browserContexts=worker.
	 */
	protected WebDriver __workerDriver__(String bkey) {
		com.gatf.selenium.context.WorkerPool<WebDriver> p = __workerPool__();
		if(p == null || CloudDrivers.routesPlainKeys()) return null;   // Δ154/157 merge: a device-cloud session is never pooled (its dashboard name/status is per session)
		return p.acquire(Thread.currentThread(), this, __workerKey__(bkey), this::__workerOpen__);
	}

	/**
	 * H3 (Δ154): emitted by codegen around a newly launched browser: offer it to the worker pool (which opens the
	 * script's context in it) and return it unchanged. Without a pool, or where contexts are unsupported, the browser
	 * stays the script's own and is quit at script end, as before.
	 */
	protected WebDriver __workerAdopt__(String bkey, WebDriver d) {
		com.gatf.selenium.context.WorkerPool<WebDriver> p = __workerPool__();
		if(p == null || d == null || CloudDrivers.routesPlainKeys()) return d;   // Δ154/157 merge: cloud sessions stay per script
		GatfExecutorConfig cfg = ___cxt___.getGatfExecutorConfig();
		boolean tracing = cfg != null && cfg.captureTraceThisRun() && !cfg.isLoadTestingEnabled()
				&& (cfg.getConcurrentUserSimulationNum()==null || cfg.getConcurrentUserSimulationNum()<=1);
		// a CDP trace is bound to the default context: trace this run over BiDi, or (no BiDi) do not pool (logged once)
		if(cfg != null && p.trace(tracing, cfg.getTraceProtocol(), d instanceof HasDevTools, com.gatf.selenium.trace.BidiRaw.available(d))
				== com.gatf.selenium.context.WorkerPool.Trace.BIDI) {
			cfg.setTraceProtocol("bidi");
		}
		p.adopt(Thread.currentThread(), this, __workerKey__(bkey), d, com.gatf.selenium.context.WorkerDrivers.refusal(d), this::__workerOpen__);
		return d;
	}

	/** H3 (Δ154): script end: true when {@code d} is a worker browser, kept by the pool (never quit here). */
	private boolean __workerRelease__(WebDriver d) {
		com.gatf.selenium.context.WorkerPool<WebDriver> p = __workerPool__();
		return p != null && p.release(this, d);
	}

	public void quit(SeleniumTestSession sess) {
		__ctxCloseAll__();   // H3: no per-test context outlives the script (pass, fail, timeout or abort)
		if(sess.__trace__!=null) { try { sess.__trace__.stop(); } catch (Exception e) {} }
		// M5: the loginOnce script leaves its authenticated state for the suite
		GatfExecutorConfig __scfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		if(Boolean.TRUE.equals(LOGIN_ONCE_RUN.get()) && __scfg != null && StringUtils.isNotBlank(__scfg.getStorageState()) && sess.___d___.size() > 0
				&& !sess.___dqs___.get(0) && !__loginOnceSaved__) {
			try {
				System.out.println(BrowserState.save(sess.___d___.get(0), stateFile(__scfg.getStorageState().trim())));
			} catch (Exception e) {
				System.out.println("loginOnce: could not save the storage state (" + e.getMessage() + ") - end the script with 'state save <file>' while the page is still open");
			}
		}
		if(sess.___d___.size()>0) {
			int indx = 0;
			for (WebDriver d : sess.___d___)
			{
				if(sess.___dqs___.get(indx)) continue;
				// M4: no route may outlive the script (a driver kept in wdmSessions is reused with its interception).
				// disableRoutes only, not close(): the transport may share its DevTools/BiDi session with the tracer, and its
				// listener then answers only its own (removed) intercepts.
				Object[] __rs = __routes__.remove(d);
				if(__rs != null && Boolean.TRUE.equals(__rs[2])) {
					try { ((com.gatf.selenium.trace.BrowserControl) __rs[1]).disableRoutes(); } catch (Exception e) {}
				}
				String sessionId = null;
				try {
					sessionId = ((RemoteWebDriver)d).getSessionId().toString();
					DRV_FEATURES.remove(sessionId);
				} catch (Exception e) {
				}
				try {
					if(__workerRelease__(d)) {
						// H3 (Δ154): a worker browser: its context is already disposed (__ctxCloseAll__), the pool keeps it
					} else if((sessionId!=null && !state.wdmSessions.containsKey(sessionId)) || sessionId==null) {
						d.quit();
					}
				} catch (Exception e) {
					if(e.getCause()!=null) {
						/*if(e.getCause() instanceof TimeoutException) {
							try {
								d.quit();
							} catch (Exception e2) {
								e2.getCause().printStackTrace();
							}
						} else {*/
							//e.getCause().printStackTrace();
						//}
					}
				}
				sess.___dqs___.set(indx, true);
				if(d instanceof HasDevTools) {
					//DevTools devTools = ((HasDevTools)d).getDevTools();
					//devTools.disconnectSession();
				}
			}
		}
	}

	public void quit() {
		quit(getSession());
	}

	public void quitAll() {
		for (SeleniumTestSession s : state.sessions) {
			quit(s);
		}
		clearSemanticOpts();
	}

	public abstract void close();

	public abstract SeleniumTest copy(AcceptanceTestContext ctx, int index);

	protected void setOutPath(String path) {
		setSemanticOpts();   // M3: the executing thread sees this test's semantic options on every find path
		state.outPath = path;
	}

	@SuppressWarnings("unchecked")
	protected List<WebElement> ___invoke_sub_test_dyn___(Class<?> claz, String stName, String __sfname__, WebDriver ___cw___,
			WebDriver ___ocw___, SearchContext ___sc___1, LoggingPreferences ___lp___) throws Throwable {
		Method method = claz.getDeclaredMethod(stName, new Class[] { String.class, WebDriver.class, WebDriver.class,
				SearchContext.class, LoggingPreferences.class });
		if(state._dynTstObj.get()!=null) {
			SeleniumTest tst_ = state._dynTstObj.get();
			method = tst_.getClass().getDeclaredMethod(stName, new Class[] { String.class, WebDriver.class, WebDriver.class,
				SearchContext.class, LoggingPreferences.class });
			method.setAccessible(true);
			tst_.state = state;
			tst_.___cxt___ = ___cxt___;
			System.out.println("Executing overriden method " + stName);
			try {
				return (List<WebElement>) method.invoke(tst_, new Object[] { __sfname__, ___cw___, ___ocw___, ___sc___1, ___lp___ });
			} catch (InvocationTargetException e) {
				if(e.getCause() instanceof RestartsubtestException) {
					___cxt___.unRestartSubtest();
					return ___invoke_sub_test_dyn___(claz, stName, __sfname__, ___cw___, ___ocw___, ___sc___1, ___lp___);
				} else {
					throw e.getCause();
				}
			}
		} else {
			method.setAccessible(true);
			try {
				return (List<WebElement>) method.invoke(this, new Object[] { __sfname__, ___cw___, ___ocw___, ___sc___1, ___lp___ });
			} catch (RestartsubtestException e) {
				___cxt___.unRestartSubtest();
				return ___invoke_sub_test_dyn___(claz, stName, __sfname__, ___cw___, ___ocw___, ___sc___1, ___lp___);
			} catch (InvocationTargetException e) {e.printStackTrace();
				if(e.getCause() instanceof RestartsubtestException) {
					___cxt___.unRestartSubtest();
					return ___invoke_sub_test_dyn___(claz, stName, __sfname__, ___cw___, ___ocw___, ___sc___1, ___lp___);
				} else {
					throw e.getCause();
				}
			}
		}
	}
	
	public abstract List<SeleniumTestSession> execute(LoggingPreferences ___lp___, String outPath) throws Exception;

	/*protected boolean checkifSessionIdExistsInSet(Set<String> st, String sname, String sid) {
        if(sname==null && sid==null)return true;
        if(sname!=null && st.contains(sname))return true;
        if(sid!=null && st.contains(sid))return true;
        return false;
    }*/

	public static class SeleniumTestResult implements Serializable {
		private static final long serialVersionUID = 1L;

		private Map<String, SerializableLogEntries> logs = new HashMap<String, SerializableLogEntries>();

		private boolean status;

		private boolean isContinue;

		long executionTime;

		String stName;
		
		String stImg;
		
		int line;
		
		transient Throwable cause;

		private Map<String, Object[]> internalTestRes = new HashMap<String, Object[]>();

		/** Q9/Q10: budget + security results from the trace (report sidecar); null when not checked. */
		private transient Map<String, Object> checks;

		/** M2: soft ({@code ??~}) failures recorded while this script / subtest ran. */
		private int softFailures;

		public int getSoftFailures() {
			return softFailures;
		}

		/** M6: skip | fixme | only when this subtest was not run (reported as skipped), else null. */
		private String skipReason;

		public String getSkipReason() {
			return skipReason;
		}

		/** M6: a subtest that was not run: passes the script, reported as skipped with its reason. */
		static SeleniumTestResult skipped(SeleniumTest test, String reason) {
			SeleniumTestResult r = new SeleniumTestResult(test.getSession(), test);
			r.skipReason = reason;
			List<LogEntry> entries = new ArrayList<LogEntry>();
			entries.add(new LogEntry(Level.ALL, new Date().getTime(), skipMessage(reason)));
			r.logs.put("gatf", new SerializableLogEntries(entries));
			return r;
		}

		/** M6: report text for a skipped subtest. */
		public static String skipMessage(String reason) {
			return "fixme".equals(reason) ? "Skipped (fixme)" : "only".equals(reason) ? "Skipped (another subtest is marked only)" : "Skipped";
		}

		private SeleniumTestResult(SeleniumTestSession s, SeleniumTest test) {
			this.status = true;
			this.isContinue = true;
			this.stName = test.get__subtestname__();
			this.line = test.state.line;
			this.internalTestRes = s.internalTestRs;
		}

		public Map<String, Object> getChecks() {
			return checks;
		}
		/** M9/M10: files attached by steps (visual diff, accessibility results), absolute paths. */
		private transient List<String> attachments = new ArrayList<String>();
		public List<String> getAttachments() {
			return attachments == null ? new ArrayList<String>() : attachments;
		}
		public void setChecks(Map<String, Object> checks) {
			this.checks = checks;
		}
		/** Q9/Q10: fail an otherwise finished script (budget breach, security findings); the message leads its logs. */
		public void failWith(String message) {
			this.status = false;
			if (this.cause == null) this.cause = new RuntimeException(message);
			List<LogEntry> entries = new ArrayList<LogEntry>();
			entries.add(new LogEntry(Level.ALL, new Date().getTime(), message));
			SerializableLogEntries prev = this.logs.get("gatf");
			if (prev != null) {
				for (SerializableLogEntry e : prev.getAll()) entries.add(new LogEntry(e.getLevel(), e.getTimestamp(), e.getMessage()));
			}
			this.logs.put("gatf", new SerializableLogEntries(entries));
		}

		public Throwable getCause() {
			return cause;
		}
		public Map<String, SerializableLogEntries> getLogs()
		{
			return logs;
		}
		public boolean isStatus()
		{
			return status;
		}
		public long getExecutionTime()
		{
			return executionTime;
		}
		public String getSubtestName()
		{
			return stName;
		}
		public String getSubtestImg()
		{
			return stImg;
		}
		public Map<String,Object[]> getInternalTestRes()
		{
			return internalTestRes;
		}
		public SeleniumTestResult(WebDriver d, SeleniumTest test, LoggingPreferences ___lp___)
		{
			this.attachments = test.drainAttachments();
			this.stName = test.get__subtestname__();
			this.status = true;
			this.internalTestRes = test.getSession().internalTestRs;
			this.line = test.state.line;
			// M2: a script / subtest that recorded soft failures ends failed, listing every one
			List<String> soft = test.__soft__.drain();
			if(!soft.isEmpty()) {
				this.softFailures = soft.size();
				this.status = false;
				this.cause = new SoftFailures.SoftAssertionError(soft);
			}
		}
		public SeleniumTestResult(WebDriver d, SeleniumTest test, Throwable exc, String img, LoggingPreferences ___lp___, String subTestName) {
			this.attachments = test.drainAttachments();
			this.cause = exc;
			this.status = false;
			// M2: soft failures recorded before this result (a hard failure / pass / warn after soft ones): still counted.
			// A script that ended with soft failures reaches here as FailureException(SoftAssertionError): keep its count.
			List<String> soft = test.__soft__.drain();
			Throwable root = exc instanceof FailureException ? ((FailureException)exc).err : exc;
			this.softFailures = root instanceof SoftFailures.SoftAssertionError ? ((SoftFailures.SoftAssertionError)root).getFailures().size() : soft.size();
			this.isContinue = false;
			this.line = test.state.line;
			this.internalTestRes = test.getSession().internalTestRs;
			this.stName = subTestName;
			// H2 (Δ146): the failing step's DOM after-state goes into the trace before any failure screenshot
			if(!(exc instanceof PassSubTestException) && !(exc instanceof WarnSubTestException)) test.__traceFailure__(exc);
			/*Logs logs = d.manage().logs();
            for (String s : LOG_TYPES_SET) {
                if(!logs.getAvailableLogTypes().contains(s))continue;
                LogEntries logEntries = logs.get(s);
                if(logEntries!=null && !logEntries.getAll().isEmpty()) {
                    this.logs.put(s, new SerializableLogEntries(logEntries.getAll())); 
                }
            }*/
			boolean isPending = false;
			if(cause instanceof GatfRunTimeError) {
				isPending = ((GatfRunTimeError)cause).pending;
				if(isPending) {
					if(cause instanceof XPathException && ((XPathException)cause).details!=null && ((XPathException)cause).details.length>0) {
						//System.out.println("Invalid xpath expression provided, check if your xpath expression contains spaces and use single quotes(') instead of double quotes(\") for your xpath expressions");
					} else {
						String relName = test.state.cfileName.replace(test.state.basePath, "");
					    if(relName.startsWith(File.separator)) {
					    	relName = relName.substring(1);
			        	}
					    String cmd = "";
						try {
							cmd = Files.readAllLines(Paths.get(test.state.cfileName)).get(test.state.line-1);
						} catch (Exception e) {
						}
						((GatfRunTimeError)cause).details = new Object[] {cmd, test.state.line, relName, cause.getMessage()};
					}
					((GatfRunTimeError)cause).pending = false;
					((GatfRunTimeError)cause).img = img;
				}
			}
			if(cause instanceof PassSubTestException || cause instanceof WarnSubTestException) {
				this.status = cause instanceof PassSubTestException;
				this.isContinue = true;

				if(cause instanceof WarnSubTestException && test.___cxt___.getGatfExecutorConfig().getWaitOnWarnException()>0)
				{
					long cnt = test.___cxt___.getGatfExecutorConfig().getWaitOnWarnException();
					while(cnt>0) {
						if(test.___cxt___.isStopExecSet()) {
							throw new RuntimeException("Stopped Execution");
						}
						try {
							Thread.sleep(1000);
							cnt -= 1000;
						} catch(Exception e){}
						if(test.___cxt___.isRestartSubtest()) {
							throw new RestartsubtestException();
						}
					}
				}

				this.stName = test.get__subtestname__();
				List<LogEntry> entries = new ArrayList<LogEntry>();
				entries.add(new LogEntry(Level.ALL, new Date().getTime(), cause.getMessage()));
				this.logs.put("gatf", new SerializableLogEntries(entries));
				if(isPending) System.out.println(cause.getMessage());
			} else if(cause instanceof FailSubTestException || cause instanceof SubTestException) {
				this.isContinue = false;
				if(test.___cxt___.getGatfExecutorConfig().getWaitOnFailException()>0)
				{
					long cnt = test.___cxt___.getGatfExecutorConfig().getWaitOnFailException();
					while(cnt>0) {
						if(test.___cxt___.isStopExecSet()) {
							throw new RuntimeException("Stopped Execution");
						}
						try {
							Thread.sleep(1000);
							cnt -= 1000;
						} catch(Exception e){}
						if(test.___cxt___.isRestartSubtest()) {
							throw new RestartsubtestException();
						}
					}
				}
				this.stName = test.get__subtestname__();
				List<LogEntry> entries = new ArrayList<LogEntry>();
				entries.add(new LogEntry(Level.ALL, new Date().getTime(), cause.getMessage()));
				entries.add(new LogEntry(Level.ALL, new Date().getTime(), ExceptionUtils.getStackTrace(cause)));
				this.logs.put("gatf", new SerializableLogEntries(entries));
				if(isPending) {
					if(cause instanceof FailSubTestException) {
						System.out.println("Error occurred on line no " + line);
						if(cause.getMessage().contains("no such window: target window already closed")) {
							java.lang.System.out.println("no such window: target window already closed");
						} else {
							cause.printStackTrace();
						}
					} else {
						System.out.println(cause.getMessage());
					}
					try {
						stImg = img;
						java.lang.System.out.println(img);
						screenshotAsFile(d, img);
						if (d instanceof JavascriptExecutor) {
							((JavascriptExecutor)d).executeScript("window.scrollTo(0,0)");
						}
					} catch (Exception e) {
					}
				}
			} else {
				this.stName = test.get__subtestname__();
				List<LogEntry> entries = new ArrayList<LogEntry>();
				if(cause instanceof RuntimeException) {
					if(cause.getCause()!=null) {
						if(subTestName!=null) {
							stImg = ((SubTestException)cause.getCause()).img;
							entries.add(new LogEntry(Level.ALL, new Date().getTime(), "Subtest " + subTestName + " Failed"));
						} else {
							entries.add(new LogEntry(Level.ALL, new Date().getTime(), cause.getMessage()));
							entries.add(new LogEntry(Level.ALL, new Date().getTime(), ExceptionUtils.getStackTrace(cause)));
						}
					} else {
						entries.add(new LogEntry(Level.ALL, new Date().getTime(), cause.getMessage()));
						entries.add(new LogEntry(Level.ALL, new Date().getTime(), ExceptionUtils.getStackTrace(cause)));
					}
				} else {
					entries.add(new LogEntry(Level.ALL, new Date().getTime(), cause.getMessage()));
					entries.add(new LogEntry(Level.ALL, new Date().getTime(), ExceptionUtils.getStackTrace(cause)));
				}
				if(isPending) {
					try {
						stImg = img;
						System.out.println("Error occurred on line no " + line);
						if(cause.getMessage().contains("no such window: target window already closed")) {
							java.lang.System.out.println("no such window: target window already closed");
						} else if(cause.getMessage().contains("is not a valid XPath expression")) {
							java.lang.System.out.println("Invalid xpath expression provided, check if your xpath expression contains spaces and use single quotes(') instead of double quotes(\") for your xpath expressions");
						} else {
							cause.printStackTrace();
							java.lang.System.out.println(img);
							screenshotAsFile(d, img);
						}
					} catch (Exception e) {
					}
				} else if(cause instanceof RuntimeException) {
					cause.printStackTrace();
				}
				this.logs.put("gatf", new SerializableLogEntries(entries));
			}
			if(!soft.isEmpty()) {
				if(cause instanceof PassSubTestException || cause instanceof WarnSubTestException) {
					// M2: pass / warn cannot clear earlier soft failures: the (sub)test fails listing them
					this.status = false;
					this.isContinue = false;
					this.cause = new SoftFailures.SoftAssertionError(soft);
					failWith(cause.getMessage());
				} else {
					// M2: a hard failure after soft ones: the soft messages follow the hard error in the logs
					SerializableLogEntries prev = this.logs.get("gatf");
					List<LogEntry> entries = new ArrayList<LogEntry>();
					if(prev != null) for (SerializableLogEntry e : prev.getAll()) entries.add(new LogEntry(e.getLevel(), e.getTimestamp(), e.getMessage()));
					entries.add(new LogEntry(Level.ALL, new Date().getTime(), SoftFailures.message(soft)));
					this.logs.put("gatf", new SerializableLogEntries(entries));
				}
			}
		}
		public SeleniumTestResult(SeleniumTest test, Throwable cause) {
			this.cause = cause;
			this.status = false;
			this.softFailures = test.__soft__.drain().size();
			this.stName = test.get__subtestname__();
			this.line = test.state.line;
			this.internalTestRes = test.getSession().internalTestRs;
			if(cause instanceof GatfRunTimeError) {
				String relName = test.state.cfileName.replace(test.state.basePath, "");
			    if(relName.startsWith(File.separator)) {
			    	relName = relName.substring(1);
	        	}
			    String cmd = "";
				try {
					cmd = Files.readAllLines(Paths.get(test.state.cfileName)).get(test.state.line-1);
				} catch (Exception e) {
				}
				((GatfRunTimeError)cause).details = new Object[] {cmd, test.state.line, relName, cause.getMessage()};
			}
			System.out.println("Error occurred on line no " + line);
			List<LogEntry> entries = new ArrayList<LogEntry>();
			entries.add(new LogEntry(Level.ALL, new Date().getTime(), cause.getMessage()));
			entries.add(new LogEntry(Level.ALL, new Date().getTime(), ExceptionUtils.getStackTrace(cause)));
			this.logs.put("gatf", new SerializableLogEntries(entries));
		}
	}
	
	protected void sendKeys(WebDriver driver, WebElement le, String type, String qualifier, String tvalue) {
		awaitActionable(driver, le, Actionability.modeFor(type, tvalue));
		sendKeys(type, qualifier, driver, le, tvalue, ___cxt___, state.name);
	}
	
	protected static String randomize(String tvalue) {
		return RandomValues.randomize(tvalue);   // G8: moved to RandomValues
	}

	protected static void sendKeys(String type, String qualifier, WebDriver wd, WebElement le, String tvalue, AcceptanceTestContext ___cxt___, String name) {
		if(type.equalsIgnoreCase("randomize")) {
			if ((le.getTagName().toLowerCase().matches("input") /*&& le.get(0).getDomProperty("type").toLowerCase().matches("text|url|email|hidden")*/)
					|| (le.getTagName().toLowerCase().matches("textarea"))) {
				String randomVal = randomize(tvalue);
				le.sendKeys(randomVal);
				jsEvent(wd, le, qualifier);
			} /*else if (le.get(0).getTagName().toLowerCase().matches("input") && le.get(0).getDomProperty("type").toLowerCase().matches("number")) {
				long min = 0;
				long max = 99999;
				if(StringUtils.isNotBlank(v1)) {
					try {
						min = Long.parseLong(v1);
					} catch (Exception e) {
					}
				}
				if(StringUtils.isNotBlank(v2)) {
					try {
						max = Long.parseLong(v2);
					} catch (Exception e) {
					}
				}
				long num = (long)(min + (Math.random() * (max - min)));
				le.get(0).sendKeys(num+"");
			}*/ else if (le.getTagName().toLowerCase().matches("select")) {
				randomizeSelect(le);
			} else if (le.getTagName().toLowerCase().matches("input") && le.getDomProperty("type").toLowerCase().matches("checkbox")) {
				le.click();
			} else if (le.getTagName().toLowerCase().matches("input") && le.getDomProperty("type").toLowerCase().matches("radio")) {
				le.click();
			}
		} else {
			if(tvalue.startsWith("file://")) {
				tvalue = resolveFile(tvalue.substring(7), ___cxt___, name);
			}
			le.sendKeys(tvalue);
			jsEvent(wd, le, qualifier);
		}
	}

	protected void window(int pos) {
		if(pos>=0 && pos<getSession().___d___.size()) {
			getSession().__wpos__ = pos;
		} else {
			throw new RuntimeException("Invalid window number specified");
		}
	}

	protected void newWindow(LoggingPreferences lp) {
		try
		{
			Method m = getClass().getMethod("setupDriver"+getSession().browserName, new Class[]{LoggingPreferences.class});
			if(m!=null) {
				m.invoke(this, new Object[]{lp});
			}
			getSession().__wpos__++;
		}
		catch (Exception e)
		{
			throw new RuntimeException("Invalid browser name specified", e);
		}
	}
	
	
	protected void mzoompinch(WebDriver driver, Object ele, int x, int y, boolean isZoom) {
		AppiumTouch.zoom(driver, ele instanceof WebElement ? (WebElement) ele : null, x, y, isZoom, __mwhere__());   // Δ158: W3C touch, errors are step errors
	}
	
	protected void doSwipe(WebDriver driver, Point start, Point end, int duration) {
		AppiumTouch.swipe(driver, start, end, duration, __mwhere__());   // Δ158
	}

	/** Δ158: duration &lt; 0 = none given (100 ms hold); e + point = point offset from e's top-left. */
	protected void doTap(WebDriver driver, WebElement e, Point point, int duration) {
		AppiumTouch.tap(driver, e, point, duration, __mwhere__());
	}

	/** Δ158 (H5): {@code touch …} as one W3C touch source; entries are {action, element, x, y, durationMs}. */
	protected void doTouchChain(WebDriver driver, List<Object[]> steps) {
		AppiumTouch.chain(driver, steps, __mwhere__());
	}

	protected void mobileRotate(WebDriver driver) {
		AppiumTouch.rotate(driver, __mwhere__());
	}

	protected void mobileHideKeypad(WebDriver driver) {
		AppiumTouch.hideKeypad(driver, __mwhere__());
	}

	protected void mobileShake(WebDriver driver) {
		AppiumTouch.shake(driver, __mwhere__());
	}

	/** Δ158 (H5): {@code open appium-android | appium-ios}: local Appium 2, or a real device when GATF_CLOUD is set. */
	protected WebDriver getAppiumDriver(String key, String configUrl, Map<String, String> caps, String version) {
		return AppiumDrivers.create(key, configUrl, caps, version, ___cxt___);
	}

	/** The current statement as file:line (relative to the project), for step errors. */
	protected String __mwhere__() {
		if(state == null || state.cfileName == null) return "";
		String where = state.cfileName.replace(state.basePath == null ? "" : state.basePath, "");
		if(where.startsWith(File.separator) || where.startsWith("/")) where = where.substring(1);
		return where + ":" + state.line;
	}

	protected static void randomizeSelect(WebElement le) {
		RandomValues.randomizeSelect(le);   // G8: moved to RandomValues
	}

	private void pluginsLoad() {
		if (___cxt___ != null) {
			com.gatf.selenium.plugins.sdk.PluginRegistry.loadAndInit(___cxt___.getResourceFile("plugins"), SeleniumTest.class.getClassLoader(), ___cxt___);
		}
	}

	protected Object pluginize(String name, String signature, List<String> args, List<List<String>> args1) {
		try
		{
			// M13: an SDK v2 plugin (plugins/*.jar) runs through its instance; the legacy static form through reflection
			com.gatf.selenium.plugins.sdk.GatfStepPlugin v2 = null;
			if (signature.startsWith("v2:")) {
				v2 = com.gatf.selenium.plugins.sdk.PluginRegistry.get(name);
				if (v2 == null) {
					// a JVM that never compiled the script (debugger, distributed node) loads plugins/ here
					pluginsLoad();
					v2 = com.gatf.selenium.plugins.sdk.PluginRegistry.get(name);
				}
				if (v2 == null) throw new RuntimeException("plugin " + name + " is no longer in plugins/");
			}
			Class<?> cls;
			Method meth = null, meth1 = null;
			boolean twoargs = true;
			if (v2 != null) {
				cls = v2.getClass();
			} else {
				String[] parts = signature.split("@");
				String clsname = parts[0].trim();
				String method = parts[1].trim();

				try {
					cls = Class.forName(clsname, true, com.gatf.selenium.plugins.sdk.PluginRegistry.classLoader());
				} catch (ClassNotFoundException e) {
					pluginsLoad();
					cls = Class.forName(clsname, true, com.gatf.selenium.plugins.sdk.PluginRegistry.classLoader());
				}

				try {
					meth = cls.getMethod(method, new Class[]{String.class, Object[].class});
				} catch (Exception e) {
				}

				if(meth==null) {
					meth = cls.getMethod(method, new Class[]{Object[].class});
					twoargs = false;
				}
			}

			try {
				Method meth2 = cls.getMethod("isValidParams", new Class[]{List.class, List.class});
				Boolean isValid = (Boolean)meth2.invoke(null, new Object[]{args, args1});
				if(isValid!=null && !isValid) {
					throw new RuntimeException("Problem executing plugin, invalid parameters provided " + name);
				}
			} catch (Exception e) {
			}

			Object[] nargs =  new Object[args.size()+3];
			int c = 0;
			int indx = -1;
			for (String arg : args) {
				indx++;

				boolean parameterize = true;
				try {
					meth1 = cls.getMethod("isParameterizeFirstSetParam", new Class[]{String.class, int.class});
					Boolean temp = (Boolean)meth1.invoke(null, new Object[]{arg, indx});
					if(temp!=null && !temp) {
						parameterize = temp;
					}
				} catch (Exception e) {
				}

				if(!parameterize) {
					nargs[c++] = arg.trim();
					continue;
				}

				if(arg.trim().startsWith("${") && arg.trim().endsWith("}")) {
					String vn = arg.trim().substring(2, arg.length()-1);
					nargs[c++] = evaluate(vn);
				} else if(arg.trim().startsWith("$v{") && arg.trim().endsWith("}")) {
					String vn = arg.trim().substring(3, arg.length()-1);
					nargs[c++] = ___get_var__(vn);
				} else if((arg.toLowerCase().trim().startsWith("file://") || arg.toLowerCase().trim().startsWith("http://") 
						|| arg.toLowerCase().trim().startsWith("https://"))) {
					if(arg.toLowerCase().trim().startsWith("file://")) {
						File _f = ___cxt___.getResourceFile(arg.trim().substring(7));
						arg = _f.toURI().toURL().toString();
					}
					nargs[c++] = Resources.toString(new URL(arg), Charset.forName("UTF-8"));
				} else if(arg.toLowerCase().trim().startsWith("$file://") || arg.toLowerCase().trim().startsWith("$http://") 
						|| arg.toLowerCase().trim().startsWith("$https://")) {
					if(arg.toLowerCase().trim().startsWith("file://")) {
						File _f = ___cxt___.getResourceFile(arg.trim().substring(7));
						arg = _f.toURI().toURL().toString();
					}
					String tmpl = Resources.toString(new URL(arg), Charset.forName("UTF-8"));
					tmpl = evaluate(tmpl);
					nargs[c++] = tmpl;
				} else {
					nargs[c++] = arg;
				}
			}

			List<List<Object>> nargs1 = new ArrayList<List<Object>>();
			if(args1!=null) {
				int indx1 = 0;
				int indx2 = -1;
				for (List<String> narg : args1) {
					List<Object> nargs2 = new ArrayList<Object>();
					for (String arg : narg) {
						indx2++;

						boolean parameterize = true;
						try {
							meth1 = cls.getMethod("isParameterizeSecondSetParam", new Class[]{String.class, int.class, int.class});
							Boolean temp = (Boolean)meth1.invoke(null, new Object[]{arg, indx1, indx2});
							if(temp!=null && !temp) {
								parameterize = temp;
							}
						} catch (Exception e) {
						}

						if(!parameterize) {
							nargs2.add(arg.trim());
							continue;
						}

						if(arg.trim().startsWith("${") && arg.trim().endsWith("}")) {
							String vn = arg.trim().substring(2, arg.length()-1);
							nargs2.add(evaluate(vn));
						} else if(arg.trim().startsWith("$v{") && arg.trim().endsWith("}")) {
							String vn = arg.trim().substring(3, arg.length()-1);
							nargs2.add(___get_var__(vn));
						} else if(arg.toLowerCase().trim().startsWith("file://") || arg.toLowerCase().trim().startsWith("http://") 
								|| arg.toLowerCase().trim().startsWith("https://")) {
							if(arg.toLowerCase().trim().startsWith("file://")) {
								File _f = ___cxt___.getResourceFile(arg.trim().substring(7));
								arg = _f.toURI().toURL().toString();
							}
							nargs2.add(Resources.toString(new URL(arg), Charset.forName("UTF-8")));
						} else if(arg.toLowerCase().trim().startsWith("$file://") || arg.toLowerCase().trim().startsWith("$http://") 
								|| arg.toLowerCase().trim().startsWith("$https://")) {
							if(arg.toLowerCase().trim().startsWith("file://")) {
								File _f = ___cxt___.getResourceFile(arg.trim().substring(7));
								arg = _f.toURI().toURL().toString();
							}
							String tmpl = Resources.toString(new URL(arg), Charset.forName("UTF-8"));
							tmpl = evaluate(tmpl);
							nargs2.add(tmpl);
						} else {
							nargs2.add(arg);
						}

						indx1++;
					}
					nargs1.add(nargs2);
				}

				indx1++;
			}

			nargs[c++] = nargs1;
			nargs[c++] = state.index==-1?0:state.index;
			nargs[c++] = ___cxt___;

			// Q8: api/curl calls share the browser session (cookies) while the plugin runs
			WebDriver bridgeDriver = null;
			try {
				bridgeDriver = get___d___();
			} catch (Exception e) {
				// no browser session open yet
			}
			com.gatf.executor.core.SessionBridge.Bridge prevBridge = BrowserSession.enter(bridgeDriver,
					___cxt___!=null && ___cxt___.getGatfExecutorConfig()!=null ? ___cxt___.getGatfExecutorConfig().getBrowserApiSession() : null,
					___cxt___!=null && ___cxt___.getGatfExecutorConfig()!=null ? ___cxt___.getGatfExecutorConfig().getBrowserApiStorageToken() : null,
					___cxt___!=null && ___cxt___.getGatfExecutorConfig()!=null ? ___cxt___.getGatfExecutorConfig().getBrowserApiStorageTokenHosts() : null);
			try {
				if (v2 != null) {
					List<Object> inline = new ArrayList<Object>(java.util.Arrays.asList(nargs).subList(0, args.size()));
					return v2.execute(new com.gatf.selenium.plugins.sdk.GatfStepPlugin.Call(name, inline, nargs1, state.index==-1?0:state.index, ___cxt___));
				}
				return meth.invoke(null, twoargs?new Object[]{name, nargs}:new Object[]{nargs});
			} finally {
				com.gatf.executor.core.SessionBridge.restore(prevBridge);
			}
		}
		catch (Exception e)
		{
			throw new RuntimeException("Problem executing plugin " + name, e);
		}
	}

	public class SelFunc<T, R> implements Function<T, R> {
		Object[] ____wi = new Object[2];

		@Override
		public R apply(T t) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	protected static List<WebElement> ByJquerySelector(WebDriver d, String finder) {
		if (d instanceof JavascriptExecutor) {
		    return (List<WebElement>)((JavascriptExecutor)d).executeScript("return $(arguments[0]).get()", finder);
		} else {
		    throw new IllegalStateException("This driver cannot run JavaScript.");
		}
	}
	
	protected static List<WebElement> getElements(WebDriver d, SearchContext sc, String finder, List<WebElement> ce) {
		return getElements(d, sc, finder, null, null, ce);
	}

	@SuppressWarnings({ "unchecked" })
	protected static List<WebElement> getElements(WebDriver d, SearchContext sc, String finder, String finder1, String relative, List<WebElement> ce) {
		finder = finder.trim();
		String by = finder.indexOf("@")!=-1?finder.substring(0, finder.indexOf("@")).trim():finder;
		if(by.charAt(0)==by.charAt(by.length()-1)) {
			if(by.charAt(0)=='"' || by.charAt(0)=='\'') {
				by = by.substring(1, by.length()-1);
			}
		}
		
		String classifier = finder.indexOf("@")!=-1?finder.substring(finder.indexOf("@")+1).trim():"";
		if(!classifier.isEmpty() && classifier.charAt(0)==classifier.charAt(classifier.length()-1)) {
			if(classifier.charAt(0)=='"' || classifier.charAt(0)=='\'') {
				classifier = classifier.substring(1, classifier.length()-1);
			}
		}
		
		if(by.equalsIgnoreCase("this") || by.equalsIgnoreCase("current")) {
			return ce;
		} else if(by.equalsIgnoreCase("active")) {
			return new ArrayList<WebElement>(){{add(d.switchTo().activeElement());}};
		} else if(classifier.trim().isEmpty()) {
			throw new RuntimeException("Invalid element selector specified " + finder);
		}
		
		List< WebElement> el = null;
		if(SemanticLocators.isSemantic(by, classifier)) {
			el = semanticElements(d, sc, by, classifier);
		} else if(by.equalsIgnoreCase("id")) {
			el = By.id(classifier).findElements(sc);
		} else if(by.equalsIgnoreCase("name")) {
			el = By.name(classifier).findElements(sc);
		} else if(by.equalsIgnoreCase("class") || by.equalsIgnoreCase("className")) {
			el = By.className(classifier).findElements(sc);
		} else if(by.equalsIgnoreCase("tag") || by.equalsIgnoreCase("tagname")) {
			el = By.tagName(classifier).findElements(sc);
		} else if(by.equalsIgnoreCase("xpath")) {
			el = By.xpath(classifier).findElements(sc);
			if(el==null || el.size()==0) {
				Object ctxt = null;
				if(sc instanceof WebElement) {
					ctxt = sc;
				}
				if (d instanceof JavascriptExecutor) {
					el = (List<WebElement>)((JavascriptExecutor)d).executeScript("return window.GatfUtil.findByXpath(arguments[0], arguments[1])", classifier, ctxt);
				}
			}
		} else if(by.equalsIgnoreCase("cssselector") || by.equalsIgnoreCase("css")) {
			el = By.cssSelector(classifier).findElements(sc);
		} else if(by.equalsIgnoreCase("text")) {
			el = By.xpath("//*[contains(text(), '" + classifier+"')]").findElements(sc);
		} else if(by.equalsIgnoreCase("linkText")) {
			el = By.linkText(classifier).findElements(sc);
		} else if(by.equalsIgnoreCase("partialLinkText")) {
			el = By.partialLinkText(classifier).findElements(sc);
		} else if(by.equalsIgnoreCase("jq") || by.equalsIgnoreCase("jquery") || by.equalsIgnoreCase("$")) {
			el = ByJquerySelector(d, classifier);
		}
		
		if(el!=null && el.size()>0 && relative!=null && finder1!=null) {
			switch (relative) {
				case "leftof":
					el = RelativeLocator.with(getBy(d, finder1)).toLeftOf(el.get(0)).findElements(sc);
					break;
				case "rightof":
					el = RelativeLocator.with(getBy(d, finder1)).toRightOf(el.get(0)).findElements(sc);
					break;
				case "above":
					el = RelativeLocator.with(getBy(d, finder1)).above(el.get(0)).findElements(sc);
					break;
				case "below":
					el = RelativeLocator.with(getBy(d, finder1)).below(el.get(0)).findElements(sc);
					break;
				case "near":
					el = RelativeLocator.with(getBy(d, finder1)).near(el.get(0)).findElements(sc);
					break;
				default:
					break;
			}
		}
		return el;
	}
	
	/** M3: {testIdAttribute, strict ("true"/"false")} for this thread's script; refreshed on every element search. */
	private static final ThreadLocal<String[]> SEMANTIC_OPTS = new ThreadLocal<String[]>();
	/** M3: set around a loop's / transient provider's find: a strict semantic locator may match many there. */
	private static final ThreadLocal<Boolean> SEMANTIC_MULTI = new ThreadLocal<Boolean>();

	private void setSemanticOpts() {
		GatfExecutorConfig c = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		SEMANTIC_OPTS.set(new String[] { c == null ? null : c.getTestIdAttribute(), String.valueOf(c != null && c.strictLocatorsEnabled()) });
	}

	/** M3: drops this thread's semantic options (end of a run / setup script). */
	public static void clearSemanticOpts() {
		SEMANTIC_OPTS.remove();
		SEMANTIC_MULTI.remove();
	}

	/** M3: generated code brackets a loop's find with {@code semanticMulti(true)} / {@code semanticMulti(false)}. */
	protected static void semanticMulti(boolean on) {
		if (on) SEMANTIC_MULTI.set(Boolean.TRUE); else SEMANTIC_MULTI.remove();
	}

	/** M3: resolve a semantic locator in the page (see {@link SemanticLocators}); strict mode fails on more than one match. */
	@SuppressWarnings("unchecked")
	protected static List<WebElement> semanticElements(WebDriver d, SearchContext sc, String by, String classifier) {
		if(!(d instanceof JavascriptExecutor)) {
			throw new IllegalStateException("Semantic locator " + by + "@" + classifier + " needs a driver that can run JavaScript");
		}
		String[] opts = SEMANTIC_OPTS.get();
		String tid = opts != null && StringUtils.isNotBlank(opts[0]) ? opts[0] : SemanticLocators.DEFAULT_TEST_ID_ATTRIBUTE;
		boolean strict = opts != null && "true".equals(opts[1]);
		Object root = sc instanceof WebElement ? sc : null;
		Object r = ((JavascriptExecutor)d).executeScript(SemanticLocators.RESOLVER_JS, root, SemanticLocators.parse(by, classifier), tid);
		if(!(r instanceof Map)) return new ArrayList<WebElement>();
		Map<String, Object> m = (Map<String, Object>)r;
		List<WebElement> els = m.get("els") instanceof List ? new ArrayList<WebElement>((List<WebElement>)m.get("els")) : new ArrayList<WebElement>();
		if(strict && els.size() > 1 && !Boolean.TRUE.equals(SEMANTIC_MULTI.get())) {
			int count = m.get("count") instanceof Number ? ((Number)m.get("count")).intValue() : els.size();
			throw new SemanticLocators.StrictViolation(SemanticLocators.strictViolation(by + "@" + classifier, SemanticLocators.strings(m.get("desc")), count));
		}
		return els;
	}

	private static By getBy(WebDriver d, String finder) {
		finder = finder.trim();
		String by = finder.substring(0, finder.indexOf("@")).trim();
		if(by.charAt(0)==by.charAt(by.length()-1)) {
			if(by.charAt(0)=='"' || by.charAt(0)=='\'') {
				by = by.substring(1, by.length()-1);
			}
		}
		String classifier = finder.substring(finder.indexOf("@")+1).trim();
		if(classifier.charAt(0)==classifier.charAt(classifier.length()-1)) {
			if(classifier.charAt(0)=='"' || classifier.charAt(0)=='\'') {
				classifier = classifier.substring(1, classifier.length()-1);
			}
		}
		By el = null;
		if(by.equalsIgnoreCase("id")) {
			el = By.id(classifier);
		} else if(by.equalsIgnoreCase("name")) {
			el = By.name(classifier);
		} else if(by.equalsIgnoreCase("class") || by.equalsIgnoreCase("className")) {
			el = By.className(classifier);
		} else if(by.equalsIgnoreCase("tag") || by.equalsIgnoreCase("tagname")) {
			el = By.tagName(classifier);
		} else if(by.equalsIgnoreCase("xpath")) {
			el = By.xpath(classifier);
		} else if(by.equalsIgnoreCase("cssselector") || by.equalsIgnoreCase("css")) {
			el = By.cssSelector(classifier);
		} else if(by.equalsIgnoreCase("text")) {
			el = By.xpath("//*[contains(text(), '" + classifier+"')]");
		} else if(by.equalsIgnoreCase("linkText")) {
			el = By.linkText(classifier);
		} else if(by.equalsIgnoreCase("partialLinkText")) {
			el = By.partialLinkText(classifier);
		}
		return el;
	}
	
	//Unused for now....does not work correctly--- use wopensave instead
	/**
	 * `printpdf <file> [text [colsep]]`: writes the current page as a PDF to {@code file}. With {@code text}, it also
	 * extracts the text and tables (PDFBox) to {@code <file>.txt} and makes them available via {@link #pdfTable(String)}.
	 * <ul>
	 *  <li>A page showing a {@code blob:} document (e.g. a PDF opened in the viewer) saves the document bytes
	 *      themselves, not a print of the viewer.</li>
	 *  <li>Otherwise the page is printed via {@link com.gatf.selenium.trace.Transports#printPdf}: raw CDP, else BiDi,
	 *      else W3C print. That works on Chromium, Firefox, Edge and Grid, with no pinned devtools version.</li>
	 *  <li>Failures fail the step. The old code swallowed every exception, leaked its streams, was pinned to CDP v150,
	 *      and wrote the blob branch through a UTF-8 String, which corrupted binary PDFs.</li>
	 * </ul>
	 */
	protected void printToPdf(WebDriver pdr, String filePath, boolean extractText, String colsep) {
		byte[] pdf = null;
		String cur = null;
		try {
			cur = pdr.getCurrentUrl();
		} catch (Exception e) {
			// no current URL (closed/switching window): fall through to printing
		}
		if (cur != null && cur.startsWith("blob:")) {
			String b64 = readBlob(pdr, cur);
			if (b64 != null && !b64.equals(cur)) {
				pdf = Base64.getDecoder().decode(b64.substring(b64.indexOf(',') + 1).trim());
			}
		}
		if (pdf == null) {
			pdf = com.gatf.selenium.trace.Transports.printPdf(pdr);
		}
		if (pdf == null || pdf.length == 0) {
			throw new RuntimeException("printpdf: this browser session cannot print to PDF (CDP Page.printToPDF, BiDi browsingContext.print and W3C print are all unavailable)");
		}
		File out = new File(filePath);
		try {
			if (out.getParentFile() != null) {
				out.getParentFile().mkdirs();
			}
			java.nio.file.Files.write(out.toPath(), pdf);
		} catch (IOException e) {
			throw new RuntimeException("printpdf: cannot write " + out.getAbsolutePath(), e);
		}
		if (extractText) {
			extractTextFromPdf(out.getPath(), StringUtils.isBlank(colsep) ? "|" : colsep, 0, 0);
		}
	}
	
	protected static List<List<Map<String, String>>> pdfTable(String filePath) {
		String fk = DigestUtils.sha256Hex(filePath+".txt");
		if(_pdtTables.containsKey(fk)) {
			return _pdtTables.get(fk);
		}
		return new ArrayList<List<Map<String, String>>>();
	}
	@SuppressWarnings("rawtypes")
	/**
	 * 
	 * @param filePath
	 * @param colSep
	 * @param headerMode
	 * @param skippages
	 * 
	 * headerMode = 0 -> Table wise header
	 * headerMode = 1 -> Single header found on the first table across all pages
	 * headerMode = 2 -> No headers enabled
	 */
	protected static void extractTextFromPdf(String filePath, String colSep, int headerMode, int skippages) {
		PdfTables.extractTextFromPdf(filePath, colSep, headerMode, skippages);   // G8: moved to PdfTables
	}

	protected void windowOpenSaveJsPre(WebDriver driver, int optionalOpenNums) {
		if (!(driver instanceof JavascriptExecutor)) {
		    throw new IllegalStateException("This driver cannot run JavaScript.");
		}
		try {
			initJs(driver);
			System.out.println("Window open intercept added for " + optionalOpenNums + " window(s)....");
			//((JavascriptExecutor)driver).executeScript("window.__wostn__="+optionalOpenNums+";window.__wosjp__=[];window.open=function(a,b,c){window.__wosjp__.push([a,b,c]);window.__owo__(a,b,c);console.log(a);}");
			((JavascriptExecutor)driver).executeScript("window.GatfUtil.wopensaveInit("+optionalOpenNums+")");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void windowOpenSaveJsPost(WebDriver driver, String filePath, boolean extractText, int openPos, String colsep) {
		if (!(driver instanceof JavascriptExecutor)) {
		    throw new IllegalStateException("This driver cannot run JavaScript.");
		}
		HttpClient client = null;
		try {
			//String url = (String)((JavascriptExecutor)driver).executeScript("if("+openPos+"<window.__wosjp__.length) return window.__wosjp__["+openPos+"]; else return 'FAIL';");
			String url = (String)((JavascriptExecutor)driver).executeScript("return window.GatfUtil.wopensaveFetch("+openPos+")");
			int counter = 0;
			while((StringUtils.isBlank(url) || "FAIL".equals(url)) && counter++<60) {
				System.out.println("Waiting for `wopensave` download URL... attempt " + counter);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				}
				//url = (String)((JavascriptExecutor)driver).executeScript("if("+openPos+"<window.__wosjp__.length) return window.__wosjp__["+openPos+"]; else return 'FAIL';");
				url = (String)((JavascriptExecutor)driver).executeScript("return window.GatfUtil.wopensaveFetch("+openPos+")");
			}
			if(StringUtils.isBlank(url) || "FAIL".equals(url)) {
				throw new RuntimeException("Invalid window.open url found");
			}
			Long optionalOpenNum = (Long)((JavascriptExecutor)driver).executeScript("return window.GatfUtil.__wostn__");
			Long foundOpenNum = (Long)((JavascriptExecutor)driver).executeScript("return window.GatfUtil.__wosjp__.length");
			try {
				if(foundOpenNum<openPos) {
					throw new RuntimeException("Not all window.open's have fired, only "+foundOpenNum+" fired out of " + optionalOpenNum + ", requested " + openPos);
				}
			} catch (Exception e) {
			}
			System.out.println("Window open intercept got url [" + url + "] for window " + openPos);
			client = TestCaseExecutorUtil.getClient();
			new File(filePath).delete();
			if(url.startsWith("blob:")) {
				String data = (String)((JavascriptExecutor)driver).executeScript("return await window.GatfUtil.wopenBlobToBase64('"+url+"')");
				data = data.substring(data.indexOf(",")+1);
				IOUtils.write(Base64.getDecoder().decode(data), new FileOutputStream(filePath));
				if(extractText && new File(filePath).exists()) {
					extractTextFromPdf(filePath, colsep, 0, 0);
				}
				return;
			} else if(!url.startsWith("http://") && !url.startsWith("https://")) {
				String burl = driver.getCurrentUrl();
				if(burl.indexOf("#")!=-1) burl = burl.substring(0, burl.indexOf("#"));
				if(burl.indexOf("?")!=-1) burl = burl.substring(0, burl.indexOf("?"));
				if(!burl.trim().endsWith("/")) burl += "/";
				if(url.trim().startsWith("/")) url = url.substring(1);
				url = burl + url;
			}
			HttpResponse<java.io.InputStream> res = client.send(HttpRequest.newBuilder().uri(URI.create(url)).header("Referer", WorkflowContextHandler.getBaseUrl(url)).build(), HttpResponse.BodyHandlers.ofInputStream());
			IOUtils.copy(res.body(), new FileOutputStream(filePath));
			res.body().close();
			if(extractText && new File(filePath).exists()) {
				extractTextFromPdf(filePath, colsep, 0, 0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static String resolveFile(String filePath, AcceptanceTestContext ___cxt___, String relFilePath) {
		if(!new File(filePath).exists()) {
			File upfl = ___cxt___.getResourceFile(filePath, relFilePath);
			if(!upfl.exists()) {
				upfl = new File(System.getProperty("user.dir"), filePath);
				if(!upfl.exists()) {
					throw new RuntimeException("File not found at the given path, please provide a valid file [" + filePath + "]");
				} else {
					filePath = upfl.getAbsolutePath();
				}
			} else {
				filePath = upfl.getAbsolutePath();
			}
		} else {
			filePath = new File(filePath).getAbsolutePath();
		}
		return filePath;
	}

	protected void uploadFile(WebDriver wd, List<WebElement> ret, String filePath, int count) {
		if(ret!=null && !ret.isEmpty()) awaitActionable(wd, ret.get(0), "upload");
		initJs(wd);
		jsFocus(wd, ret.get(0));
		filePath = resolveFile(filePath, ___cxt___, state.name);
		/*if(!new File(filePath).exists()) {
			File upfl = ___cxt___.getResourceFile(filePath);
			if(!upfl.exists()) {
				upfl = new File(System.getProperty("user.dir"), filePath);
				if(!upfl.exists()) {
					throw new RuntimeException("File not found at the given path, please provide a valid file [" + filePath + "]");
				} else {
					filePath = upfl.getAbsolutePath();
				}
			} else {
				filePath = upfl.getAbsolutePath();
			}
		}*/
		
		if(__ctxOf__(wd) != null && wd instanceof org.openqa.selenium.chromium.HasCdp && wd instanceof JavascriptExecutor) {
			// H3: the DevTools session is bound to the script's own tab; inside a per-test context use the current tab's CDP
			org.openqa.selenium.chromium.HasCdp cdp = (org.openqa.selenium.chromium.HasCdp) wd;
			String cssSelctor = (String)((JavascriptExecutor)wd).executeScript("return window.GatfUtil.getCssSelector($(arguments[0]))", ret.get(0));
			Map<String, Object> dom = cdp.executeCdpCommand("DOM.getDocument", new HashMap<String, Object>());
			Map<String, Object> qa = new HashMap<String, Object>();
			qa.put("nodeId", ((Map<?, ?>) dom.get("root")).get("nodeId"));
			qa.put("selector", cssSelctor);
			Map<String, Object> q = cdp.executeCdpCommand("DOM.querySelector", qa);
			List<String> files = new ArrayList<String>();
			for(int i=0;i<Math.max(1, count);i++) files.add(filePath);
			Map<String, Object> sa = new HashMap<String, Object>();
			sa.put("nodeId", q.get("nodeId"));
			sa.put("files", files);
			cdp.executeCdpCommand("DOM.setFileInputFiles", sa);
		} else if(wd instanceof HasDevTools && wd instanceof JavascriptExecutor) {
			DevTools devTools = ((HasDevTools)wd).getDevTools();
			try {
				String cssSelctor = (String)((JavascriptExecutor)wd).executeScript("return window.GatfUtil.getCssSelector($(arguments[0]))", ret.get(0));
				Node node = devTools.send(DOM.getDocument(Optional.empty(), Optional.empty()));
				NodeId nodeId = devTools.send(DOM.querySelector(node.getNodeId(), cssSelctor));
				List<String> files = new ArrayList<String>();
				files.add(filePath);
				for(int i=0;i<count-1;i++) {
					files.add(filePath);
				}
				devTools.send(DOM.setFileInputFiles(files, Optional.of(nodeId), Optional.empty(), Optional.empty()));
				/*Map<String, Object> dom = ((org.openqa.selenium.chrome.ChromeDriver)get___d___()).executeCdpCommand("DOM.getDocument", new HashMap<>());
				Map<String, Object> domqaArgs = new HashMap<>();
				domqaArgs.put("nodeId", ((Map<String, Object>)dom.get("root")).get("nodeId"));
				domqaArgs.put("selector", cssSelctor);
				Map<String, Object> domqs = ((HasDevTools)get___d___()).executeCdpCommand("DOM.querySelector", domqaArgs);
				Map<String, Object> setIfArgs = new HashMap<>();
				setIfArgs.put("nodeId", domqs.get("nodeId"));
				List<String> files = new ArrayList<String>();
				files.add(filePath);
				for(int i=0;i<count-1;i++) {
					files.add(filePath);
				}
				setIfArgs.put("files", files);
				((org.openqa.selenium.chrome.ChromeDriver)get___d___()).executeCdpCommand("DOM.setFileInputFiles", setIfArgs);*/
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			if(count>1) {
				throw new RuntimeException("Multi File uploads only supported with devtools supported browsers for now");
			}
			ret.get(0).click();
			java.awt.datatransfer.StringSelection ss = new java.awt.datatransfer.StringSelection(filePath);
			java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
			try {
				java.awt.Robot robot21 = new java.awt.Robot();
				//robot21.keyPress(java.awt.event.KeyEvent.VK_ENTER);
				//robot21.keyRelease(java.awt.event.KeyEvent.VK_ENTER);
				robot21.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
				robot21.keyPress(java.awt.event.KeyEvent.VK_V);
				robot21.keyRelease(java.awt.event.KeyEvent.VK_V);
				robot21.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
				robot21.delay(1000);
				robot21.keyPress(java.awt.event.KeyEvent.VK_ENTER);
				robot21.delay(200);
				robot21.keyRelease(java.awt.event.KeyEvent.VK_ENTER);
			} catch (AWTException e) {
			}
		}
		sleep(1000);
	}
	
	private static String getSettingVal(String sessionId, String name) {
		if(DRV_FEATURES.containsKey(sessionId)) {
			if(DRV_FEATURES.get(sessionId).containsKey(name) && DRV_FEATURES.get(sessionId).get(name)!=null) {
				return DRV_FEATURES.get(sessionId).get(name).trim();
			}
		}
		return null;
	}
	
	protected static void addSettingVal(WebDriver wd, String key, String val) {
		String sessionId = getSessionId(wd);
		if(DRV_FEATURES.containsKey(sessionId)) {
			DRV_FEATURES.get(sessionId).put(key, val);
		}
	}
	
	private static boolean isSettingEnabled(String sessionId, String name) {
		return "true".equalsIgnoreCase(getSettingVal(sessionId, name));
	}
	
	private static String getSessionId(WebDriver wd) {
		String sessionId = "";
		if(wd instanceof RemoteWebDriver) {
			sessionId = ((RemoteWebDriver)wd).getSessionId().toString();
		}
		return sessionId;
	}
	
	/** Emit a per-action timeline event into the active trace (no-op when tracing is off). */
	protected void __traceAction__(String type, String detail) {
		__traceAction__(type, detail, null);
	}

	/** H2 (Δ146): as above, with the action's element, which the per-action DOM snapshots mark as the target. */
	protected void __traceAction__(String type, String detail, WebElement target) {
		try {
			SeleniumTestSession s = getSession();
			if (s != null && s.__trace__ != null) s.__trace__.action(type, detail, target);
		} catch (Exception e) {}
	}

	/** H2 (Δ146): the failing step's after-state, before the failure screenshot (no-op when tracing is off). */
	protected void __traceFailure__(Throwable cause) {
		try {
			SeleniumTestSession s = getSession();
			if (s != null && s.__trace__ != null) s.__trace__.failure(cause == null ? null : String.valueOf(cause.getMessage()));
		} catch (Exception e) {}
	}

	/** M5: set by the executor while the loginOnce script runs: no storage-state load, and the state is saved at quit. */
	public static final ThreadLocal<Boolean> LOGIN_ONCE_RUN = new ThreadLocal<Boolean>();

	/** M5: this loginOnce run already cleared the previous state file. */
	private boolean __stateFresh__;

	/** E14: set by the executor while globalSetup runs before loginOnce: the storage state (about to be replaced) is not loaded. */
	public static final ThreadLocal<Boolean> SKIP_STATE_LOAD = new ThreadLocal<Boolean>();

	/** E13: the loginOnce script saved its state before closing its last window (nothing left to save at quit). */
	private boolean __loginOnceSaved__;

	/** E13: emitted before {@code close} in the configured loginOnce script only: saves while the last window is still open. */
	protected void __loginOnceSave__(WebDriver d) {
		GatfExecutorConfig cfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		if(!Boolean.TRUE.equals(LOGIN_ONCE_RUN.get()) || cfg == null || StringUtils.isBlank(cfg.getStorageState())) return;
		try {
			if(d.getWindowHandles().size() > 1) return;   // other windows stay open: the save at quit still finds a page
			System.out.println(BrowserState.save(d, stateFile(cfg.getStorageState().trim())));
			__loginOnceSaved__ = true;
		} catch (Exception e) {
			System.out.println("loginOnce: could not save the storage state before close (" + e.getMessage() + ")");
		}
	}

	/** M5: emitted for {@code state save|load <file>}. */
	protected void __state__(WebDriver d, String op, String file) throws Exception {
		File f = stateFile(file);
		String msg = "save".equals(op) ? BrowserState.save(d, f) : BrowserState.load(d, f);
		__traceAction__("state", msg);
		System.out.println(msg);
	}

	/** M5: a state file: absolute as given, else under the test-case directory (so every script finds the same file). */
	protected File stateFile(String name) {
		File f = new File(name);
		if(f.isAbsolute() || ___cxt___ == null) return f;
		GatfExecutorConfig cfg = ___cxt___.getGatfExecutorConfig();
		File base = new File(cfg.getTestCasesBasePath() == null ? "." : cfg.getTestCasesBasePath());
		if(StringUtils.isNotBlank(cfg.getTestCaseDir())) base = new File(base, cfg.getTestCaseDir());
		return new File(base, name);
	}

	/**
	 * M8/M11: the protocol channel for emulate / clock: CDP when the driver speaks it (local Chromium), else the
	 * session's WebDriver BiDi socket (Firefox, Grid sessions; codegen asks for webSocketUrl when a script emulates).
	 */
	protected com.gatf.selenium.emulation.Emulation.Channel protocolChannel(WebDriver d, String what) {
		if (d instanceof org.openqa.selenium.chromium.HasCdp) {
			final org.openqa.selenium.chromium.HasCdp cdp = (org.openqa.selenium.chromium.HasCdp) d;
			return new com.gatf.selenium.emulation.Emulation.Channel() {
				public boolean cdp() { return true; }
				public Map<String, Object> send(String method, Map<String, Object> params) { return cdp.executeCdpCommand(method, params); }
				public String context() { return null; }
				public String origin() { return null; }
				public String userContext() { return __ctxOf__(d); }   // H3: permission grants name the per-test context
			};
		}
		if (com.gatf.selenium.trace.BidiRaw.available(d)) {
			return new com.gatf.selenium.emulation.Emulation.Channel() {
				public boolean cdp() { return false; }
				public Map<String, Object> send(String method, Map<String, Object> params) { return com.gatf.selenium.trace.BidiRaw.send(d, method, params); }
				public String context() { return d.getWindowHandle(); }   // a BiDi browsing-context id is the window handle
				public String userContext() { return __ctxOf__(d); }   // H3: permission grants name the per-test context
				public String origin() {
					try {
						java.net.URI u = java.net.URI.create(d.getCurrentUrl());
						return u.getScheme() != null && u.getScheme().startsWith("http") && u.getHost() != null
								? u.getScheme() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "") : null;
					} catch (RuntimeException e) {
						return null;
					}
				}
			};
		}
		throw new RuntimeException(what + ": this browser session has neither CDP (local Chromium) nor a WebDriver BiDi socket (webSocketUrl)");
	}

	/** M8: permissions granted per driver (CDP replaces the whole set on every grant). */
	private final Map<WebDriver, java.util.Set<String>> __granted__ = new java.util.IdentityHashMap<WebDriver, java.util.Set<String>>();

	/** M8: {@code emulate …} (device, viewport, geolocation, locale, timezone, permissions, colorscheme, offline, network, reset). */
	protected void __emulate__(WebDriver d, String spec) {
		com.gatf.selenium.emulation.Emulation e = com.gatf.selenium.emulation.Emulation.parse(spec);
		com.gatf.selenium.emulation.Devices.Device dev = null;
		if (e.needsDevice()) {
			File custom = state != null && state.basePath != null ? new File(state.basePath, "devices.json") : null;
			dev = com.gatf.selenium.emulation.Devices.find(e.deviceName(), custom);
		}
		String msg;
		try {
			msg = e.apply(dev, protocolChannel(d, "emulate " + e.op), __granted__.computeIfAbsent(d, k -> new java.util.LinkedHashSet<String>()));
		} catch (UnsupportedOperationException x) {
			throw new RuntimeException(x.getMessage(), x);
		}
		__traceAction__("emulate", msg);
		System.out.println(msg);
	}

	/** M11: the per-document clock registration of each driver (to replace / remove it). */
	private final Map<WebDriver, Object[]> __clockPreload__ = new java.util.IdentityHashMap<WebDriver, Object[]>();

	/** M11: {@code clock install [time] | set <time> | fastforward <duration> | uninstall} (see FakeClock). */
	protected void __clock__(WebDriver d, String spec) {
		com.gatf.selenium.emulation.FakeClock c = com.gatf.selenium.emulation.FakeClock.parse(spec);
		if (!(d instanceof JavascriptExecutor)) throw new RuntimeException("clock needs a browser that runs JavaScript");
		JavascriptExecutor js = (JavascriptExecutor) d;
		String msg;
		switch (c.op) {
			case "install": {
				long epoch = c.value != null ? c.value : System.currentTimeMillis();
				String gen = Long.toString(System.nanoTime(), 36);   // tells this installation's carried time from a stale one
				js.executeScript(com.gatf.selenium.emulation.FakeClock.JS + "return window.__gatfClock.install(arguments[0], arguments[1]);", epoch, gen);
				msg = "clock installed at " + java.time.Instant.ofEpochMilli(epoch) + " (paused; due 0 ms timers still run)";
				clockUnregister(d);
				try {
					com.gatf.selenium.emulation.Emulation.Channel ch = protocolChannel(d, "clock");
					com.gatf.selenium.emulation.Emulation.Call call = com.gatf.selenium.emulation.FakeClock.registerPreload(ch.cdp(), epoch, gen, ch.context());
					String id = com.gatf.selenium.emulation.FakeClock.preloadId(ch.cdp(), ch.send(call.method, call.params));
					if (id != null) __clockPreload__.put(d, new Object[] { ch, id });
				} catch (RuntimeException e) {
					msg += " (this document only: " + e.getMessage() + ")";
				}
				break;
			}
			case "uninstall":
				js.executeScript("if (window.__gatfClock) window.__gatfClock.uninstall();");
				clockUnregister(d);
				msg = "clock uninstalled";
				break;
			default: {
				Object on = js.executeScript("return !!(window.__gatfClock && window.__gatfClock.installed());");
				if (!Boolean.TRUE.equals(on)) throw new RuntimeException("clock " + c.op + ": the page has no fake clock (clock install first)");
				if (c.op.equals("set")) {
					js.executeScript("return window.__gatfClock.setSystemTime(arguments[0]);", c.value);
					msg = "clock set to " + java.time.Instant.ofEpochMilli(c.value);
				} else if (c.op.equals("pause") || c.op.equals("resume")) {
					js.executeScript("window.__gatfClock." + c.op + "();");
					msg = c.op.equals("pause") ? "clock paused" : "clock resumed (time follows the real clock)";
				} else {
					// async: promise reactions (await / then) run between timers, as in the real event loop
					java.time.Duration prevTo = null;
					Object ran;
					try {
						try {
							prevTo = d.manage().timeouts().getScriptTimeout();
							if (prevTo == null || prevTo.compareTo(java.time.Duration.ofMinutes(5)) < 0) d.manage().timeouts().scriptTimeout(java.time.Duration.ofMinutes(5));
						} catch (RuntimeException e) {
							prevTo = null;
						}
						ran = js.executeAsyncScript("window.__gatfClock.tickAsync(arguments[0], arguments[arguments.length - 1]);", c.value);
					} catch (org.openqa.selenium.WebDriverException e) {
						if (e instanceof org.openqa.selenium.ScriptTimeoutException) {
							// stop the in-page loop, or it keeps running (and blocks the pump) after the step failed
							try { js.executeScript("if (window.__gatfClock && window.__gatfClock.abort) window.__gatfClock.abort();"); } catch (RuntimeException x) { /* page gone */ }
							throw e;
						}
						String m = String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.ROOT);
						if (!(m.contains("unload") || m.contains("navigat") || m.contains("no such window") || m.contains("detached"))) throw e;
						// a timer navigated away (e.g. a session-timeout redirect): the new page boots at the time reached
						msg = "clock fastforward " + c.value + " ms: a timer navigated away; the next page continues at the time reached";
						__traceAction__("clock", msg);
						System.out.println(msg);
						return;
					} finally {
						if (prevTo != null) {
							try { d.manage().timeouts().scriptTimeout(prevTo); } catch (RuntimeException e) { /* keep going */ }
						}
					}
					if (ran instanceof Map && ((Map<?, ?>) ran).get("error") != null) throw new RuntimeException(String.valueOf(((Map<?, ?>) ran).get("error")));
					Object errs = js.executeScript("return window.__gatfClock.errors();");
					msg = "clock fastforward " + c.value + " ms: " + ran + " timer(s) ran";
					if (errs instanceof List && !((List<?>) errs).isEmpty()) msg += "; timer errors: " + errs;
				}
			}
		}
		__traceAction__("clock", msg);
		System.out.println(msg);
	}

	private void clockUnregister(WebDriver d) {
		Object[] prev = __clockPreload__.remove(d);
		if (prev == null) return;
		com.gatf.selenium.emulation.Emulation.Channel ch = (com.gatf.selenium.emulation.Emulation.Channel) prev[0];
		com.gatf.selenium.emulation.Emulation.Call call = com.gatf.selenium.emulation.FakeClock.unregisterPreload(ch.cdp(), (String) prev[1]);
		try {
			ch.send(call.method, call.params);
		} catch (RuntimeException e) {
			// the tab / session is gone: nothing left to remove
		}
	}

	/** M4: set by codegen when the script uses route/unroute (see addWdm). */
	private boolean __routeBidi__;

	protected void __route_bidi__() {
		__routeBidi__ = true;
	}

	/** M4: the protocol that intercepts for {@code route}: -Dgatf.routeProtocol=cdp|bidi, else traceProtocol, else cdp. */
	private static String __routeProtocol__(GatfExecutorConfig cfg) {
		String rp = System.getProperty("gatf.routeProtocol");
		if(StringUtils.isNotBlank(rp)) return rp.trim().toLowerCase(java.util.Locale.ROOT);
		return cfg != null && cfg.getTraceProtocol() != null ? cfg.getTraceProtocol() : "cdp";
	}

	/** M4: per browser session, {route table, the transport intercepting for it}. */
	private final Map<WebDriver, Object[]> __routes__ = java.util.Collections.synchronizedMap(new java.util.IdentityHashMap<WebDriver, Object[]>());

	/** M4: emitted for {@code route ...} / {@code unroute ...} statements (variables already substituted). */
	protected void __route__(WebDriver d, String statement) {
		com.gatf.selenium.route.RouteSpec.Parsed p = com.gatf.selenium.route.RouteSpec.parse(statement);
		Object[] rs = __routes__.get(d);
		if(rs == null) {
			if("unroute".equals(p.kind)) {
				__traceAction__("route", "unroute: no routes on this session");
				return;
			}
			com.gatf.selenium.route.RouteTable table = new com.gatf.selenium.route.RouteTable();
			GatfExecutorConfig cfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
			// H3: inside a per-test context the intercept is BiDi, scoped to the context's tab (CDP Fetch stays on the
			// script's DevTools tab); with contexts on, a BiDi intercept in the default context is scoped to its tab too
			boolean inCtx = __ctxOf__(d) != null;
			String rproto = inCtx ? "bidi" : __routeProtocol__(cfg);
			String rscope = null;
			if(inCtx || (cfg != null && "subtest".equals(cfg.browserContextMode()))) {
				try { rscope = d.getWindowHandle(); } catch (RuntimeException e) { if(inCtx) throw e; }   // no window: unscoped, as before
			}
			com.gatf.selenium.trace.TraceConfig tc = new com.gatf.selenium.trace.TraceConfig()
					.setProtocol(rproto);
			com.gatf.selenium.trace.BrowserControl bc = com.gatf.selenium.trace.Transports.create(d, tc);
			// a BiDi intercept (whatever transport create() picked) is scoped; CDP refuses a scope, and outside a
			// context CDP Fetch is per tab anyway, so it then intercepts unscoped as before
			boolean on = bc != null && bc.supports(com.gatf.selenium.trace.Capability.ROUTE)
					&& (bc.enableRoutes(table, state.hasNetapixCommand, rscope) || (!inCtx && rscope != null && bc.enableRoutes(table, state.hasNetapixCommand)));
			if(!on) {
				throw new RuntimeException(inCtx ? "route: inside a browser context routes need a WebDriver BiDi session (webSocketUrl)"
						: "route: this browser session cannot intercept requests (needs CDP on Chromium, or a BiDi session: webSocketUrl)");
			}
			rs = new Object[] { table, bc, Boolean.TRUE };
			__routes__.put(d, rs);
		} else if(!"unroute".equals(p.kind) && !Boolean.TRUE.equals(rs[2])) {
			// routes were switched off by `unroute all`: intercept again
			if(!((com.gatf.selenium.trace.BrowserControl) rs[1]).enableRoutes((com.gatf.selenium.route.RouteTable) rs[0], state.hasNetapixCommand)) {
				throw new RuntimeException("route: this browser session cannot intercept requests any more");
			}
			rs[2] = Boolean.TRUE;
		}
		String msg = com.gatf.selenium.route.RouteSpec.apply(p, (com.gatf.selenium.route.RouteTable) rs[0], this::__routeFile__);
		if("unroute".equals(p.kind) && ((com.gatf.selenium.route.RouteTable) rs[0]).size() == 0 && Boolean.TRUE.equals(rs[2])) {
			// no rules left: stop pausing every request
			((com.gatf.selenium.trace.BrowserControl) rs[1]).disableRoutes();
			rs[2] = Boolean.FALSE;
		}
		__traceAction__("route", msg);
		System.out.println(msg);
	}

	/** M4: a file named by a route statement: next to the script, else a test resource. */
	private byte[] __routeFile__(String name) {
		File f = new File(name);
		if(!f.isAbsolute() && state != null && state.cfileName != null) f = new File(new File(state.cfileName).getParentFile(), name);
		if(!f.isFile() && ___cxt___ != null) f = ___cxt___.getResourceFile(name);
		if(f == null || !f.isFile()) throw new IllegalArgumentException("route: file not found: " + name);
		try {
			return java.nio.file.Files.readAllBytes(f.toPath());
		} catch (IOException e) {
			throw new IllegalArgumentException("route: cannot read " + f.getPath() + ": " + e.getMessage());
		}
	}

	/** H3 (Δ153): the per-test browser context scope of each driver (browserContexts=subtest). */
	private final Map<WebDriver, com.gatf.selenium.context.ContextScope> __ctx__ = new java.util.IdentityHashMap<WebDriver, com.gatf.selenium.context.ContextScope>();
	/** H3: the driver whose context the running top-level subtest opened. */
	private WebDriver __ctxDriver__;
	/** H3: set while a skip marker or a simulator check names a subtest: those drive no browser. */
	private boolean __ctxQuiet__;

	private boolean __ctxOn__() {
		GatfExecutorConfig cfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		return cfg != null && "subtest".equals(cfg.browserContextMode());
	}

	/** H3: the open per-test context of {@code d}, or null (the default context). */
	protected String __ctxOf__(WebDriver d) {
		com.gatf.selenium.context.ContextScope s = d == null ? null : __ctx__.get(d);
		return s == null ? null : s.context();
	}

	private com.gatf.selenium.context.ContextScope __ctxScope__(final WebDriver d) {
		com.gatf.selenium.context.ContextScope s = __ctx__.get(d);
		if(s != null) return s;
		com.gatf.selenium.context.ContextMatrix.Decision dec = com.gatf.selenium.context.ContextMatrix.decide(System.getProperty("gatf.contextProtocol"),
				com.gatf.selenium.trace.Transports.hasCdp(d), com.gatf.selenium.trace.BidiRaw.available(d));
		List<com.gatf.selenium.context.ContextOps> ops = new ArrayList<com.gatf.selenium.context.ContextOps>();
		for (String proto : new String[] { dec.protocol, dec.alternate }) {
			if(proto == null) continue;
			try {
				com.gatf.selenium.context.ContextOps o = com.gatf.selenium.trace.Transports.contextOps(d, proto);
				if(o != null) ops.add(o);
			} catch (RuntimeException e) { /* that channel is not usable */ }
		}
		com.gatf.selenium.context.ContextScope.Window w = new com.gatf.selenium.context.ContextScope.Window() {
			public String current() { return d.getWindowHandle(); }
			public void switchTo(String h) { d.switchTo().window(h); }
			public Set<String> handles() { return d.getWindowHandles(); }
		};
		List<com.gatf.selenium.context.ContextScope.Slot> slots = new ArrayList<com.gatf.selenium.context.ContextScope.Slot>();
		slots.add(new com.gatf.selenium.context.ContextScope.Slot() {   // route (Δ127/128)
			public Object stash() { return __routes__.remove(d); }
			public void teardown() {
				Object[] rs = __routes__.remove(d);
				if(rs != null && Boolean.TRUE.equals(rs[2])) ((com.gatf.selenium.trace.BrowserControl) rs[1]).disableRoutes();
			}
			public void restore(Object st) { if(st != null) __routes__.put(d, (Object[]) st); }
			public void drop() {   // removing a BiDi intercept needs no tab: do it even when the context's tab is gone
				Object[] rs = __routes__.remove(d);
				if(rs != null && Boolean.TRUE.equals(rs[2])) ((com.gatf.selenium.trace.BrowserControl) rs[1]).disableRoutes();
			}
		});
		slots.add(new com.gatf.selenium.context.ContextScope.Slot() {   // emulate permission grants (Δ137)
			public Object stash() { return __granted__.remove(d); }
			public void teardown() { __granted__.remove(d); }
			@SuppressWarnings("unchecked")
			public void restore(Object st) { if(st != null) __granted__.put(d, (java.util.Set<String>) st); }
			public void drop() { __granted__.remove(d); }
		});
		slots.add(new com.gatf.selenium.context.ContextScope.Slot() {   // clock preload (Δ138)
			public Object stash() { return __clockPreload__.remove(d); }
			public void teardown() { clockUnregister(d); }
			public void restore(Object st) { if(st != null) __clockPreload__.put(d, (Object[]) st); }
			public void drop() { __clockPreload__.remove(d); }
		});
		s = new com.gatf.selenium.context.ContextScope(ops, w, slots, m -> System.out.println(m));
		if(!dec.supported()) s.warnFallback(dec.reason);
		else if(ops.isEmpty()) s.warnFallback(dec.protocol + " cannot create contexts on this session");
		__ctx__.put(d, s);
		return s;
	}

	/** H3: entering a top-level subtest: a fresh context in the same browser, loaded with the project's storageState. */
	private void __ctxEnter__() {
		if(__ctxQuiet__ || __ctxDriver__ != null || !__ctxOn__() || Boolean.TRUE.equals(LOGIN_ONCE_RUN.get())) return;
		WebDriver d = getSession() == null ? null : get___d___();
		if(d == null) return;
		try {
			String ctx = __ctxScope__(d).open();
			if(ctx == null) return;
			__ctxDriver__ = d;
			BrowserState.userContext(d, ctx);
			__traceAction__("context", "opened " + ctx);
			GatfExecutorConfig cfg = ___cxt___.getGatfExecutorConfig();
			if(StringUtils.isNotBlank(cfg.getStorageState()) && !Boolean.TRUE.equals(SKIP_STATE_LOAD.get())) {
				File sf = stateFile(cfg.getStorageState().trim());
				if(sf.isFile()) System.out.println(BrowserState.load(d, sf));
			}
		} catch (Exception e) {
			System.out.println("browserContexts: " + e.getMessage());
		}
	}

	/** H3: leaving a top-level subtest (pass, fail, timeout or abort): tear down and dispose its context. */
	private void __ctxExit__() {
		WebDriver d = __ctxDriver__;
		if(d == null) return;
		__ctxDriver__ = null;
		BrowserState.userContext(d, null);
		com.gatf.selenium.context.ContextScope s = __ctx__.get(d);
		if(s == null || s.context() == null) return;
		String ctx = s.context();
		s.close();
		try { __traceAction__("context", "closed " + ctx); } catch (Exception e) {}
	}

	/**
	 * H3: the windows a {@code tab} / {@code window} / {@code close others} statement may index: inside a per-test
	 * context only that context's tabs (its own first), else every window as before. Emitted by codegen.
	 */
	protected Set<String> __handles__(WebDriver d) {
		com.gatf.selenium.context.ContextScope s = d == null ? null : __ctx__.get(d);
		return s == null ? d.getWindowHandles() : s.handles();
	}

	/** H3: script end: close every open context and retry any that could not be disposed. */
	private void __ctxCloseAll__() {
		__ctxDriver__ = null;
		BrowserState.userContext(null, null);
		for (com.gatf.selenium.context.ContextScope s : new ArrayList<com.gatf.selenium.context.ContextScope>(__ctx__.values())) {
			try { s.closeAll(); } catch (Exception e) {}
		}
		__ctx__.clear();
	}

	/** M2: soft ({@code ??~}) assertion failures, drained into the next pushed result. */
	final SoftFailures __soft__ = new SoftFailures();
	/** The caller's pending soft failures, set aside while a subtest runs (key: the caller's subtest name). */
	final java.util.Deque<Entry<String, List<String>>> __softStack__ = new java.util.ArrayDeque<Entry<String, List<String>>>();

	/** M2: emitted by codegen around a {@code ??~} statement: record the failure and let the script continue. */
	protected void __soft_fail__(RuntimeException e) {
		if("Stopped Execution".equals(e.getMessage())) throw e;
		String where = "";
		if(state != null && state.cfileName != null) {
			where = state.cfileName.replace(state.basePath == null ? "" : state.basePath, "");
			if(where.startsWith(File.separator)) where = where.substring(1);
			where += ":" + state.line;
		}
		__soft__.add(where, e.getMessage());
		__traceAction__("softfail", e.getMessage());
		System.out.println("Soft assertion failed" + (where.isEmpty() ? "" : " at " + where) + ": " + e.getMessage());
	}

	/** M6: emitted for a subtest call that must not run (skip / fixme marker, or another subtest is marked only). */
	protected void __skip_subtest__(String stname, String sfname, String reason) {
		String prev = get__subtestname__();
		__ctxQuiet__ = true;   // H3: a skipped subtest drives no browser: no context
		try {
			set__subtestname__(stname, sfname);   // clears the not-run placeholder, adds provider details to the name
		} finally {
			__ctxQuiet__ = false;
		}
		try {
			pushResult(SeleniumTestResult.skipped(this, reason));
			System.out.println("Skipped subtest " + get__subtestname__() + " (" + reason + ")");
		} finally {
			reset__subtestname__(prev);
		}
	}

	/** M6: an afterEach / afterAll hook failed after the script had already failed: logged, the first failure is reported. */
	protected void __hook_failed__(String hook, Throwable t) {
		System.out.println(hook + " hook failed: " + t.getMessage());
		__traceAction__("hookfail", hook + ": " + t.getMessage());
	}

	/** E6: soft failures an afterEach / afterAll hook recorded after the failure's result was taken: logged, not charged to the next test. */
	protected void __hook_soft__(String hook) {
		for (String s : __soft__.drain()) System.out.println(hook + " hook soft assertion failed: " + s);
	}

	/** M1: file:line of a statement marked {@code nowait}/{@code <action>!}; its actions skip the auto-wait. */
	private String __nowaitAt__;

	/** M1: emitted by codegen right after __set__cln__ for an opted-out statement. */
	protected void __nowait__() {
		__nowaitAt__ = state == null ? null : state.cfileName + ":" + state.line;
	}

	/** M2: the retry budget for a value assertion, or null when web-first assertions are off (legacy: fail at once)
	 *  or the statement is opted out with {@code nowait}. */
	protected WebFirst.Budget webFirstBudget() {
		GatfExecutorConfig cfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		if (cfg == null || !cfg.webFirstAssertionsEnabled()) return null;
		if (__nowaitAt__ != null && state != null && __nowaitAt__.equals(state.cfileName + ":" + state.line)) return null;
		return new WebFirst.Budget(cfg.effectiveAssertTimeoutMs(), Actionability.SYSTEM_CLOCK);
	}

	/** M1: wait until {@code we} is actionable for {@code mode} (see {@link Actionability}). No-op unless the
	 *  config sets autoWait, for a {@code nowait} statement, or on a driver that cannot run scripts. */
	protected void awaitActionable(WebDriver wd, WebElement we, String mode) {
		GatfExecutorConfig cfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		if (cfg == null || !cfg.autoWaitEnabled() || we == null || !(wd instanceof JavascriptExecutor)) return;
		if (__nowaitAt__ != null && state != null && __nowaitAt__.equals(state.cfileName + ":" + state.line)) return;
		final JavascriptExecutor js = (JavascriptExecutor) wd;
		long waited = Actionability.await(mode, cfg.effectiveActionTimeoutMs(), m -> {
			try {
				Object r = js.executeAsyncScript(Actionability.PROBE_JS, we, m);
				return r == null ? null : String.valueOf(r);
			} catch (org.openqa.selenium.StaleElementReferenceException e) {
				return Actionability.DETACHED;
			} catch (WebDriverException e) {
				return null;   // the probe itself could not run: fall back to the legacy behaviour
			}
		}, Actionability.SYSTEM_CLOCK);
		if (waited > 0) __traceAction__("autowait", mode + " " + waited + "ms");
	}

	protected void clickAction(WebDriver wd, List<WebElement> ret, String qualifier) {
		__traceAction__("click", qualifier, ret!=null && !ret.isEmpty() ? ret.get(0) : null);
		if(ret!=null && !ret.isEmpty()) awaitActionable(wd, ret.get(0), "click");
		for(final WebElement we: ret) {
			String sessionId = getSessionId(wd);
			if(isSettingEnabled(sessionId, "clk_focus") || "fo".equalsIgnoreCase(qualifier)) {
				jsFocus(wd, we);
			}
			we.click();
			break;
		}
	}

	/** Raw (global timeouts off) click codegen: as above, an auto-wait failure names the locator. */
	protected void clickAction(WebDriver wd, List<WebElement> ret, String qualifier, String locator) {
		try {
			clickAction(wd, ret, qualifier);
		} catch (Actionability.NotActionableException e) {
			throw e.withLocator(locator);
		}
	}

	private void elementAction(WebDriver wd, List<WebElement> ret, String action, String tvalue, String selValue, String selSubsel) {
		if(!action.toLowerCase().matches(Command.clickExStr)) __traceAction__(action, selValue, ret!=null && !ret.isEmpty() ? ret.get(0) : null);
		if(action.toLowerCase().matches(Command.clickExStr)) {
			Matcher m = Command.clickEx.matcher(action.toLowerCase());
        	m.matches();
        	String qualifier = m.group(1);
			clickAction(wd, ret, qualifier);
		} else if(action.equalsIgnoreCase("hover")) {
			for(final WebElement we: ret) {
				awaitActionable(wd, we, "hover");
				Actions ac = new Actions(wd);
				ac.moveToElement(we).perform();
				break;
			}
		} else if(action.equalsIgnoreCase("hoverandclick")) {
			for(final WebElement we: ret) {
				awaitActionable(wd, we, "click");
				Actions ac = new Actions(wd);
				ac.moveToElement(we).click().perform();
				break;
			}
		} else if(action.equalsIgnoreCase("clear")) {
			for(final WebElement we: ret) {
				awaitActionable(wd, we, "clear");
				jsEvent(wd, we, "fo");
				we.clear();
				jsChange(wd, we);
				break;
			}
		} else if(action.equalsIgnoreCase("submit")) {
			for(final WebElement we: ret) {
				awaitActionable(wd, we, "submit");
				jsEvent(wd, we, "fo");
				we.submit();
				break;
			}
		} else if(action.toLowerCase().matches(Command.typeExStr)) {
			Matcher m = Command.typeEx.matcher(action.toLowerCase());
        	m.matches();
        	String type = m.group(1);
        	String qualifier = m.group(2);
			for(final WebElement we: ret) {
				awaitActionable(wd, we, Actionability.modeFor(type, tvalue));
				jsEvent(wd, we, "fo");
				System.out.println(type + " => " + tvalue);
				sendKeys(type, qualifier, wd, we, tvalue, ___cxt___, state.name);
				//we.sendKeys(tvalue);
				//jsEvent(wd, we, qualifier);
				break;
			}
		} /*else if(action.equalsIgnoreCase("typenb") || action.equalsIgnoreCase("sendkeysnb")) {
			for(final WebElement we: ret) {
				System.out.println("Type => " + tvalue);
				we.sendKeys(tvalue);
				//jsChange(wd, we);
				break;
			}
		} else if(action.equalsIgnoreCase("randomize") || action.equalsIgnoreCase("randomizenb")) {
			String[] parts = tvalue.split("\\s+");
			sendKeys("randomize", qualifier, wd, ret, parts[0], parts.length>1?parts[1]:null, parts.length>2?parts[2]:null);
		}*/ else if(action.equalsIgnoreCase("upload")) {
			uploadFile(wd, ret, tvalue, 1);
		} else if(action.equalsIgnoreCase("select")) {
			//jsEvent(wd, ret.get(0), "fo");
			awaitActionable(wd, ret.get(0), "select");
			Select s = new Select(ret.get(0));
			if(selSubsel.equalsIgnoreCase("text")) {
				s.selectByVisibleText(selValue);
            } else if(selSubsel.equalsIgnoreCase("index")) {
            	s.selectByIndex(Integer.parseInt(selValue));
            } else if(selSubsel.equalsIgnoreCase("value")) {
            	s.selectByValue(selValue);
            } else if(selSubsel.equalsIgnoreCase("first")) {
            	s.selectByIndex(0);
            } else if(selSubsel.equalsIgnoreCase("last")) {
            	s.selectByIndex(s.getOptions().size()-1);
            }
			jsEvent(wd, ret.get(0), "fo");
		} /*else if(action.equalsIgnoreCase("chord")) {
			for(final WebElement we: ret) {
				we.sendKeys(Keys.chord(tvalue));
				jsChange(wd, we);
				break;
			}
		} else if(action.equalsIgnoreCase("chordnb")) {
			for(final WebElement we: ret) {
				we.sendKeys(Keys.chord(tvalue));
				//jsChange(wd, we);
				break;
			}
		}*/ else if(action.equalsIgnoreCase("dblclick") || action.equalsIgnoreCase("doubleclick")) {
			for(final WebElement we: ret) {
				//jsEvent(wd, we, "fo");
				awaitActionable(wd, we, "dblclick");
				Actions ac = new Actions(wd);
				ac.moveToElement(we).doubleClick().perform();
				break;
			}
		}
	}
	
	protected static void jsEvent(WebDriver wd, WebElement we, String qualifier) {
		if(StringUtils.isBlank(qualifier)) return;
		switch (qualifier) {
			case "bl":
				jsBlur(wd, we);
				break;
			case "ch":
				jsChange(wd, we);
				break;
			case "fo":
				we.click();
				jsFocus(wd, we);
				break;
			case "bk":
				we.sendKeys(Keys.chord("\ue003"));
				we.click();
				/*try {
					java.awt.Robot rbt = new java.awt.Robot();
					rbt.keyPress(java.awt.event.KeyEvent.VK_BACK_SPACE);
					rbt.keyRelease(java.awt.event.KeyEvent.VK_BACK_SPACE);
				} catch (AWTException e) {
				}*/
				break;
			case "cl":
				we.click();
				break;
			default:
				break;
		}
	}
	
	protected static void jsChange(WebDriver wd, WebElement we) {
		if (wd instanceof JavascriptExecutor) {
			((JavascriptExecutor)wd).executeScript("arguments[0].dispatchEvent(new Event('change', {bubbles: true}));", we);
		}
	}
	
	protected static void jsBlur(WebDriver wd, WebElement we) {
		if (wd instanceof JavascriptExecutor) {
			((JavascriptExecutor)wd).executeScript("arguments[0].blur();", we);
		}
	}
	
	protected static void jsFocus(WebDriver wd, WebElement we) {
		if (wd instanceof JavascriptExecutor) {
			((JavascriptExecutor)wd).executeScript("arguments[0].focus();", we);
		}
	}
	
	protected static void jsKeyEvent(WebDriver wd, WebElement we, String type, char key) {
		jsFocus(wd, we);
		if (wd instanceof JavascriptExecutor) {
			((JavascriptExecutor)wd).executeScript("arguments[0].dispatchEvent(new KeyboardEvent('"+type+"', {'key': '"+key+"'}));", we);
		}
	}
	
	protected static void jsClick(WebDriver wd, WebElement we) {
		if (wd instanceof JavascriptExecutor) {
			((JavascriptExecutor)wd).executeScript("arguments[0].dispatchEvent(new MouseEvent('click', {bubbles: true}));", we);
		}
	}

	protected List<WebElement> handleWaitFuncWL_(WebDriver driver, final SearchContext sc, final List<WebElement> ce, final int timeOutCounter, String relative, String[] classifier, String[] by, String subselector, 
			boolean byselsame, String value, String[] values, String action, String oper, String tvalue, String exmsg, boolean noExcep, int timeoutGranularity, boolean isVisible, String ... layers) {
		return handleWaitFuncWL(driver, sc, ce, timeOutCounter, relative, classifier, by, subselector, byselsame, value, values, action, oper, tvalue, exmsg, noExcep, timeoutGranularity, isVisible, null, 0, layers);
	}

	@SuppressWarnings("unchecked")
	protected List<WebElement> handleWaitFuncWL(WebDriver driver, final SearchContext sc, final List<WebElement> ce, int timeOutCounter, String relative, String[] classifier, String[] by, String subselector, 
			boolean byselsame, String value, String[] values, String action, String oper, String tvalue, String exmsg, boolean noExcep, int timeoutGranularity, boolean isVisible, String testFile, int lineNo, String ... layers) {
		int counter = 0;
		WebFirst.Budget assertBudget = null;   // M2: created at the first value mismatch when web-first assertions are on
		//timeOutCounter = 10;
		while(true) {
			boolean wasPaused = false;
			while(___cxt___.isPauseElSearch(true)) {
				if(___cxt___.isStopExecSet()) {
					throw new RuntimeException("Stopped Execution");
				}
				if(!wasPaused) {
					String relName = testFile.replace(state.basePath, "");
					if(relName.startsWith(File.separator)) {
						relName = relName.substring(1);
					}
					___cxt___.setPausedLineNo(relName, lineNo);
					wasPaused = true;
				}
				try {
					Thread.sleep(1000);
					System.out.println("Script is currently in paused state......");
				} catch (Exception e) {
				}
			}
			if(wasPaused) {
				try {
					BasicFileAttributes attr = Files.readAttributes(Paths.get(testFile), BasicFileAttributes.class);
					if(attr.lastModifiedTime().compareTo(state.lastModifFileTime)>0) {
						state.lastModifFileTime = attr.lastModifiedTime();
						List<String> commands = new ArrayList<String>();
						Command cmd = Command.read(___cxt___.getResourceFile(testFile), commands, ___cxt___);
						Command c = Command.findCommandByLineNum(cmd, testFile, lineNo);
						if(c!=null) {
							FindCommandImpl fc = (FindCommandImpl)c;
							List<Object> params = fc.cond.paramsAfterPause(fc.children, noExcep, counter, isVisible);
							relative = (String)params.get(0);
							classifier = (String[])params.get(1);
							if(classifier!=null) {
								classifier[0] = evaluate(classifier[0]);
								classifier[1] = evaluate(classifier[1]);
							}
							by = (String[])params.get(2);
							subselector = (String)params.get(3);
							if(subselector!=null) {
								subselector = evaluate(subselector);
							}
							byselsame = (boolean)params.get(4);
							value = (String)params.get(5);
							if(value!=null) {
								value = evaluate(value);
							}
							if(params.get(6)!=null) {
								List<String> vals = (List<String>)params.get(6);
								values = new String[vals.size()];
								for (int i = 0; i < vals.size(); i++) {
									values[i] = evaluate(vals.get(i));
								}
							}
							action = (String)params.get(7);
							oper = (String)params.get(8);
							tvalue = (String)params.get(9);
							if(tvalue!=null) {
								tvalue = evaluate(tvalue);
							}
							exmsg = (String)params.get(10);
							Object[] retvals = new Object[4];
							try {
								SeleniumTest dyn = SeleniumCodeGeneratorAndUtil.getSeleniumTest(state.name, ___cxt___.getProjectClassLoader(), 
									___cxt___, retvals, ___cxt___.getGatfExecutorConfig(), false, null, null);
								state._dynTstObj.set(dyn);
								counter = 0;
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				___cxt___.setPausedLineNo(null, -1);
			}
			List<WebElement> el;
			try {
				el = (List<WebElement>)handleWaitOrTransientProv(driver, sc, ce, 0L, relative, classifier, by, subselector, byselsame, value, values, action, oper, tvalue, exmsg, noExcep, timeoutGranularity, isVisible, layers);
			} catch (WebFirst.Mismatch mm) {
				// M2: element found, condition false: retry until assertTimeout (web-first) instead of failing at once
				if(assertBudget == null) assertBudget = webFirstBudget();
				if(assertBudget == null) throw mm;
				if(!assertBudget.retry()) throw mm.after(assertBudget.elapsed());
				sleep(Math.min(WebFirst.POLL_MS, Math.max(1, timeoutGranularity)));
				if(___cxt___.isStopExecSet()) {
					throw new RuntimeException("Stopped Execution");
				}
				continue;
			} catch (org.openqa.selenium.StaleElementReferenceException se) {
				// M2: the element re-rendered between find and read: web-first retries it like a false condition
				if(assertBudget == null) assertBudget = webFirstBudget();
				if(assertBudget == null || !assertBudget.retry()) throw se;
				sleep(Math.min(WebFirst.POLL_MS, Math.max(1, timeoutGranularity)));
				if(___cxt___.isStopExecSet()) {
					throw new RuntimeException("Stopped Execution");
				}
				continue;
			}
			if(!isVisible) {
				if (el != null) return el;
			} else {
				if (el == null) return el;
			}
			sleep(timeoutGranularity);
			if (counter++ >= timeOutCounter) {
				//noExcep is true only for if conditionals --- BEWARE, ifs generally have a small timeout counter value
				if(!noExcep && ___cxt___.getGatfExecutorConfig().isAutoPauseOnElNotFound())	{
					counter = 1;
					___cxt___.setPausedLineNo(testFile, lineNo);
					___cxt___.pauseElSearch();
				} else {
					break;
				}
			}
			if(___cxt___.isStopExecSet()) {
				throw new RuntimeException("Stopped Execution");
			}
		}
		if(!noExcep) throw new RuntimeException(exmsg);
		return null;
	}
	
	@SuppressWarnings("unchecked")
	protected List<String[]> transientProviderDataWL(WebDriver driver, final SearchContext sc, final List<WebElement> ce, final long timeOutCounter, String relative, final String[] classifier, final String[] by, String subselector, 
			boolean byselsame, String value, String[] values, String action, String oper, String tvalue, String exmsg, boolean noExcep, int timeoutGranularity, boolean isVisible, String ... layers) {
		int counter = 0;
		while(true) {
			if(___cxt___.isStopExecSet()) {
				throw new RuntimeException("Stopped Execution");
			}
			List<String[]> el = (List<String[]>)handleWaitOrTransientProv(driver, sc, ce, 0L, relative, classifier, by, subselector, byselsame, value, values, action, oper, tvalue, exmsg, noExcep, timeoutGranularity, isVisible, layers);
			if(!isVisible) {
				if (el != null) return el;
			} else {
				if (el == null) return el;
			}
			sleep(timeoutGranularity);
			if (counter++ == timeOutCounter) {
				break;
			}
		}
		if(!noExcep) throw new RuntimeException(exmsg);
		return null;
	}

	public static String getAttributeValue(WebDriver driver, WebElement el, String atName) {
		String value = null;
		if(el!=null) {
			if(driver instanceof JavascriptExecutor) {
				value = (String)((JavascriptExecutor)driver).executeScript("return window.GatfUtil.getElementAttrValue(arguments[0], arguments[1])", el, atName);
			} else {
				value = el.getDomAttribute(atName);
				if(StringUtils.isBlank(value)) {
					value = el.getDomProperty(atName);
				}
			}
		}
		return value;
	}

	@SuppressWarnings("unchecked")
	protected List<WebElement> handleWaitFunc(WebDriver driver, final SearchContext sc, final List<WebElement> ce, final long timeOutInSeconds, String relative, final String[] classifier, final String[] by, String subselector, 
			boolean byselsame, String value, String[] values, String action, String oper, String tvalue, String exmsg, boolean noExcep, int timeoutGranularity, boolean isVisible, String ... layers) {
		return (List<WebElement>)handleWaitOrTransientProv(driver, sc, ce, timeOutInSeconds, relative, classifier, by, subselector, byselsame, value, values, action, oper, tvalue, exmsg, noExcep, timeoutGranularity, isVisible, layers);
	}
	
	@SuppressWarnings("unchecked")
	protected List<String[]> transientProviderData(WebDriver driver, final SearchContext sc, final List<WebElement> ce, final long timeOutInSeconds, String relative, final String[] classifier, final String[] by, String subselector, 
			boolean byselsame, String value, String[] values, String action, String oper, String tvalue, String exmsg, boolean noExcep, int timeoutGranularity, boolean isVisible, String ... layers) {
		return (List<String[]>)handleWaitOrTransientProv(driver, sc, ce, timeOutInSeconds, relative, classifier, by, subselector, byselsame, value, values, action, oper, tvalue, exmsg, noExcep, timeoutGranularity, isVisible, layers);
	}

	@SuppressWarnings("unchecked")
	private Object handleWaitOrTransientProv(WebDriver driver, final SearchContext sc, final List<WebElement> ce, final long timeOutInSeconds, String relative, final String[] classifier, final String[] by, String subselector, 
			boolean byselsame, String value, String[] values, final String action, String oper, String tvalue, String exmsg, boolean noExcep, int timeoutGranularity, boolean isVisible, String ... layers) {
		final WebDriver wsc = (WebDriver) sc;
		final Object[] o = new Object[2];
		long timeoutRemaining = 0;
		setSemanticOpts();   // M3 semantic locator options
		initJs(driver);
		System.out.println("Searching element => " + by[0]+"@"+classifier[0]);
		if(timeOutInSeconds<=0) {
			List<WebElement> el = getElements(driver, wsc, by[0]+"@"+classifier[0], by[1]+"@"+classifier[1], relative, ce);
			if (el == null || el.isEmpty())  {
			} else {
				boolean enabledCheck = false;
				if(action!=null && (action.toLowerCase().matches(Command.clickExStr) || action.toLowerCase().matches(Command.typeExStr))) {
					enabledCheck = true;
				}

				WebElement elo = elementInteractable(el.get(0), enabledCheck, layers).apply(driver);
				if(elo!=null) {
					o[0] = el;
					o[1] = ce;
				}
			}
		} else {
			long start = System.currentTimeMillis();
			try {
				(new WebDriverWait(wsc, Duration.ofSeconds(timeOutInSeconds))).until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver input) {
						List<WebElement> ___ce___ = ce;
						try {
							List<WebElement> el = getElements(driver, wsc, by[0]+"@"+classifier[0], by[1]+"@"+classifier[1], relative, ce);
							if (el == null || el.isEmpty()) return false;

							boolean enabledCheck = false;
							if(action!=null && (action.toLowerCase().matches(Command.clickExStr) || action.toLowerCase().matches(Command.typeExStr))) {
								enabledCheck = true;
							}

							WebElement elo = elementInteractable(el.get(0), enabledCheck, layers).apply(driver);
							if(elo!=null) {
								o[0] = el;
								o[1] = ___ce___;
								return true;
							}
							return false;
						} catch(SemanticLocators.StrictViolation sv) {
							throw sv;   // M3: ambiguity is not a timing problem: fail now with the candidates
						} catch(Exception e) {
							return false;
						}
					}
				});
			} catch (org.openqa.selenium.TimeoutException e) {
				throw new RuntimeException(exmsg, e);
			}
			timeoutRemaining = timeOutInSeconds - (System.currentTimeMillis() - start)/state.timeoutSleepGranularity;
			//System.out.println("Timeout remaining = " + timeoutRemaining);
		}
		List<WebElement> ret = (List<WebElement>)o[0];
		Object resp = ret;
		boolean flag = true;
		if(ret!=null) {
			if(action==null && (StringUtils.isNotBlank(value) || (values!=null && values.length>0)) && subselector!=null && !subselector.isEmpty()) {
				if(value!=null)
				{
					if(byselsame)
					{
						String rhs = null;
						if(subselector.equalsIgnoreCase("title")) {
							rhs = ((WebDriver)sc).getTitle();
						} else if(subselector.equalsIgnoreCase("currentUrl")) {
							rhs = ((WebDriver)sc).getCurrentUrl();
						} else if(subselector.equalsIgnoreCase("pageSource")) {
							rhs = ((WebDriver)sc).getPageSource();
						} else if(subselector.equalsIgnoreCase("width")) {
							rhs = String.valueOf(driver.manage().window().getSize().getWidth());
						} else if(subselector.equalsIgnoreCase("height")) {
							rhs = String.valueOf(driver.manage().window().getSize().getHeight());
						} else if(subselector.equalsIgnoreCase("xpos")) {
							rhs = String.valueOf(driver.manage().window().getPosition().getX());
						} else if(subselector.equalsIgnoreCase("ypos")) {
							rhs = String.valueOf(driver.manage().window().getPosition().getY());
						} else if(subselector.equalsIgnoreCase("alerttext")) {
							rhs = String.valueOf(driver.switchTo().alert().getText());
						}

						if(rhs!=null) {
							if(oper.startsWith("<=")) {
								flag &= value.compareTo(rhs)<=0;
							} else if(oper.startsWith(">=")) {
								flag &= value.compareTo(rhs)>=0;
							} else if(oper.startsWith("=") || oper.startsWith("==")) {
								flag &= value.compareTo(rhs)==0;
							} else if(oper.startsWith("<")) {
								flag &= value.compareTo(rhs)<0;
							} else if(oper.startsWith(">")) {
								flag &= value.compareTo(rhs)>0;
							} else if(oper.startsWith("!=")) {
								flag &= value.compareTo(rhs)!=0;
							} else if(oper.startsWith("%") && oper.endsWith("%")) {
								flag &= value.contains(rhs);
							} else if(oper.startsWith("%")) {
								flag &= value.startsWith(rhs);
							} else if(oper.endsWith("%")) {
								flag &= value.endsWith(rhs);
							}
						}
					} else {
						for(final WebElement we: ret) {
							String rhs = null;
							if(subselector.equalsIgnoreCase("text")) {
								rhs = we.getText();
							} else if(subselector.equalsIgnoreCase("tagname")) {
								rhs = we.getTagName();
							} else if(subselector.toLowerCase().startsWith("attr@")) {
								String atname = subselector.substring(5);
								if(atname.charAt(0)=='"' || atname.charAt(0)=='\'') {
									atname = atname.substring(1, atname.length()-1);
								}
								rhs = getAttributeValue(driver, we, atname);
							} else if(subselector.toLowerCase().startsWith("cssvalue@")) {
								String atname = subselector.substring(9);
								if(atname.charAt(0)=='"' || atname.charAt(0)=='\'') {
									atname = atname.substring(1, atname.length()-1);
								}
								rhs = we.getCssValue(atname);
							} else if(subselector.equalsIgnoreCase("width")) {
								rhs = String.valueOf(we.getSize().getWidth());
							} else if(subselector.equalsIgnoreCase("height")) {
								rhs = String.valueOf(we.getSize().getHeight());
							} else if(subselector.equalsIgnoreCase("xpos")) {
								rhs = String.valueOf(we.getLocation().getX());
							} else if(subselector.equalsIgnoreCase("ypos")) {
								rhs = String.valueOf(we.getLocation().getY());
							}
	
							if(rhs!=null) {
								if(oper.startsWith("<=")) {
									flag &= value.compareTo(rhs)<=0;
								} else if(oper.startsWith(">=")) {
									flag &= value.compareTo(rhs)>=0;
								} else if(oper.startsWith("=") || oper.startsWith("==")) {
									flag &= value.compareTo(rhs)==0;
								} else if(oper.startsWith("<")) {
									flag &= value.compareTo(rhs)<0;
								} else if(oper.startsWith(">")) {
									flag &= value.compareTo(rhs)>0;
								} else if(oper.startsWith("!=")) {
									flag &= value.compareTo(rhs)!=0;
								} else if(oper.startsWith("%") && oper.endsWith("%")) {
									flag &= value.contains(rhs);
								} else if(oper.startsWith("%")) {
									flag &= value.startsWith(rhs);
								} else if(oper.endsWith("%")) {
									flag &= value.endsWith(rhs);
								}
							}
	
							break;
						}
					}
				} else if(values!=null && values.length>0) {
					if(byselsame)
					{
						String rhs = null;
						if(subselector.equalsIgnoreCase("title")) {
							rhs = ((WebDriver)sc).getTitle();
						} else if(subselector.equalsIgnoreCase("currentUrl")) {
							rhs = ((WebDriver)sc).getCurrentUrl();
						} else if(subselector.equalsIgnoreCase("pageSource")) {
							rhs = ((WebDriver)sc).getPageSource();
						} else if(subselector.equalsIgnoreCase("width")) {
							rhs = String.valueOf(driver.manage().window().getSize().getWidth());
						} else if(subselector.equalsIgnoreCase("height")) {
							rhs = String.valueOf(driver.manage().window().getSize().getHeight());
						} else if(subselector.equalsIgnoreCase("xpos")) {
							rhs = String.valueOf(driver.manage().window().getPosition().getX());
						} else if(subselector.equalsIgnoreCase("ypos")) {
							rhs = String.valueOf(driver.manage().window().getPosition().getY());
						} else if(subselector.equalsIgnoreCase("alerttext")) {
							rhs = String.valueOf(driver.switchTo().alert().getText());
						}

						if(rhs!=null) {
							if(oper.startsWith("<=")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag |= nvalue.compareTo(rhs)<=0;
								}
								flag &= tflag;
							} else if(oper.startsWith(">=")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag &= nvalue.compareTo(rhs)>=0;
								}
								flag &= tflag;
							} else if(oper.startsWith("=") || oper.startsWith("==")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag &= nvalue.compareTo(rhs)==0;
								}
								flag &= tflag;
							} else if(oper.startsWith("<")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag &= nvalue.compareTo(rhs)<0;
								}
								flag &= tflag;
							} else if(oper.startsWith(">")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag &= nvalue.compareTo(rhs)>0;
								}
								flag &= tflag;
							} else if(oper.startsWith("!=")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag &= nvalue.compareTo(rhs)!=0;
								}
								flag &= tflag;
							} else if(oper.startsWith("%") && oper.endsWith("%")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag &= nvalue.contains(rhs);
								}
								flag &= tflag;
							} else if(oper.startsWith("%")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag &= nvalue.startsWith(rhs);
								}
								flag &= tflag;
							} else if(oper.endsWith("%")) {
								boolean tflag = true;
								for (int i=0;i<values.length;i++) {
									String nvalue = values[i];
									tflag &= nvalue.endsWith(rhs);
								}
								flag &= tflag;
							}
						}
					} else {
						for(final WebElement we: ret) {
							String rhs = null;
							if(subselector.equalsIgnoreCase("text")) {
								rhs = we.getText();
							} else if(subselector.equalsIgnoreCase("tagname")) {
								rhs = we.getTagName();
							} else if(subselector.toLowerCase().startsWith("attr@")) {
								String atname = subselector.substring(5);
								if(atname.charAt(0)=='"' || atname.charAt(0)=='\'') {
									atname = atname.substring(1, atname.length()-1);
								}
								rhs = getAttributeValue(driver, we, atname);
							} else if(subselector.toLowerCase().startsWith("cssvalue@")) {
								String atname = subselector.substring(9);
								if(atname.charAt(0)=='"' || atname.charAt(0)=='\'') {
									atname = atname.substring(1, atname.length()-1);
								}
								rhs = we.getCssValue(atname);
							} else if(subselector.equalsIgnoreCase("width")) {
								rhs = String.valueOf(we.getSize().getWidth());
							} else if(subselector.equalsIgnoreCase("height")) {
								rhs = String.valueOf(we.getSize().getHeight());
							} else if(subselector.equalsIgnoreCase("xpos")) {
								rhs = String.valueOf(we.getLocation().getX());
							} else if(subselector.equalsIgnoreCase("ypos")) {
								rhs = String.valueOf(we.getLocation().getY());
							}
	
							if(rhs!=null) {
								if(oper.startsWith("<=")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag |= nvalue.compareTo(rhs)<=0;
									}
									flag &= tflag;
								} else if(oper.startsWith(">=")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag &= nvalue.compareTo(rhs)>=0;
									}
									flag &= tflag;
								} else if(oper.startsWith("=")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag &= nvalue.compareTo(rhs)==0;
									}
									flag &= tflag;
								} else if(oper.startsWith("<")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag &= nvalue.compareTo(rhs)<0;
									}
									flag &= tflag;
								} else if(oper.startsWith(">")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag &= nvalue.compareTo(rhs)>0;
									}
									flag &= tflag;
								} else if(oper.startsWith("!=")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag &= nvalue.compareTo(rhs)!=0;
									}
									flag &= tflag;
								} else if(oper.startsWith("%") && oper.endsWith("%")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag &= nvalue.contains(rhs);
									}
									flag &= tflag;
								} else if(oper.startsWith("%")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag &= nvalue.startsWith(rhs);
									}
									flag &= tflag;
								} else if(oper.endsWith("%")) {
									boolean tflag = true;
									for (int i=0;i<values.length;i++) {
										String nvalue = values[i];
										tflag &= nvalue.endsWith(rhs);
									}
									flag &= tflag;
								}
							}
	
							break;
						}
					}
				}
			} else if(action!=null) {
				try {
					elementAction(driver, ret, action, tvalue, value, subselector);
				} catch (Actionability.NotActionableException e) {
					// M1: auto-wait gave up. A detached element is searched for again by the caller's wait loop (WL path).
					if(e.isDetached() && !isVisible && timeOutInSeconds<=0) return null;
					throw e.withLocator(by[0]+"@"+classifier[0]);
				} catch (WebDriverException e) {
					String exMsg = ExceptionUtils.getStackTrace(e);
					boolean isInvClk = exMsg.contains("org.openqa.selenium.ElementClickInterceptedException") 
							&& exMsg.contains("is not clickable at point (")
							&& exMsg.contains("Other element would receive the click");
					boolean isNotSel = exMsg.contains("org.openqa.selenium.ElementNotSelectableException");
					boolean isNotInt = exMsg.contains("org.openqa.selenium.ElementNotInteractableException");
					boolean isNotVis = exMsg.contains("org.openqa.selenium.ElementNotVisibleException");
					if(isInvClk || isNotSel || isNotInt || isNotVis) {
						resp = null;
					}
					if(timeoutRemaining>0 && (isInvClk || isNotSel || isNotInt || isNotVis)) {
						Exception lastException = null;
						while(timeoutRemaining>0) {
							if(___cxt___.isStopExecSet()) {
								throw new RuntimeException("Stopped Execution");
							}
							try {
								Thread.sleep(state.timeoutSleepGranularity);
								System.out.println("WDE-Retrying operation.....Timeout remaining = " + (timeoutRemaining-1) + " secs");
								elementAction(driver, ret, action, tvalue, value, subselector);
								resp = ret;
								lastException = null;
								break;
							} catch (Exception e1) {
								if(e1 instanceof Actionability.NotActionableException) throw ((Actionability.NotActionableException)e1).withLocator(by[0]+"@"+classifier[0]);
								lastException = e1;
								exMsg = ExceptionUtils.getStackTrace(e1);
								isInvClk = exMsg.contains("org.openqa.selenium.ElementClickInterceptedException") 
										&& exMsg.contains("is not clickable at point (")
										&& exMsg.contains("Other element would receive the click");
								isNotSel = exMsg.contains("org.openqa.selenium.ElementNotSelectableException");
								isNotInt = exMsg.contains("org.openqa.selenium.ElementNotInteractableException");
								isNotVis = exMsg.contains("org.openqa.selenium.ElementNotVisibleException");
								if(!(isInvClk || isNotSel || isNotInt || isNotVis)) {
									break;
								}
							}
							timeoutRemaining--;
						}
						if(lastException!=null) {
							lastException.printStackTrace();
						}
					} else {
						//This means this has come from WaitTillElementVisibleOrInvisibleCommand
						if(timeoutRemaining==0 && (isInvClk || isNotSel || isNotInt || isNotVis)) {
							return null;
						}
						e.printStackTrace();
					}
				} catch (Exception e) {
					String exMsg = ExceptionUtils.getStackTrace(e);
					boolean isInvClk = exMsg.contains("org.openqa.selenium.ElementClickInterceptedException") 
							&& exMsg.contains("is not clickable at point (")
							&& exMsg.contains("Other element would receive the click");
					boolean isNotSel = exMsg.contains("org.openqa.selenium.ElementNotSelectableException");
					boolean isNotInt = exMsg.contains("org.openqa.selenium.ElementNotInteractableException");
					boolean isNotVis = exMsg.contains("org.openqa.selenium.ElementNotVisibleException");
					if(isInvClk || isNotSel || isNotInt || isNotVis) {
						resp = null;
					}
					if(timeoutRemaining>0 && (isInvClk || isNotSel || isNotInt || isNotVis)) {
						Exception lastException = null;
						while(timeoutRemaining>0) {
							if(___cxt___.isStopExecSet()) {
								throw new RuntimeException("Stopped Execution");
							}
							try {
								Thread.sleep(state.timeoutSleepGranularity);
								System.out.println("E-Retrying operation.....Timeout remaining = " + (timeoutRemaining-1) + " secs");
								elementAction(driver, ret, action, tvalue, value, subselector);
								resp = ret;
								lastException = null;
								break;
							} catch (Exception e1) {
								if(e1 instanceof Actionability.NotActionableException) throw ((Actionability.NotActionableException)e1).withLocator(by[0]+"@"+classifier[0]);
								lastException = e1;
								exMsg = ExceptionUtils.getStackTrace(e1);
								isInvClk = exMsg.contains("org.openqa.selenium.ElementClickInterceptedException") 
										&& exMsg.contains("is not clickable at point (")
										&& exMsg.contains("Other element would receive the click");
								isNotSel = exMsg.contains("org.openqa.selenium.ElementNotSelectableException");
								isNotInt = exMsg.contains("org.openqa.selenium.ElementNotInteractableException");
								isNotVis = exMsg.contains("org.openqa.selenium.ElementNotVisibleException");
								if(!(isInvClk || isNotSel || isNotInt || isNotVis)) {
									break;
								}
							}
							timeoutRemaining--;
						}
						if(lastException!=null) {
							lastException.printStackTrace();
						}
					} else {
						//This means this has come from WaitTillElementVisibleOrInvisibleCommand
						if(timeoutRemaining==0 && (isInvClk || isNotSel || isNotInt || isNotVis)) {
							return null;
						}
						e.printStackTrace();
					}
				}
			} else if("selected".equalsIgnoreCase(subselector) || "enabled".equalsIgnoreCase(subselector) || "visible".equalsIgnoreCase(subselector)) {
				for(final WebElement we: ret) {
					if(subselector.equalsIgnoreCase("selected")) {
						flag &= we.isSelected();
					} else if(subselector.equalsIgnoreCase("enabled")) {
						flag &= we.isEnabled();
					} else if(subselector.equalsIgnoreCase("visible")) {
						flag &= we.isDisplayed();
					}
					break;
				}
			} else if(subselector!=null) {
				List<String> ssl = Arrays.asList(subselector.split("[\t ]*,[\t ]*"));
				List<String[]> rtl = new java.util.ArrayList<String[]>();
				for(final WebElement we: ret) {
					String[] t = new String[ssl.size()];
					for (int i=0;i<ssl.size();i++)
					{
						if(ssl.get(i).equalsIgnoreCase("text")) {
							t[i] = we.getText();
						} else if(ssl.get(i).equalsIgnoreCase("tagname")) {
							t[i] = we.getTagName();
						} else if(ssl.get(i).toLowerCase().startsWith("attr@")) {
							String atname = ssl.get(i).substring(5);
							if(atname.charAt(0)=='"' || atname.charAt(0)=='\'') {
								atname = atname.substring(1, atname.length()-1);
							}
							t[i] = getAttributeValue(driver, we, atname);
						} else if(ssl.get(i).toLowerCase().startsWith("cssvalue@")) {
							String atname = ssl.get(i).substring(9);
							if(atname.charAt(0)=='"' || atname.charAt(0)=='\'') {
								atname = atname.substring(1, atname.length()-1);
							}
							t[i] = we.getCssValue(atname);
						} else if(ssl.get(i).equalsIgnoreCase("width")) {
							t[i] = String.valueOf(we.getSize().getWidth());
						} else if(ssl.get(i).equalsIgnoreCase("height")) {
							t[i] = String.valueOf(we.getSize().getHeight());
						} else if(ssl.get(i).equalsIgnoreCase("xpos")) {
							t[i] = String.valueOf(we.getLocation().getX());
						} else if(ssl.get(i).equalsIgnoreCase("ypos")) {
							t[i] = String.valueOf(we.getLocation().getY());
						}
					}
					rtl.add(t);
				}
				resp = rtl;
			}
		}
		if(!noExcep && !flag) {
			throw new WebFirst.Mismatch(exmsg, WebFirst.describe(subselector, oper, value, values));
		} else if(noExcep) {
			//resp = null;
		}
		return resp;
	}

	protected void sleep(long wait) {
		try {
			while(wait>0) {
				Thread.sleep(Math.min(wait, 1000));
				wait -= 1000;
				if(___cxt___.isStopExecSet()) {
					throw new RuntimeException("Stopped Execution");
				}
				if(wait<1000 && wait>0) {
					Thread.sleep(wait);
				}
			}
		} catch (InterruptedException ___e___15) {
		}
	}

	private static int getZIndex(WebElement el) {
		String zindex = el.getCssValue("z-index");
		if(zindex!=null) {
			try {
				return Integer.parseInt(el.getCssValue("z-index"));
			} catch (Exception e) {
			}
		}
		return 0;
	}

	private static boolean checkRectangleOnTop(Rectangle trec, Rectangle orec) {
		Point tmid = new Point(trec.getX() + trec.getWidth()/2, trec.getY() + trec.getHeight()/2);
		return tmid.getX()>orec.getX() && tmid.getX()<(orec.getX()+orec.getWidth()) && tmid.getY()>orec.getY() && tmid.getY()<(orec.getY()+orec.getHeight());
	}

	protected static Rectangle getRect(WebElement e) {
		return new Rectangle(e.getLocation().getX(), e.getLocation().getY(), e.getSize().getWidth(), e.getSize().getHeight());
	}
	
	protected static Point getCenter(WebElement e) {
		Rectangle rect = ((WebElement)e).getRect();
		Point from = new Point(rect.x + rect.getWidth() / 2, rect.y + rect.getHeight() / 2);
		return from;
	}

	private static ExpectedCondition<WebElement> elementInteractable(WebElement element, boolean enabledCheck, String ... layers) {
		return new ExpectedCondition<WebElement>() {
			@Override
			public WebElement apply(WebDriver driver) {
				try {
					WebElement telement = ExpectedConditions.elementToBeClickable(element).apply(driver);
					if(telement==null && isJsVisible(driver, element)) {
						return element;
					}
					//element.isDisplayed() && (!enabledCheck || (enabledCheck && element.isEnabled()));
					if(telement!=null && layers!=null && layers.length>0) {
						int tzl = getZIndex(telement);
						Rectangle trec = getRect(telement);
						List<WebElement> ce = new ArrayList<WebElement>();
						ce.add(element);
						for (String layer : layers) {
							try {
								List<WebElement> el = getElements(driver, driver, layer, null, null, ce);
								if(el!=null && el.size()>0 && /*el.get(0).isEnabled() &&*/ el.get(0).isDisplayed()) {
									int ozl = getZIndex(el.get(0));
									Rectangle orec = getRect(el.get(0));
									boolean temp = ozl>tzl && checkRectangleOnTop(trec, orec);
									if(!temp) {
										telement = null;
										break;
									}
								}
							} catch (Exception e) {
							}
						}
					}
					return telement;
				} catch (Exception e) {
					return null;
				}
			}
		};
	}
	
	private static boolean isJsVisible(WebDriver driver, WebElement element) {
		if (driver instanceof JavascriptExecutor) {
			return Boolean.TRUE.equals(((JavascriptExecutor)driver)
					.executeScript("return arguments[0].offsetParent!==undefined && arguments[0].offsetParent!==null", element));
		}
		return true;
	}

	protected void initStateFulProvider(String name) {
		String hash = getFileProviderHash(name);
		if(hash==null) {
			throw new RuntimeException("Only File providers can have stateful loops, provder " + name + " is not a file provider");
		}
		File stateFile = new File(name+"_s_state");
		if(!stateFile.exists()) {
			try {
				stateFile.createNewFile();
				FileUtils.write(stateFile, hash+";0", "UTF-8");
			} catch (Exception e) {
			}
		} else {
			try {
				String contents = FileUtils.readFileToString(stateFile, "UTF-8");
				if(!contents.startsWith(hash+";")) {
					throw new RuntimeException("File provider " + name + " has changed, cannot continue with stateful provider loop\n"
							+ "Delete the " + name+"_s_state" + " file to continue from the beginning of the provider loop");
				}
			} catch (Exception e) {
			}
		}
	}

	protected int preStateFulProvider(String name, int index) {
		File stateFile = new File(name+"_s_state");
		if(stateFile.exists()) {
			try {
				String contents = FileUtils.readFileToString(stateFile, "UTF-8");
				return Integer.valueOf(contents.substring(contents.indexOf(";")+1));
			} catch (Exception e) {
			}
		} else {
			System.out.println("File provider " + name + " has been deleted on the filesystem, but we will continue as far as we can");
		}
		return index;
	}

	protected void postStateFulProvider(String name, int index) {
		File stateFile = new File(name+"_s_state");
		if(stateFile.exists()) {
			try {
				String contents = FileUtils.readFileToString(stateFile, "UTF-8");
				contents = contents.substring(0, contents.indexOf(";")+1) + (index+1);
				FileUtils.write(stateFile, contents, "UTF-8");
			} catch (Exception e) {
			}
		} else {
			System.out.println("File provider " + name + " has been deleted on the filesystem, but we will continue as far as we can");
		}
	}

	protected byte[] screenshotAsBytes(WebDriver webDriver) throws IOException {
		Screenshot fpScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(webDriver);
		BufferedImage originalImage = fpScreenshot.getImage();
		try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
			ImageIO.write(originalImage, "png", baos);
			baos.flush();
			return baos.toByteArray();
		}
	}

	protected static void screenshotAsFile(WebDriver webDriver, String filepath) {
		if(webDriver instanceof AppiumDriver) {
			File sc = ((TakesScreenshot)new Augmenter().augment(webDriver)).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(sc, new File(filepath));
			} catch (Exception e) {
			}
		} else {
			float windowDPR = 1.75f;
			if (webDriver instanceof JavascriptExecutor) {
				Object output = ((JavascriptExecutor) webDriver).executeScript("return window.devicePixelRatio");
				windowDPR = Float.parseFloat(String.valueOf(output));
			}
			Screenshot fpScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(ShootingStrategies.scaling(windowDPR), 100)).takeScreenshot(webDriver);
			BufferedImage originalImage = fpScreenshot.getImage();
			try {
				ImageIO.write(originalImage, "png", new FileOutputStream(filepath));
			} catch (Exception e) {
			}
		}
	}

	protected void elementScreenshotAsFile(WebDriver webDriver, WebElement element, String filepath) throws IOException {
		if(webDriver instanceof AppiumDriver) {
			File sc = element.getScreenshotAs(OutputType.FILE);
			//File sc = ((TakesScreenshot)new Augmenter().augment(element)).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(sc, new File(filepath));
		} else {
			float windowDPR = 1.75f;
			if (webDriver instanceof JavascriptExecutor) {
				Object output = ((JavascriptExecutor) webDriver).executeScript("return window.devicePixelRatio");
				windowDPR = Float.parseFloat(String.valueOf(output));
			}
			Screenshot fpScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(ShootingStrategies.scaling(windowDPR), 100)).takeScreenshot(webDriver, element);
			BufferedImage originalImage = fpScreenshot.getImage();
			ImageIO.write(originalImage, "png", new FileOutputStream(filepath));
		}
	}

	protected void saveImageToFile(WebDriver webDriver, WebElement element, String filepath) throws IOException {
		if(element!=null && element.getTagName().equalsIgnoreCase("img")) {
			BufferedImage originalImage = ImageIO.read(new URL(element.getDomProperty("src")));
			ImageIO.write(originalImage, "png", new FileOutputStream(filepath));
		}
	}

	protected String readImageText(WebDriver webDriver, WebElement element, String filepath) throws IOException {
		ITesseract ocr = instance.get();
		try {
			if(ocr==null) {
				ocr = new Tesseract1();
				ocr.setDatapath(___cxt___.getGatfExecutorConfig().getExtraProperties().get("tesseract.training.data.path"));
				instance.set(ocr);
			}
		} catch (Exception e) {
			throw new RuntimeException("Unable to initialize tesseract engine");
		}
		if(element!=null && element.getTagName().equalsIgnoreCase("img") && ocr!=null) {
			BufferedImage bufferedImage = null;
			if (webDriver instanceof JavascriptExecutor) {
				String str = (String) ((JavascriptExecutor) webDriver).executeScript("return window.GatfUtil.imageAsBase64(arguments[0])", element);
				byte[] imagedata = DatatypeConverter.parseBase64Binary(str.substring(str.indexOf(",") + 1));
				bufferedImage = ImageIO.read(new ByteArrayInputStream(imagedata));
			} else {
				bufferedImage = ImageIO.read(new URL(element.getDomProperty("src")));
			}
			
			if(StringUtils.isNotBlank(filepath)) {
				ImageIO.write(bufferedImage, "png", new FileOutputStream(filepath));
			}
			
			try {
				return ocr.doOCR(bufferedImage);
			} catch (Exception e) {
				throw new RuntimeException("Unable to extract text from image file");
			}
		}
		throw new RuntimeException("not a valid image element");
	}

	protected String readBlob(WebDriver webDriver, String burl) {
		if(webDriver instanceof JavascriptExecutor) {
			try {
				@SuppressWarnings("unused")
				String script = " "
					+ "var uri = arguments[0];"
					+ "var callback = arguments[1];"
					+ "var toBase64 = function(buffer){for(var r,n=new Uint8Array(buffer),t=n.length,a=new Uint8Array(4*Math.ceil(t/3)),i=new Uint8Array(64),o=0,c=0;64>c;++c)i[c]='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'.charCodeAt(c);for(c=0;t-t%3>c;c+=3,o+=4)r=n[c]<<16|n[c+1]<<8|n[c+2],a[o]=i[r>>18],a[o+1]=i[r>>12&63],a[o+2]=i[r>>6&63],a[o+3]=i[63&r];return t%3===1?(r=n[t-1],a[o]=i[r>>2],a[o+1]=i[r<<4&63],a[o+2]=61,a[o+3]=61):t%3===2&&(r=(n[t-2]<<8)+n[t-1],a[o]=i[r>>10],a[o+1]=i[r>>4&63],a[o+2]=i[r<<2&63],a[o+3]=61),new TextDecoder('ascii').decode(a)};"
					+ "var xhr = new XMLHttpRequest();"
					+ "xhr.responseType = 'arraybuffer';"
					+ "xhr.onload = function(){ callback(toBase64(xhr.response)) };"
					+ "xhr.onerror = function(){ callback(uri) };"
					+ "xhr.open('GET', uri);"
					+ "xhr.send();"; 
				String string2 = "const blob = await fetch(document.location).then(res => res.blob());"
					+ "function blobToBase64(blob) {"
					+ "	return new Promise((resolve, _) => {"
					+ "		const reader = new FileReader();"
					+ "		reader.onloadend = () => resolve(reader.result);"
					+ "		reader.readAsDataURL(blob);"
					+ "	});"
					+ "}return await blobToBase64(blob);";
				Object result = ((JavascriptExecutor) webDriver).executeScript(string2);
				return result.toString();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return "";
	}
	
	protected String readQrBarCode(WebDriver webDriver, WebElement element, String filepath) throws IOException {
		if(element!=null && webDriver instanceof JavascriptExecutor) {
			BufferedImage bufferedImage = null;
			String str = (String) ((JavascriptExecutor) webDriver).executeAsyncScript("window.GatfUtil.elementToBase64(arguments[0], arguments[arguments.length-1])", element);
			byte[] imagedata = DatatypeConverter.parseBase64Binary(str.substring(str.indexOf(",") + 1));
			bufferedImage = ImageIO.read(new ByteArrayInputStream(imagedata));
			/*} else {
				bufferedImage = ImageIO.read(new URL(element.getDomProperty("src")));
			}*/
			
			if(StringUtils.isNotBlank(filepath)) {
				ImageIO.write(bufferedImage, "png", new FileOutputStream(filepath));
			}
			
			try {
				LuminanceSource source = new BufferedImageLuminanceSource(bufferedImage);
			    BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
			    Result result = new MultiFormatReader().decode(bitmap);
			    return result.getText();
			} catch (Exception e) {
				throw new RuntimeException("Unable to read QR/Barcode from image file");
			}
		}
		throw new RuntimeException("not a valid image element");
	}
	
	
	protected String getOutDir() {
		return ___cxt___.getOutDirPath() + File.separator + state.outPath;
	}

	/** M9/M10: files produced by a step (visual diff, accessibility results), drained into the next pushed result. */
	final List<String> __attachments__ = java.util.Collections.synchronizedList(new ArrayList<String>());

	protected void __attach__(String absPath) {
		if (absPath != null) __attachments__.add(absPath);
	}

	List<String> drainAttachments() {
		synchronized (__attachments__) {
			List<String> out = new ArrayList<String>(__attachments__);
			__attachments__.clear();
			return out;
		}
	}

	/** M9/M10: the running .sel file's path under the test-case dir, without {@code .sel} ({@code ui/login}); "" if unknown. */
	protected String scriptKey() {
		if (state == null || state.cfileName == null) return "";
		String rel = state.basePath != null ? state.cfileName.replace(state.basePath, "") : new File(state.cfileName).getName();
		rel = rel.replace('\\', '/');
		while (rel.startsWith("/")) rel = rel.substring(1);
		return rel.toLowerCase(java.util.Locale.ROOT).endsWith(".sel") ? rel.substring(0, rel.length() - 4) : rel;
	}

	/** M9: {@code gatf test --update-snapshots} (config updateSnapshots, or -Dgatf.updateSnapshots=true). */
	protected boolean updateSnapshots() {
		GatfExecutorConfig cfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		return (cfg != null && Boolean.TRUE.equals(cfg.getUpdateSnapshots())) || Boolean.getBoolean("gatf.updateSnapshots");
	}

	/** The whole page in CSS pixels (AShot viewport pasting, scaled by devicePixelRatio), as element rects are. */
	protected BufferedImage fullPageImage(WebDriver webDriver) throws IOException {
		if (webDriver instanceof AppiumDriver) {
			byte[] png = ((TakesScreenshot) new Augmenter().augment(webDriver)).getScreenshotAs(OutputType.BYTES);
			return ImageIO.read(new java.io.ByteArrayInputStream(png));
		}
		float dpr = 1f;
		if (webDriver instanceof JavascriptExecutor) {
			Object output = ((JavascriptExecutor) webDriver).executeScript("return window.devicePixelRatio");
			try { dpr = Float.parseFloat(String.valueOf(output)); } catch (NumberFormatException e) { dpr = 1f; }
		}
		return new AShot().shootingStrategy(ShootingStrategies.viewportPasting(ShootingStrategies.scaling(dpr), 100)).takeScreenshot(webDriver).getImage();
	}

	private static volatile String AXE_JS;

	/** The bundled axe-core (unmodified, MPL-2.0: resources/gatf-axe/), read once. */
	static String axeSource() {
		String s = AXE_JS;
		if (s == null) {
			try (java.io.InputStream in = SeleniumTest.class.getResourceAsStream("/gatf-axe/axe.min.js")) {
				if (in == null) throw new IllegalStateException("gatf-axe/axe.min.js is missing from the classpath");
				AXE_JS = s = IOUtils.toString(in, "UTF-8");
			} catch (IOException e) {
				throw new IllegalStateException("cannot read gatf-axe/axe.min.js: " + e.getMessage(), e);
			}
		}
		return s;
	}

	/**
	 * M10: {@code a11y check [include <css>]... [exclude <css>]... [impact>=<level>] [report]}: runs axe-core in the page;
	 * violations at or above the level fail the step (unless {@code report}), listed with their selectors. The mapped
	 * result goes to {@code <out>/<browser>-<n>-a11y.json} (attached), the report's checks tab and the trace.
	 */
	/** M10: numbering of a11y result files across the run (scripts share the out dir). */
	private static final java.util.concurrent.atomic.AtomicInteger A11Y_SEQ = new java.util.concurrent.atomic.AtomicInteger();

	/** Injects the bundled axe (unless this exact version is there) into the current document and, recursively, its frames. */
	private void injectAxe(WebDriver d, int depth) {
		JavascriptExecutor js = (JavascriptExecutor) d;
		Object ver = js.executeScript("return window.axe && window.axe.run ? String(window.axe.version) : null;");
		if (!com.gatf.selenium.checks.A11yReport.AXE_VERSION.equals(ver)) js.executeScript(axeSource());
		js.executeScript(com.gatf.selenium.checks.A11yReport.CONFIGURE_JS);
		if (depth >= 3) return;
		List<WebElement> frames;
		try {
			frames = d.findElements(org.openqa.selenium.By.cssSelector("iframe, frame"));
		} catch (RuntimeException e) {
			return;
		}
		for (WebElement f : frames) {
			try {
				d.switchTo().frame(f);
			} catch (RuntimeException e) {
				continue;   // detached / not switchable: axe reports it as "incomplete"
			}
			try {
				injectAxe(d, depth + 1);
			} catch (RuntimeException e) {
				// a frame that refuses scripts is left to axe's own frame handling
			} finally {
				d.switchTo().parentFrame();
			}
		}
	}

	/**
	 * M10: {@code a11y check [include <css>]... [exclude <css>]... [impact>=<level>] [report]}: runs axe-core in the page
	 * (and its frames); violations at or above the level fail the step (unless {@code report}), listed with their
	 * selectors. The mapped result goes to {@code <out>/<browser>-<script>-<n>-a11y.json} (attached), the report's
	 * checks tab, the trace ({@code checks.json}) and a trace event.
	 */
	@SuppressWarnings("unchecked")
	protected void __a11yCheck__(WebDriver d, List<String> include, List<String> exclude, String minImpact, boolean reportOnly) {
		if (!(d instanceof JavascriptExecutor)) throw new RuntimeException("a11y check needs a browser that runs JavaScript");
		JavascriptExecutor js = (JavascriptExecutor) d;
		injectAxe(d, 0);
		// axe on a large page can outrun the driver's default 30 s async-script timeout
		java.time.Duration prev = null;
		try {
			prev = d.manage().timeouts().getScriptTimeout();
			if (prev == null || prev.compareTo(java.time.Duration.ofSeconds(120)) < 0) d.manage().timeouts().scriptTimeout(java.time.Duration.ofSeconds(120));
		} catch (RuntimeException e) {
			prev = null;
		}
		Object raw;
		try {
			raw = js.executeAsyncScript(com.gatf.selenium.checks.A11yReport.RUN_JS, include, exclude);
		} finally {
			if (prev != null) {
				try { d.manage().timeouts().scriptTimeout(prev); } catch (RuntimeException e) { /* keep going */ }
			}
		}
		Map<String, Object> rep;
		try {
			rep = com.gatf.selenium.checks.A11yReport.map(WorkflowContextHandler.OM.readValue(String.valueOf(raw), Map.class), minImpact, getBrowserName());
		} catch (IOException e) {
			throw new RuntimeException("a11y check: unreadable axe result: " + e.getMessage(), e);
		}
		int n = A11Y_SEQ.incrementAndGet();
		String file = null;
		try {
			String b = getBrowserName() == null ? "" : getBrowserName().replaceAll("[^A-Za-z0-9._-]+", "_") + "-";
			String sc = scriptKey().replaceAll("[^A-Za-z0-9._-]+", "-");
			File f = new File(getOutDir(), b + (sc.isEmpty() ? "" : sc + "-") + n + "-a11y.json");
			f.getParentFile().mkdirs();
			WorkflowContextHandler.OM.writerWithDefaultPrettyPrinter().writeValue(f, rep);
			file = f.getAbsolutePath();
			__attach__(file);
			if (getSession().__trace__ != null) {   // picked up by TraceChecks into the trace's checks.json
				WorkflowContextHandler.OM.writerWithDefaultPrettyPrinter().writeValue(getSession().__trace__.workDir().resolve("a11y-" + n + ".json").toFile(), rep);
			}
		} catch (IOException | RuntimeException e) {
			System.out.println("a11y check: result not written: " + e.getMessage());
		}
		getSession().__a11y__.add(rep);
		String summary = com.gatf.selenium.checks.A11yReport.summary(rep);
		__traceAction__("a11y", summary);
		System.out.println(summary);
		if (!reportOnly && Boolean.TRUE.equals(rep.get("failed"))) {
			throw new RuntimeException(com.gatf.selenium.checks.A11yReport.failureMessage(rep, file));
		}
	}

	/**
	 * M9: {@code screenshot compare <name> [threshold] [maxdiff N|N%] [mask <locator>]...}: compares the page with its
	 * baseline in {@code <testCaseDir>/__screenshots__/<browser>/}; a mismatch fails the step and attaches the diff.
	 */
	protected void __screenshotCompare__(WebDriver d, String name, double threshold, String maxDiff, List<WebElement> masks) {
		com.gatf.selenium.visual.ImageDiff.Options o = new com.gatf.selenium.visual.ImageDiff.Options().threshold(threshold).maxDiff(maxDiff);
		if (masks != null) {
			for (WebElement m : masks) {
				try {
					Rectangle r = m.getRect();
					o.mask(new java.awt.Rectangle(r.getX(), r.getY(), r.getWidth(), r.getHeight()));
				} catch (RuntimeException e) {
					// a mask element that went stale / has no box masks nothing
				}
			}
		}
		com.gatf.selenium.visual.VisualSnapshots.Outcome out;
		try {
			File tcDir = new File(state.basePath != null ? state.basePath : ".");
			out = com.gatf.selenium.visual.VisualSnapshots.check(tcDir, getBrowserName(), scriptKey(), name, fullPageImage(d), o, updateSnapshots(),
					"true".equalsIgnoreCase(System.getenv("CI")), new File(getOutDir()));
		} catch (IOException e) {
			throw new RuntimeException("screenshot compare '" + name + "': " + e.getMessage(), e);
		}
		for (String a : out.attachments) __attach__(a);
		__traceAction__("screenshot-compare", out.message);
		System.out.println(out.message);
		if (!out.passed) throw new RuntimeException(out.message);
	}
	
	public static void main(String[] args) throws Exception {
        GatfExecutorConfig config = Command.getConfig(args[1].trim(), args.length>2?args[2].trim():null);
        config.setSeleniumLoggerPreferences("browser(OFF),client(OFF),driver(OFF),performance(OFF),profiler(OFF),server(OFF)");
        for (SeleniumDriverConfig selConf : config.getSeleniumDriverConfigs())
        {
            if(selConf.getDriverName() != null && selConf.getPath()!=null && new File(selConf.getPath()).exists()) {
                System.setProperty(selConf.getDriverName(), selConf.getPath());
            }
        }
        
        System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        Security.setProperty("crypto.policy", "unlimited");
        System.setProperty("webdriver.http.factory", "jdk-http-client");
        
        AcceptanceTestContext c = new AcceptanceTestContext();
        c.setGatfExecutorConfig(config);
        c.validateAndInit(true);
        c.getWorkflowContextHandler().initializeSuiteContext(1);
    	
        try {
        	final LoggingPreferences lp = SeleniumCodeGeneratorAndUtil.getLp(config);
        	SeleniumTest dyn = (SeleniumTest)Class.forName(args[0]).getDeclaredConstructor(new Class[] {AcceptanceTestContext.class, int.class}).newInstance(new Object[] {c, 0});
        	System.out.println(dyn!=null?"SUCCESS":"FAILURE");
        	if(dyn!=null) {
        		// Δ163h: the debugger's Stop ends this JVM; quit its browser sessions on the way out, or a Grid / device-cloud
        		// session stays open (holding its slot) until the Grid's idle timeout. quit() skips sessions already quit.
        		final SeleniumTest __dyn = dyn;
        		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
        			try { __dyn.quitAll(); } catch (Throwable ignore) { }
        		}, "gatf-debuggee-quit"));
        	}
            if(dyn!=null) {
            	try {
                    dyn.execute(lp, "");
                } catch (Throwable e) {
                }
                dyn.quitAll();
            }
        } catch (GatfSelCodeParseError e) {
        	e.printStackTrace();
        } catch (Throwable e) {
        	e.printStackTrace();
        }
    }
	
	public static class RestartsubtestException extends RuntimeException {
	}
	public static class GatfRunTimeErrors extends RuntimeException {
		private List<? extends GatfRunTimeError> errors;
		public GatfRunTimeErrors(List<? extends GatfRunTimeError> errors) {
			this.errors = errors;
		}
		public List<? extends GatfRunTimeError> getAll() {
			return errors;
		}
	}
	public static abstract class GatfRunTimeError extends RuntimeException {
		Object[] details;
		Throwable err;
		boolean pending = true;
		String img;
		public abstract Object[] getDetails();
		public GatfRunTimeError(String msg) {
			super(msg);
		}
		public GatfRunTimeError(String msg, Throwable e) {
			super(msg, e);
		}
		public Throwable getErr() {
			return err;
		}
		public String getStImg() {
			return img;
		}
		//public void process(String relPath) {
		//	details = new Object[] {details[0], details[1], details[2], relPath};
		//}
	}
	
	public static abstract class ValidSubTestException extends GatfRunTimeError {
		public ValidSubTestException(String msg) {
			super(msg);
		}
		public Object[] getDetails() {
        	return details;
        }
	}
	
	public static class PassSubTestException extends ValidSubTestException {
		public PassSubTestException(String msg) {
			super(msg);
		}
	}
	
	public static class WarnSubTestException extends ValidSubTestException {
		public WarnSubTestException(String msg) {
			super(msg);
		}
	}
	
	public static class FailSubTestException extends GatfRunTimeError {
		public FailSubTestException(String msg) {
			super(msg);
		}
		public Object[] getDetails() {
        	return details;
        }
	}
	
	public static class SubTestException extends GatfRunTimeError {
		public SubTestException(String stName, Throwable cause) {
			super(cause.getMessage());
			this.err = cause;
		}
		public Object[] getDetails() {
        	return details;
        }
	}
	
	public static class FailureException extends GatfRunTimeError {
		Throwable err;
		public FailureException(Throwable cause) {
			super(cause.getMessage());
			this.err = cause;
			if(err instanceof GatfRunTimeError) {
				this.pending = ((GatfRunTimeError)err).pending;
			}
		}
		public Object[] getDetails() {
        	return details;
        }
	}
	
	public static class XPathException extends GatfRunTimeError {
		Throwable err;
		public XPathException(Throwable cause) {
			super(cause.getMessage());
			this.err = cause;
		}
		public Object[] getDetails() {
        	return details;
        }
	}
	
	protected void navigateTo(WebDriver d, String url) {
		d.navigate().to(url);
		waitForReady(d);
	}
	
	protected void refresh(WebDriver d) {
		d.navigate().refresh();
		waitForReady(d);
	}

	protected void initBrowser(WebDriver driver, boolean logconsole, boolean logdebug, boolean lognw, boolean hasNetapixCommand) {
		state.logconsole = logconsole;
		state.logdebug = logdebug;
		state.lognw = lognw;
		state.hasNetapixCommand = hasNetapixCommand;
		// M5: every UI script starts from the project's saved login state (not the loginOnce run that produces it)
		GatfExecutorConfig __lcfg = ___cxt___ != null ? ___cxt___.getGatfExecutorConfig() : null;
		if(__lcfg != null && StringUtils.isNotBlank(__lcfg.getStorageState()) && !Boolean.TRUE.equals(LOGIN_ONCE_RUN.get()) && !Boolean.TRUE.equals(SKIP_STATE_LOAD.get())) {
			File __sf = stateFile(__lcfg.getStorageState().trim());
			if(__sf.isFile()) {
				try {
					System.out.println(BrowserState.load(driver, __sf));
				} catch (Exception e) {
					System.out.println("storageState: not loaded (" + e.getMessage() + ")");
				}
			}
		} else if(__lcfg != null && StringUtils.isNotBlank(__lcfg.getStorageState()) && Boolean.TRUE.equals(LOGIN_ONCE_RUN.get()) && !__stateFresh__) {
			// M5: the loginOnce run replaces the state file (a merge would keep an old login's cookies / origins)
			__stateFresh__ = true;
			File __sf = stateFile(__lcfg.getStorageState().trim());
			if(__sf.isFile() && __sf.delete()) System.out.println("loginOnce: previous " + __sf.getPath() + " removed");
		}
		String sessionId = ((RemoteWebDriver)driver).getSessionId().toString();
		if(driver instanceof HasDevTools) {
			DevTools devTools = ((HasDevTools)driver).getDevTools();
			state.BROWSER_FEATURES.put(sessionId+".SECURITY", true);
			//BROWSER_FEATURES.put(sessionId+".INTERCEPTNW", interceptApiCall);
			state.BROWSER_FEATURES.put(sessionId+".LOGCONSOLE", logconsole);
			state.BROWSER_FEATURES.put(sessionId+".NWCONSOLE", lognw);
			devTools.createSession();
			devTools.clearListeners();
			devTools.send(Network.setCacheDisabled(true));
			devTools.send(org.openqa.selenium.devtools.v150.security.Security.setIgnoreCertificateErrors(true));
			
			if(logconsole) {
				devTools.send(Log.enable());
				devTools.addListener(Log.entryAdded(), logEntry -> {
					System.out.println("Browser Console Log ["+logEntry.getLevel()+"]: "+logEntry.getText());
				});
			}

			devTools.addListener(Target.targetCreated(), targetCreatedEvent -> {
				if ("page".equals(targetCreatedEvent.getType())) {
					state.tabList.add(targetCreatedEvent.getTargetId().toString());
					System.out.println("New Tab Opened: " + targetCreatedEvent.getTitle() + " (" + targetCreatedEvent.getUrl() + ")");
				}
			});

			devTools.addListener(Target.targetDestroyed(), targetId -> {
				int tgid = -1;
				for(int i=0;i<state.tabList.size();i++) {
					if(state.tabList.get(i).equals(targetId.toString())) {
						tgid = i;
						break;
					}
				}
				if(tgid!=-1) state.tabList.remove(tgid);
			});

			if(hasNetapixCommand) {
				/*
				* Fetch requestpaused will only work if you do it right at the begnning when the first session is created
				*/
				List<RequestPattern> lrp = new ArrayList<>();
				lrp.add(new RequestPattern(Optional.of("*"), Optional.empty(), Optional.of(RequestStage.RESPONSE)));
				devTools.send(Fetch.enable(Optional.of(lrp), Optional.empty()));
				devTools.addListener(Fetch.requestPaused(), requestPaused -> {
					// M4: request-stage pauses belong to route (CdpTransport answers them); netapix handles responses only
					if(!requestPaused.getResponseStatusCode().isPresent() && !requestPaused.getResponseErrorReason().isPresent()) return;
					if(state.NETWORK_INSPECTION.containsKey(sessionId)) {
						String url = state.NETWORK_INSPECTION.get(sessionId)[1].toString();
						String murl = url.indexOf("?")!=-1?url.substring(0, url.indexOf("?")):url;
						//System.out.println("---" + requestPaused.getRequestId().toString());
						if(requestPaused.getResponseStatusCode().isPresent()) {
							System.out.println(String.format("Captured Network Response for [%s] -> %d", requestPaused.getRequestId().toString(), 
								requestPaused.getResponseStatusCode().get()));
						} else {
							System.out.println(String.format("Captured Network Response for [%s]", requestPaused.getRequestId().toString()));
						}
						//requestPaused.getRequestId()
						String rurl = requestPaused.getRequest().getUrl();
						rurl = rurl.indexOf("?")!=-1?rurl.substring(0, rurl.indexOf("?")):rurl;
						if(requestPaused.getRequest().getMethod().equalsIgnoreCase(state.NETWORK_INSPECTION.get(sessionId)[0].toString()) && rurl.equalsIgnoreCase(murl)) {
							System.out.println("Matched inspection request [" + state.NETWORK_INSPECTION.get(sessionId)[0].toString() + "@" + murl + "]");
							List<HeaderEntry> headers = requestPaused.getResponseHeaders().get();
							String mimeType = null;
							Map<String, Object> headerMap = new HashMap<>();
							for(HeaderEntry he: headers) {
								if(he.getName().equalsIgnoreCase("content-type")) {
									mimeType = he.getValue();
									if(mimeType.indexOf(";")!=-1) {
										mimeType = mimeType.substring(0, mimeType.indexOf(";"));
									}
								}
								headerMap.put(he.getName(), he.getValue());
							}
							org.openqa.selenium.devtools.v150.fetch.Fetch.GetResponseBodyResponse firsb = devTools.send(Fetch.getResponseBody(requestPaused.getRequestId()));
							String body = firsb.getBody();
							if(firsb.getBase64Encoded()) {
								try {
									body = new String(org.apache.commons.codec.binary.Base64.decodeBase64(body), "UTF-8");
								} catch (UnsupportedEncodingException e) {
								}
							}
							state.NETWORK_INSPECTION.get(sessionId)[2] = requestPaused.getRequestId().toString();
							state.NETWORK_INSPECTION.get(sessionId)[3] = new Object[] {requestPaused.getResponseStatusCode().isPresent()?requestPaused.getResponseStatusCode().get():null, headerMap, mimeType, body};
						}
					}
					try {
						devTools.send(Fetch.continueResponse(requestPaused.getRequestId(), Optional.empty(), Optional.empty(), Optional.empty(), Optional.empty()));
					} catch(Exception e) {
						e.printStackTrace();
					}
				});
			}
		}
		
		// G9: trace any browser with DevTools (Chromium) OR a live BiDi socket (Firefox, Safari, BiDi-Chrome)
		if(driver instanceof HasDevTools || com.gatf.selenium.trace.BidiRaw.available(driver)) {
			try {
				// Streaming trace: functional UI runs only (not load, not multi-user). Read straight from
				// config so no Command.java codegen change is needed. Never breaks browser init.
				GatfExecutorConfig __cfg = ___cxt___!=null ? ___cxt___.getGatfExecutorConfig() : null;
				// Q3: traceMode decides whether this round traces (off / on / retain-on-failure / on-first-retry)
				if(__cfg!=null && __cfg.captureTraceThisRun() && !__cfg.isLoadTestingEnabled()
						&& (__cfg.getConcurrentUserSimulationNum()==null || __cfg.getConcurrentUserSimulationNum()<=1)
						&& getSession()!=null && getSession().__trace__==null) {
					String __sid = ((RemoteWebDriver)driver).getSessionId().toString();
					com.gatf.selenium.trace.TraceConfig __tc = new com.gatf.selenium.trace.TraceConfig()
							.setEnableTrace(true)
							.setProtocol(driver instanceof HasDevTools ? __cfg.getTraceProtocol() : "bidi")
							.setNetwork(__cfg.isTraceNetwork())
							.setConsole(__cfg.isTraceConsole())
							.setSnapshots(__cfg.isTraceSnapshots())
							.setMaxBodyBytes((long)__cfg.getTraceMaxBodyKb()*1024L)
							.setMaxTotalBytes((long)__cfg.getTraceMaxTotalMb()*1024L*1024L)
							.setMetrics(__cfg.isTraceMetrics())
							.setMetricsIntervalMs(__cfg.getTraceMetricsIntervalMs())
							.setWebVitals(__cfg.isTraceWebVitals())
							.setCpu(__cfg.isTraceCpu())
							.setCoverage(__cfg.isTraceCoverage())
							.setVideo(__cfg.isTraceVideo())
							.setVideoQuality(__cfg.getTraceVideoQuality())
							.setVideoEveryNthFrame(__cfg.getTraceVideoEveryNthFrame())
							.setDomSnapshots(__cfg.getTraceDomSnapshots());
					if(__cfg.getTraceDomSnapshotMaxMb()!=null && __cfg.getTraceDomSnapshotMaxMb()>0) {
						__tc.setSnapshotMaxTotalBytes((long)__cfg.getTraceDomSnapshotMaxMb()*1024L*1024L);
					}
					java.nio.file.Path __wd = new java.io.File(new java.io.File(getOutDir(), ".trace"), "trace-"+__sid).toPath();
					com.gatf.selenium.trace.BrowserControl __bc = com.gatf.selenium.trace.Transports.create(driver, __tc);
					getSession().__trace__ = com.gatf.selenium.trace.TraceRecorder.attach(__bc, __tc, __wd, getName(), getSession().browserName);
				}
			} catch (Exception __te) { /* tracing must never break browser init */ }
		}

		if(logdebug) {
			Configurator.setRootLevel(org.apache.logging.log4j.Level.ALL);
		}
		
		DRV_FEATURES.put(sessionId, new ConcurrentHashMap<String, String>());
	}
	
	protected void waitForReady(WebDriver driver) {
		if (driver instanceof JavascriptExecutor) {
			int counter = 0;
			while(counter++<60) {
				String status = (String)((JavascriptExecutor)driver).executeScript("return document.readyState");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				}
				if(status.equalsIgnoreCase("complete")) break;
			}
			
			if(state.possibleInvXpathExprs.size()>0) {
				initJs(driver);
				for (String[] xpathExpr : state.possibleInvXpathExprs) {
					try {
						((JavascriptExecutor)driver).executeScript("window.GatfUtil.findByXpath(arguments[0])", xpathExpr[0]);
					} catch (Exception e) {
						try {
							state.cfileName = xpathExpr[3];
							state.line = Integer.parseInt(xpathExpr[2]);
						} catch (Exception e2) {
						}
						XPathException fe = new XPathException(e);
						fe.details = new Object[] {xpathExpr[1], state.line, state.cfileName, "Invalid XPATH expression"};
						throw fe;
					}
				}
			}
		}
	}
	
	protected void initJs(WebDriver driver) {
		try {
			if(driver instanceof JavascriptExecutor) {
				if("Success".equalsIgnoreCase((String)((JavascriptExecutor)driver).executeScript("return window.GatfUtil.check()"))) {
					return;
				}
			}
		} catch (Exception e) {
			try {
				((JavascriptExecutor)driver).executeScript(IOUtils.toString(getClass().getResourceAsStream("/gatf-js-util.js"), "UTF-8"));
			} catch (IOException | NoSuchWindowException e1) {
			}
		}
	}

	protected void networkApiInspectPre(WebDriver driver, String method, String url) {
		String sessionId = ((RemoteWebDriver)driver).getSessionId().toString();
		if(!state.NETWORK_INSPECTION.containsKey(sessionId)) {
			state.NETWORK_INSPECTION.put(sessionId, new Object[] {method, url, null, null});
		} else {
			throw new RuntimeException("Only one inspection allowed at a time, no nested or simultaneous interceptions allowed.");
		}
		
		//final String murl = url.indexOf("?")!=-1?url.substring(0, url.indexOf("?")):url;
		if(driver instanceof HasDevTools) {
			DevTools devTools = ((HasDevTools)driver).getDevTools();
			if(devTools.getCdpSession()==null) {
				initBrowser(driver, state.logconsole, state.logdebug, state.lognw, state.hasNetapixCommand);
			}
			/*List<RequestPattern> lrp = new ArrayList<>();
			lrp.add(new RequestPattern(Optional.of("*"), Optional.empty(), Optional.of(RequestStage.RESPONSE)));
			devTools.send(Fetch.enable(Optional.of(lrp), Optional.empty()));

			devTools.send(Fetch.enable(Optional.of(lrp), Optional.empty()));*/

			

			/*devTools.addListener(Network.requestWillBeSent(), requestSent -> {
				if (requestSent.getType().get().equals(ResourceType.XHR)) {
					String rurl = requestSent.getRequest().getUrl();
					rurl = rurl.indexOf("?")!=-1?rurl.substring(0, rurl.indexOf("?")):rurl;
					if(requestSent.getRequest().getMethod().equalsIgnoreCase(method) && rurl.equalsIgnoreCase(murl)) {
						System.out.println("Matched inspection request [" + method + "@" + murl + "] on CDP session " + devTools.getCdpSession().toString());
						NETWORK_INSPECTION.get(sessionId)[2] = requestSent.getRequestId().toString();
					}
				}
			});
			devTools.addListener(Network.responseReceived(), responseReceived -> {
				if(NETWORK_INSPECTION.containsKey(sessionId) && responseReceived.getRequestId().toString().equals(NETWORK_INSPECTION.get(sessionId)[2])) {
					org.openqa.selenium.devtools.v150.network.model.Response response = responseReceived.getResponse();
					System.out.println("Matched inspection request [" + method + "@" + murl + "] on CDP session " + devTools.getCdpSession().toString());
					Headers headers = response.getHeaders();
					String mimeType = null;
					Map<String, Object> headerMap = new HashMap<>();
					for(Map.Entry<String, Object> he: headers.entrySet()) {
						if(he.getKey().equalsIgnoreCase("content-type")) {
							mimeType = he.getValue().toString();
							if(mimeType.indexOf(";")!=-1) {
								mimeType = mimeType.substring(0, mimeType.indexOf(";"));
							}
						}
						headerMap.put(he.getKey(), he.getValue().toString());
					}
					GetResponseBodyResponse grsp = devTools.send(Network.getResponseBody(responseReceived.getRequestId()));
					NETWORK_INSPECTION.get(sessionId)[3] = new Object[] {response.getStatus(), headerMap, mimeType, grsp.getBody()};
				}
			});
			devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));*/

			//devTools.send(Fetch.enable(Optional.of(lrp), Optional.empty()));
			System.out.println("==========Starting network inspection on CDP session");
		}
	}
	
	@SuppressWarnings("unchecked")
	protected void networkApiInspectPost(WebDriver driver, String v1, String v2) {
		String sessionId = ((RemoteWebDriver)driver).getSessionId().toString();
		if(/*BROWSER_FEATURES.containsKey(sessionId+".NETWORK_RES") && */state.NETWORK_INSPECTION.containsKey(sessionId)) {
			int counter = 0;
			while(state.NETWORK_INSPECTION.get(sessionId)[3]==null && counter++<60) {
				if(___cxt___.isStopExecSet()) {
					throw new RuntimeException("Stopped Execution");
				}
				System.out.println("Waiting for network API response for ["+state.NETWORK_INSPECTION.get(sessionId)[0].toString() 
						+  "->" + state.NETWORK_INSPECTION.get(sessionId)[1].toString() + "]... attempt " + counter);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				}
			}
			if(state.NETWORK_INSPECTION.get(sessionId)[3]==null) {
				throw new RuntimeException("No valid API response detected for ["+state.NETWORK_INSPECTION.get(sessionId)[0].toString() 
						+  "->" + state.NETWORK_INSPECTION.get(sessionId)[1].toString() + "]");
			}
			if(state.NETWORK_INSPECTION.get(sessionId)[3]!=null) {
				Object[] res = (Object[])state.NETWORK_INSPECTION.get(sessionId)[3];
				int status = (Integer)res[0];
				Map<String, Object> headers = (Map<String, Object>)res[1];
				String mimeType = (String)res[2];
				String body = (String)res[3];
				switch (v1) {
					case "status":
						___cxt___add_param__("apiStatus", status);
						break;
					case "header":
						if(v2!=null && headers.containsKey(v2)) {
							___cxt___add_param__("apiHeader", headers.get(v2).toString());
						}
						break;
					case "json":
						if(v2!=null && mimeType!=null && mimeType.toLowerCase().startsWith("application/json")) {
							String[] params = v2.split(",");
							int cindex = 1;
							for (String param : params) {
								String[] det = param.split("@");
								String vname = null;
								String path = null;
								if(det.length==1) {
									vname = "apiJson" + cindex++;
									path = det[0].trim();
								} else {
									vname = det[0].trim();
									path = det[1].trim();
								}
								if(state.BROWSER_FEATURES.containsKey(sessionId+".NWCONSOLE") && state.BROWSER_FEATURES.get(sessionId+".NWCONSOLE")) {
									System.out.println("Fetching " + path + " from [" + body + "]");
								}
								___cxt___add_param__(vname, JsonPath.read(body, path));
							}
						}
						break;
					default:
						break;
				}
			}
			
			if(driver instanceof HasDevTools) {
				//DevTools devTools = ((HasDevTools)driver).getDevTools();
				System.out.println("==========Closing network inspection on CDP session");
			}
			
			state.NETWORK_INSPECTION.remove(sessionId);
		}
	}
	
	protected void switchToFrame(WebDriver d, String selector) {
		if(StringUtils.isBlank(selector) || selector.trim().equalsIgnoreCase("main")) {
			d.switchTo().defaultContent();
			return;
		}
		
		if(selector.trim().equalsIgnoreCase("parent")) {
			d.switchTo().parentFrame();
			return;
		}
		
		if(selector.indexOf("@")!=-1) {
			List<WebElement> els = getElements(d, d, selector, null, null, null);
			if(els.size()>0) {
				d.switchTo().frame(els.get(0));
			}
		}
		
		try {
			d.switchTo().frame(Integer.parseInt(selector));
		} catch (NumberFormatException e) {
			d.switchTo().frame(selector);
		}
	}
	
	protected boolean handleAlertConfirm(WebDriver d, boolean isAlert, boolean confirmIsOk, String value) {
		int counter = 1;
		while(counter++<11) {
			if(___cxt___.isStopExecSet()) {
				throw new RuntimeException("Stopped Execution");
			}
			try {
				Alert alert = d.switchTo().alert();
				if(isAlert) {
					alert.accept();
				} else {
					if(confirmIsOk) 
						alert.accept();
					else 
						alert.dismiss();
				}
				return value!=null?true:alert.getText().equals(value);
			} catch (Exception e) {
			}
			sleep(1000);
		}
		return false;
	}
	
	protected void setupFileVar(String regex, String[] vars, String[] pos) {
		Pattern pr = Pattern.compile(regex);
		Matcher m = pr.matcher(get__loopcontext__var("a1"));
		if(m.matches()) {
			for (int i=0;i<vars.length;i++) {
				String varv = pos[i];
				for (int j = 0; j < m.groupCount(); j++) {
					varv = varv.replace("${"+(j+1)+"}", m.group(j+1));
					varv = varv.replace("$"+(j+1), m.group(j+1));
				}
				if(vars[i].startsWith("@")) {
					___cxt___add_param__(vars[i], varv);
				} else {
					newProvider(get__loopcontext__var("n")+"_rf");
					set__provname__(get__loopcontext__var("n")+"_rf");
					set__provpos__(get__loopcontext__var("n")+"_rf", get__loopcontext__indx());
				}
			}
		}
	}
	
	public static interface UtilDateF {
		public String f();
	}
	public static interface UtilDateFS {
		public String f(int days, String fmt);
	}
	
	public static class Util {
		public static String random(String typstr) {
			return randomize(typstr);
		}
		
		private static String dateArith(String what, int howMuch, String fmt) {
			if(fmt==null) fmt = "dd/MM/yyyy HH:mm:ss";
			DateTime dt = new DateTime();
			if(what!=null) {
				switch(what) {
					case "h":
						dt = dt.plusHours(howMuch);
						break;
					case "mi":
						dt = dt.plusMinutes(howMuch);
						break;
					case "s":
						dt = dt.plusSeconds(howMuch);
						break;
					case "ms":
						dt = dt.plusMillis(howMuch);
						break;
					case "d":
						dt = dt.plusDays(howMuch);
						break;
					case "m":
						dt = dt.plusMonths(howMuch);
						break;
					case "w":
						dt = dt.plusWeeks(howMuch);
						break;
					case "y":
						dt = dt.plusYears(howMuch);
						break;
					default: break;
				}
			}
			return dt.toString(fmt);
		}
		
		public static String today() {
			return dateArith(null, 0, "dd/MM/yyyy");
		}
		public static String yesterday() {
			return dateArith("d", -1, "dd/MM/yyyy");
		}
		public static String tomorrow() {
			return dateArith("d", 1, "dd/MM/yyyy");
		}
		public static String someDay(int days, String fmt) {
			return dateArith("d", days, StringUtils.isNotBlank(fmt)?fmt:"dd/MM/yyyy");
		}

		public static String lastWeek() {
			return dateArith("w", -1, "dd/MM/yyyy");
		}
		public static String nextWeek() {
			return dateArith("w", 1, "dd/MM/yyyy");
		}
		public static String someWeek(int weeks, String fmt) {
			return dateArith("w", weeks, StringUtils.isNotBlank(fmt)?fmt:"dd/MM/yyyy");
		}
		
		public static String lastMonth() {
			return dateArith("m", -1, "dd/MM/yyyy");
		}
		public static String nextMonth() {
			return dateArith("m", 1, "dd/MM/yyyy");
		}
		public static String someMonth(int months, String fmt) {
			return dateArith("m", months, StringUtils.isNotBlank(fmt)?fmt:"dd/MM/yyyy");
		}
		
		public static String lastYear() {
			return dateArith("y", -1, "dd/MM/yyyy");
		}
		public static String nextYear() {
			return dateArith("y", 1, "dd/MM/yyyy");
		}
		public static String someYear(int years, String fmt) {
			return dateArith("y", years, StringUtils.isNotBlank(fmt)?fmt:"dd/MM/yyyy");
		}
		
		public static String now() {
			return dateArith(null, 0, "HH:mm:ss");
		}
		
		public static String lastSecond() {
			return dateArith("s", -1, "HH:mm:ss");
		}
		public static String nextSecond() {
			return dateArith("s", 1, "HH:mm:ss");
		}
		public static String someSecond(int secs, String fmt) {
			return dateArith("s", secs, StringUtils.isNotBlank(fmt)?fmt:"HH:mm:ss");
		}
		
		public static String lastMinute() {
			return dateArith("mi", -1, "HH:mm:ss");
		}
		public static String nextMinute() {
			return dateArith("mi", 1, "HH:mm:ss");
		}
		public static String someMinute(int mins, String fmt) {
			return dateArith("mi", mins, StringUtils.isNotBlank(fmt)?fmt:"HH:mm:ss");
		}
		
		public static String lastHour() {
			return dateArith("h", -1, "HH:mm:ss");
		}
		public static String nextHour() {
			return dateArith("h", 1, "HH:mm:ss");
		}
		public static String someHour(int hours, String fmt) {
			return dateArith("h", hours, StringUtils.isNotBlank(fmt)?fmt:"HH:mm:ss");
		}
		
		public static UtilDateF today = () -> {
			return dateArith(null, 0, "dd/MM/yyyy");
		};
		public static UtilDateF yesterday = () -> {
			return dateArith("d", -1, "dd/MM/yyyy");
		};
		public static UtilDateF tomorrow = () -> {
			return dateArith("d", 1, "dd/MM/yyyy");
		};
		public static UtilDateFS day = (int days, String fmt) -> {
			return dateArith("d", days, StringUtils.isNotBlank(fmt)?fmt:"dd/MM/yyyy");
		};

		public static UtilDateF lastWeek = () -> {
			return dateArith("w", -1, "dd/MM/yyyy");
		};
		public static UtilDateF nextWeek = () -> {
			return dateArith("w", 1, "dd/MM/yyyy");
		};
		public static UtilDateFS week = (int weeks, String fmt) -> {
			return dateArith("w", weeks, StringUtils.isNotBlank(fmt)?fmt:"dd/MM/yyyy");
		};
		
		public static UtilDateF lastMonth = () -> {
			return dateArith("m", -1, "dd/MM/yyyy");
		};
		public static UtilDateF nextMonth = () -> {
			return dateArith("m", 1, "dd/MM/yyyy");
		};
		public static UtilDateFS month = (int months, String fmt) -> {
			return dateArith("m", months, StringUtils.isNotBlank(fmt)?fmt:"dd/MM/yyyy");
		};
		
		public static UtilDateF lastYear = () -> {
			return dateArith("y", -1, "dd/MM/yyyy");
		};
		public static UtilDateF nextYear = () -> {
			return dateArith("y", 1, "dd/MM/yyyy");
		};
		public static UtilDateFS year = (int years, String fmt) -> {
			return dateArith("y", years, StringUtils.isNotBlank(fmt)?fmt:"dd/MM/yyyy");
		};
		
		public static UtilDateF now = () -> {
			return dateArith(null, 0, "HH:mm:ss");
		};
		
		public static UtilDateF lastSecond = () -> {
			return dateArith("s", -1, "HH:mm:ss");
		};
		public static UtilDateF nextSecond = () -> {
			return dateArith("s", 1, "HH:mm:ss");
		};
		public static UtilDateFS second = (int secs, String fmt) -> {
			return dateArith("s", secs, StringUtils.isNotBlank(fmt)?fmt:"HH:mm:ss");
		};
		
		public static UtilDateF lastMinute = () -> {
			return dateArith("mi", -1, "HH:mm:ss");
		};
		public static UtilDateF nextMinute = () -> {
			return dateArith("mi", 1, "HH:mm:ss");
		};
		public static UtilDateFS minute = (int mins, String fmt) -> {
			return dateArith("mi", mins, StringUtils.isNotBlank(fmt)?fmt:"HH:mm:ss");
		};
		
		public static UtilDateF lastHour = () -> {
			return dateArith("h", -1, "HH:mm:ss");
		};
		public static UtilDateF nextHour = () -> {
			return dateArith("h", 1, "HH:mm:ss");
		};
		public static UtilDateFS hour = (int hours, String fmt) -> {
			return dateArith("h", hours, StringUtils.isNotBlank(fmt)?fmt:"HH:mm:ss");
		};
		
		public static String g(UtilDateF f1, UtilDateF f2) {
			return g(f1, f2, " ");
		}
		public static String g(UtilDateF f1, UtilDateF f2, String del) {
			return StringUtils.joinWith(del, f1.f(), f2.f());
		}
		public static String g(UtilDateFS f1, int p1, String fmt1, UtilDateFS f2, int p2, String fmt2) {
			return g(f1, p1, fmt1, f2, p2, fmt2, " ");
		}
		public static String g(UtilDateFS f1, int p1, String fmt1, UtilDateFS f2, int p2, String fmt2, String del) {
			return StringUtils.joinWith(del, f1.f(p1, fmt1), f2.f(p2, fmt2));
		}
		public static String pnf(String date, String informat, String outformat) {
			return DateTime.parse(date, DateTimeFormat.forPattern(informat)).toString(outformat);
		}
	}
	
	public static String readFileToStr(String file) {
		try {
			return FileUtils.readFileToString(new File(file), "UTF-8");
		} catch (Exception e) {
		}
		return null;
	}
	
	public static byte[] readFileToBytes(String file) {
		try {
			return FileUtils.readFileToByteArray(new File(file));
		} catch (Exception e) {
		}
		return null;
	}
	
	protected void checkMail(String tname, String from, String to, String subject, String content, int timeout) {
		String stname = get__subtestname__();
		try {
			__ctxQuiet__ = true;   // H3: a simulator check drives no browser: no context
			try { set__subtestname__(tname, tname); } finally { __ctxQuiet__ = false; }
			if(___cxt___.simulatorEventCheck("mail", new Object[] {from, to, subject, content, timeout})) {
				throw new PassSubTestException(tname);
			}
			throw new FailSubTestException(tname + " --- failed");
		} finally {
			reset__subtestname__(stname);
		}
	}
	
	protected boolean checkHttpRequest(String tname, String from, String to, String content, int timeout) {
		String stname = get__subtestname__();
		try {
			__ctxQuiet__ = true;   // H3: a simulator check drives no browser: no context
			try { set__subtestname__(tname, tname); } finally { __ctxQuiet__ = false; }
			if(___cxt___.simulatorEventCheck("http", new Object[] {from, to, content, timeout})) {
				throw new PassSubTestException(tname);
			}
			throw new FailSubTestException(tname + " --- failed");
		} finally {
			reset__subtestname__(stname);
		}
	}

	public static class TestState {
		private long timeoutSleepGranularity = 1000;
		protected transient Map<String, org.openqa.selenium.Capabilities> driverCaps = new ConcurrentHashMap<>();
		protected transient Map<String, Boolean> wdmSessions = new ConcurrentHashMap<>();
		List<SeleniumTestSession> sessions = new ArrayList<SeleniumTestSession>();
		protected String cfileName;
		protected int line;
		protected String basePath;
		protected String name;
		protected List<String[]> possibleInvXpathExprs = new ArrayList<>();
		protected transient int sessionNum = -1;
		protected int index;
		private final Map<String, Boolean> BROWSER_FEATURES = new ConcurrentHashMap<String, Boolean>();
		private String outPath;
		private AtomicReference<SeleniumTest> _dynTstObj = new AtomicReference<>();
		private final List<String> tabList = Collections.synchronizedList(new ArrayList<>());
		private boolean logconsole, logdebug, lognw, hasNetapixCommand;
		private final Map<String, Object[]> NETWORK_INSPECTION = new ConcurrentHashMap<>();
		private transient FileTime lastModifFileTime = null;
	  }
}
