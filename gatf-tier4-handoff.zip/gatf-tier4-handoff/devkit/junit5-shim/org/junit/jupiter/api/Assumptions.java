package org.junit.jupiter.api;
/** JUnit 5 shim: a failed assumption is reported as a failure with SKIP in its message (the shim has no skipped state). */
public final class Assumptions {
  private Assumptions() {}
  public static void assumeTrue(boolean b) { assumeTrue(b, "assumption failed"); }
  public static void assumeTrue(boolean b, String m) { if (!b) throw new IllegalStateException("SKIP " + m); }
  public static void assumeFalse(boolean b, String m) { assumeTrue(!b, m); }
}
