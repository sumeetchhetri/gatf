# Builder prompt (one account per card, model Opus 5.5)

Attach `gatf-src-<date>.zip` (the latest green tree) and `gatf-tier4-handoff.zip`, then paste this, with the placeholders filled. The orchestrator issues the exact list of orchestrator constraints per card.

```
go <NNN>
Model: Opus 5.5.

Setup (do this yourself first): unzip gatf-src-<date>.zip into ./gatf and gatf-tier4-handoff.zip into
./gatf-tier4-handoff. In ./gatf run `git init && git add -A && git commit -qm base` (the starting point every diff
and the delta zip is taken from). Copy gatf-tier4-handoff/CLAUDE.md into ./gatf and add it to .git/info/exclude so it
never ships. Read CLAUDE.md (rules) and gatf-tier4-handoff/TIER4-CARDS.md (cards, lanes, shared-file rules) before
anything else, follow the CLAUDE.md session procedure end to end, and use gatf-tier4-handoff/devkit/ for the checks
and packing it describes.

Repo: ./gatf. Base: gatf-src-<date>.zip (sha256 <…>), the merged green tree through Δ<last>. Pending deltas: none.
Compile error from the last merge: none. Write the Base line exactly like that in the DELTA md, plus your local
base commit sha.

Lane <A|B|C|D>. Card Δ<NNN> per TIER4-CARDS.md. Other lanes running now: <list>.
Orchestrator constraints: <from the orchestrator, if any>.

Blind verifier: mandatory if your session can spawn a fresh Opus subagent; otherwise do an adversarial self-review
labelled "not blind" (the orchestrator review is then the blind step).
Deliver: gatf-delta-<NNN>-<slug>.zip, gatf-<NNN>.sha256, DELTA-<NNN>.md (format per CLAUDE.md).
```

# Explore agent (optional, inside the builder session)
```
Map touchpoints for card Δ<NNN> (<title>) in ./gatf: the files, line numbers, signatures and short excerpts for <list
from TIER4-CARDS.md>, which of them are CRLF (`file`), existing tests to copy conventions from, and how the feature
would be invoked end to end. Facts only, under 1000 words.
```
