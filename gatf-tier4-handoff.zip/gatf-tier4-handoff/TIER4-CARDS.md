# GATF Tier 4 cards (Δ164–Δ183): API · Load · Workflow · RPA leadership

Tiers 1–3 brought GATF to Playwright parity, and ahead of it on traces, coverage insight and mobile. Tier 4 widens the lead where Playwright doesn't compete at all: protocol testing, load as a first-class SLO tool, workflow hygiene (environments, secrets, data matrices), and unattended RPA.

**Exit criterion:** every card below is Done on Sumeet's green run, plus the re-scored scorecard (Δ183).

Each card's *accept* line is what the orchestrator reviews against. Every builder runs **Opus 5.5** in its own account. The blind verifier is a fresh Opus subagent if the session can spawn one; otherwise the session does an adversarial self-review labelled "not blind", and the orchestrator review is the blind step.

## Lanes and order
Four lanes run in parallel. Within a lane, cards run in order (a card starts once the previous one is merged). The orchestrator 3-way merges across lanes.

| Lane | Cards (in order) | Owns (don't touch from other lanes) |
|---|---|---|
| **A: API protocols** | 164 → 165 → 166 → 167 | `executor/core/TestCaseExecutorUtil` request path, new `com.gatf.protocol.*`, `contract/*`, `imports/OpenApiImporter` |
| **B: Load** | 168 → 169 → 170 → 171 → 172 | `executor/perf/*`, `LoadRunSchedule`, `PerformanceTestCaseExecutor`, `executor/distributed/*` (from 172) |
| **C: Workflow** | 173 → 174 → 175 → 176 → 177 | `GatfExecutorConfig` env/secret fields, `executor/dataprovider/*`, new `com.gatf.secret.*`, `com.gatf.schedule.*`, `com.gatf.notify.*` |
| **D: RPA + hygiene** | 178 → 179 → 180 → 181 → 182 | Desktop driver path (appium-windows / mac2 keys), `ocr`/`readimgtext`/`imgsave` commands, `selenium/plugins/*`, `PdfTables`, `PluginRegistry` |
| **Close** | 183 | orchestrator |

Δ174 (secrets) is cross-cutting: once it merges, every later card in every lane must route secret values through its redactor.

## Shared-file rules (all lanes)
- `README.md`, `docs/seleasy/REFERENCE.md`, `docs/configuration.md`, `GatfCli.java` (CRLF), `pom.xml` (CRLF), `GatfExecutorConfig.java` (CRLF), `frontend/src/api.ts`, App/Shell routing, `commands.json` and its copies (`frontend/src/config/seleasyCommands.json`, `vscode-extension/src/commands.json`; regenerate with `tools/gen-commands`, never hand-edit):
  - touch them minimally and append-only;
  - list each one in a "Shared files" section of the DELTA md, with line ranges.
- New seleasy commands:
  - add the parser branch in `Command.java` (CRLF, binary-safe);
  - add docs in `REFERENCE.md`;
  - regenerate `commands.json` and its copies;
  - make a decision in `export/ExportCatalog` for every backend (the drift test enforces this);
  - add a new numbered codegen-corpus `.sel` (golden by Sumeet's `-Dgatf.golden.update=true`);
  - mirror the parse in `export/SelParser` and keep `ExportParserParityTest` green.
- New runtime dependencies: say why in the DELTA md, pin the version, and prefer the JDK. Never add a dependency that phones home.

---

## Lane A: API protocols

### Δ164: GraphQL first-class
- **Scope:**
  - a `graphql` request type for API test cases (XML/JSON case model) and a seleasy `api`-step form: query/mutation, variables (templated), operationName, persisted-query hash;
  - GraphQL-aware assertions: `errors` empty / contains, `data` JSONPath;
  - optional schema check via introspection (cached per run).
- **Accept:** a case against a public-style GraphQL fixture server passes, a schema-violating query fails with the GraphQL error surfaced, and the Postman importer's GraphQL bodies map to the new type.
- **Verify:** R1 builder/assertions · R2 against an in-process fixture server (JDK HttpServer).
- **Touchpoints:** `executor/core/TestCaseExecutorUtil` (request build), `imports/PostmanImporter.java` (GraphQL today), the API case model, `contract/*` for schema reuse.
- **Pitfalls:**
  - HTTP 200 with `errors` is a failure unless the case expects it;
  - variables are templated (`${…}`) but never string-spliced into the query text.

### Δ165: gRPC via server reflection
- **Scope:**
  - a `grpc` request type with unary and server-streaming calls;
  - the service/method is resolved by server reflection, or from a `.proto` / descriptor set file;
  - the JSON request body is converted to protobuf, and the response to JSON for the existing assertions;
  - metadata headers, deadlines, TLS / plaintext.
- **Accept:** unary and server-stream cases pass against an in-process gRPC fixture, and a status-code assertion (`NOT_FOUND`) works.
- **Verify:** R1 JSON↔proto mapping · R2 in-process server.
- **Touchpoints:** new `com.gatf.protocol.grpc`, the request type switch in `TestCaseExecutorUtil`, the case model.
- **Pitfalls:**
  - the grpc-java + protobuf dependency is large: shade it, keep it inside the fat jar, and say so;
  - reflection is not always enabled, so the descriptor-file path must work alone;
  - load use comes later (168 hooks it into the SPI).

### Δ166: WebSocket / SSE steps
- **Scope:**
  - API cases and seleasy steps to connect (headers/subprotocol), send text/JSON, and expect a message (JSON match / regex) within a timeout;
  - SSE subscribe with event-type filters;
  - close codes;
  - transcripts land in the report (and in the trace for UI-adjacent use).
- **Accept:** a chat-style WS fixture and an SSE fixture each pass a send→expect flow, and a timeout fails with the transcript shown.
- **Verify:** R1 matcher/transcript · R2 against in-process WS/SSE fixtures (JDK `HttpClient.newWebSocket` / plain HTTP SSE).
- **Touchpoints:** new `com.gatf.protocol.ws`, `Command.java` (new step, CRLF), `commands.json`, `REFERENCE.md`, `ExportCatalog`.
- **Pitfalls:** bounded buffers (cap the messages kept per connection); never block the run thread without a timeout.

### Δ167: OpenAPI drift report (residual of p01)
- **Scope:** spec vs. live:
  - operations in the spec with no executed case;
  - observed endpoints (from run HARs / API logs) missing from the spec;
  - response shapes that differ from the schema across the run.

  Output is a report page plus JSON.
- **Accept:** on the Petstore fixtures, the drift report lists an undocumented endpoint and an untested operation.
- **Verify:** R1 drift computation · vitest page.
- **Touchpoints:** `imports/OpenApiImporter.java`, `contract/*` (Δ121 validator), `/api/reports`, the frontend report views.

---

## Lane B: Load

### Δ168: Open-model scenarios on the perf-engine SPI
- **Scope:**
  - arrival-rate stages (ramp, constant, spike, step), defined once in config and mapped to each engine through the Δ140 `PerfEngine` SPI (vegeta rate, wrk2 `-R`, autocannon `--overallRate`, wperfk);
  - engines that can't do open-model refuse with a clear message;
  - folded in from Δ144: flow load tests keep cookies and apply `loadConfig` instead of only returning it;
  - folded in from Δ140: wperfk download, checksum-pinned and opt-in.
- **Accept:** a ramp→constant→spike scenario runs on vegeta and wrk2 with the achieved rate within 10 % of the target in the summary.
- **Verify:** R1 stage→engine-args mapping · R2 with a fake engine binary.
- **Touchpoints:** `executor/perf/{PerfEngine,PerfEngines,PerfArgs,PerfSummary}.java`, `LoadRunSchedule.java`, `imports/FlowToLoad` (Δ144).

### Δ169: SLO thresholds that fail the run
- **Scope:**
  - thresholds (p50/p95/p99 latency, error rate, min throughput, per endpoint or global) declared in config, evaluated on `PerfSummary`;
  - they fail the run with a non-zero exit, JUnit/CI output, and a report section showing breaches;
  - abort-early when a threshold is already lost (opt-in).
- **Accept:** the same load run passes with loose thresholds and fails (exit ≠ 0, breach listed) with a tight p95.
- **Verify:** R1 evaluator · R2 with canned summaries.
- **Touchpoints:** `PerfSummary`, `log/CiReports`, the report handler, `GatfCli` exit codes (CRLF).

### Δ170: Live load metrics export
- **Scope:**
  - exporters for OTLP (HTTP/JSON), Prometheus remote-write, and InfluxDB line protocol: RPS, latency histograms/percentiles, errors, active users, tagged by run/scenario/endpoint;
  - push interval configurable;
  - off by default.
- **Accept:** a load run streams metrics to a local fixture receiver for each protocol, and the values match the final summary within rounding.
- **Verify:** R1 encoders · R2 in-process receivers.
- **Touchpoints:** new `com.gatf.executor.perf.metrics`, the engine output parsers, `PerfSummary`.
- **Pitfalls:**
  - no secrets in labels;
  - a failing exporter never fails the run;
  - bounded queue with drop counting.

### Δ171: Live load view in the SPA
- **Scope:** during a run, a live chart of RPS, latency percentiles, errors and active users, plus threshold lines from 169, fed by an SSE/WebSocket endpoint from the same metric stream as 170.
- **Accept:** starting a load run from the UI shows live updating charts, and the final numbers equal the summary.
- **Verify:** vitest (stream reducer, chart) · R1 endpoint.
- **Touchpoints:** `ui/*` handler (auth like the other endpoints), `frontend/src/views/*`, `api.ts` (shared).

### Δ172: Elastic load workers (Docker / Kubernetes)
- **Scope:**
  - launch N workers as Docker containers or a Kubernetes Job from the coordinator, on top of `DistributedExecution` (TLS + shared secret, protocol v2 from Δ162);
  - wait for readiness, run, collect, tear down;
  - the worker image is the existing jar on the official JRE image.
- **Accept:** a run with `workers: {mode: docker, count: 3}` starts 3 workers, distributes, merges results, and removes the containers; the k8s mode renders a valid Job manifest and runs against a kind/minikube cluster on Sumeet's side.
- **Verify:** R1 manifest/command builders · R2 with a fake docker CLI.
- **Touchpoints:** `executor/distributed/*`, `LoadRunSchedule`, config.
- **Pitfalls:**
  - the shared secret is passed as a Docker/K8s secret, never as an env var in plain manifests that end up in logs;
  - always tear down on failure (finally + label-based cleanup).

---

## Lane C: Workflow

### Δ173: Environment profiles
- **Scope:**
  - named profiles (`dev`, `staging`, `prod`, …) that overlay config values, base URLs and data-provider settings;
  - selected by `--env` / `GATF_ENV` / UI dropdown;
  - the active profile is shown in reports and traces.
- **Accept:** the same suite runs against two profiles with different base URLs, and the reports name the profile.
- **Verify:** R1 overlay merge · R2 CLI.
- **Touchpoints:** `GatfExecutorConfig` (CRLF), the config loader, `RunOverrides`, `GatfCli` (CRLF), the UI config view.

### Δ174: Secret references + global masking
- **Scope:**
  - secret refs in config, test data and seleasy (`${secret:NAME}`), resolved from env, file or HashiCorp Vault (KV v2, token/AppRole from env);
  - one global redactor that masks every resolved secret value (and its 12+ char slices, as `AiSecret` does) in reports, traces (HAR bodies/headers, console, DOM snapshots' text), logs, the run console and MCP replies.
- **Accept:**
  - a run that types a Vault-sourced password and sends it in a header produces reports, traces and logs where the value never appears (a leak test greps every output);
  - Vault is unreachable → the run stops before any test with a clear message.
- **Verify:** R1 resolver + redactor · R2 a fake Vault server · the leak test.
- **Touchpoints:**
  - new `com.gatf.secret`;
  - `WorkflowContextHandler` / `SeleniumTest.evaluate` (resolution);
  - every writer: `TraceRecorder` / recorders, report handler, `RunConsole`, MCP.
- **Pitfalls:**
  - masking must not break HAR JSON or zip integrity;
  - secrets never enter the export (Δ160/161 keep `env()` refs);
  - `evaluate` multi-provider re-templating (noted in Δ148b) must not resolve a secret ref twice into logs.

### Δ175: Data-matrix runs
- **Scope:**
  - run a suite over a matrix of data providers / profiles / browsers (cartesian or zip), with per-row reporting, per-row trace names, and sharding-aware distribution (Δ131) of rows;
  - one failing row doesn't stop the others.
- **Accept:** a 3×2 matrix runs 6 rows, the report groups them, and a sharded run splits rows deterministically.
- **Verify:** R1 matrix expansion + shard split · R2 small suite.
- **Touchpoints:** `executor/dataprovider/*`, `ShardSplitter`, the report model, `merge-reports`.

### Δ176: Unattended runs: schedules + triggers
- **Scope:**
  - server-side schedules (cron syntax, per-suite, with timezone);
  - triggers: a webhook (HMAC-signed), a file drop (watched dir), and a git ref change (polling);
  - run history with status/duration/links;
  - no overlapping runs of one schedule (skip or queue, configurable).
- **Accept:** a cron schedule and a signed webhook each start a run that appears in history, an unsigned webhook is refused, and an overlapping fire is skipped and logged.
- **Verify:** R1 cron parser + scheduler with a fake clock · R2 webhook handler.
- **Touchpoints:** new `com.gatf.schedule`, `ui/*` (auth + HMAC), `LoadRunSchedule` (reuse, don't fork), the frontend run history view.

### Δ177: Notifications
- **Scope:**
  - email, Slack, Microsoft Teams and generic webhook on run end;
  - rules: on fail, on recover, always;
  - message templates with a summary, failed tests, links and the profile;
  - attachments optional;
  - all values pass the Δ174 redactor.
- **Accept:** a failing then passing scheduled run sends "failed" then "recovered" to a fixture webhook and a fixture SMTP server, with no secret in either.
- **Verify:** R1 rule engine + templates · R2 fixture receivers.
- **Touchpoints:** new `com.gatf.notify`, `selenium/plugins/MailPlugin` / `simulators/EmailGateway` (reuse the SMTP code), schedule hooks (176).

---

## Lane D: RPA + hygiene

### Δ178: Desktop automation (Appium Windows / Mac2)
- **Scope:**
  - `open appium-windows` / `appium-mac2` driving desktop apps through the existing seleasy commands;
  - window/app selection, accessibility-id / name locators mapped to seleasy locators;
  - builds on Δ158's Appium path.
- **Accept:** a Notepad (Windows) or TextEdit (macOS) script types text and asserts it, on Sumeet's machine. R2 proves the command → driver calls.
- **Verify:** R2 proxy driver · live run on Sumeet's side.
- **Touchpoints:** `DriverInitCodegen` / `BrowserDrivers` (appium-* keys from Δ158), `Command.java` locator parsing (CRLF), `commands.json`.
- **Pitfalls:**
  - web-only commands on a desktop session give a clear step error;
  - no change to web codegen (goldens identical).

### Δ179: Image / OCR locators
- **Scope:**
  - `image@"file.png"` (template match with a threshold, multi-scale) and `ocr@"text"` locators that resolve to a screen region;
  - click/hover/type at that region (web via screenshot coordinates; desktop via the session);
  - the existing `ocr` / `readimgtext` / `imgsave` commands reuse the same engine.
- **Accept:** clicking a canvas-drawn button by `image@` and by `ocr@` works on a fixture page, and a below-threshold match fails clearly.
- **Verify:** R1 matcher on fixture images · R2 click mapping.
- **Touchpoints:** `Command.java` (`ocr`, `readimgtext`, `imgsave` branches, CRLF), `SemanticLocators` (strictness: more than one match is an error), existing OCR / image dependencies.
- **Pitfalls:** device-pixel-ratio scaling; strict mode (more than one match is an error, as for semantic locators).

### Δ180: Document step library (Excel / PDF / email)
- **Scope:** first-class steps (replacing ad-hoc plugin calls):
  - Excel read/write cells, ranges and tables (POI);
  - PDF text, tables (`PdfTables`) and form fields;
  - email send/receive-and-assert (IMAP/POP3 fetch with filters, attachments).

  Results go into variables for later steps.
- **Accept:** a script reads an invoice PDF table, writes an Excel summary, and asserts a received email with that attachment against fixture SMTP/IMAP servers.
- **Verify:** R1 per step · R2 fixture mail servers.
- **Touchpoints:** `selenium/PdfTables.java`, `selenium/plugins/MailPlugin.java`, `simulators/EmailGateway.java`, `Command.java` (CRLF), `commands.json`, `REFERENCE.md`, `ExportCatalog`.
- **Pitfalls:** file paths confined to the project; mail credentials via Δ174 secret refs.

### Δ181: Plugin + engine hygiene
- **Scope:** carried items:
  - Δ139: a plugin name shadowing a built-in (rule: built-ins win, a warning names the plugin), and a jar rebuilt with the same size/mtime is reloaded (content hash);
  - Δ142: watch focus combined correctly with `--grep` / `--tag` (AND, not OR);
  - the plugin defects audit list (§7.4), re-checked and closed.
- **Accept:** each carried item has a regression test, and the §7.4 list is marked closed in the DELTA md.
- **Verify:** R1 per item.
- **Touchpoints:** `PluginRegistry`, the watch planner, `selenium/plugins/*`.

### Δ182: Command.java extraction, step 1 (P2-2, golden-gated)
- **Scope:**
  - move the per-command parse branches of one family (navigation + waits) out of `Command.java` (~9k lines, CRLF) into separate classes behind the existing dispatch;
  - no behaviour change, and every codegen golden byte-identical.
- **Accept:** `CodegenGoldenTest`, `ExportParserParityTest` and the full suite are green with zero golden changes; `Command.java` shrinks by the moved lines.
- **Verify:** golden + parity tests on Sumeet's mvn · R4 · a diff audit.
- **Pitfalls:**
  - incremental only, one family;
  - line-map (`GATF_LINE`) behaviour for the debugger must be unchanged (the debugger e2e must stay green).

---

## Δ183: Tier 4 close-out (orchestrator)
- **Scope:** re-score the scorecard (`GATF_REVIEW_AND_ROADMAP.md`), write the release notes and update the roadmap status; audit the Δ164–Δ182 range.
- **Accept:** every Tier 4 card is Done on Sumeet's green run.

## Not in Tier 4 (with reason)
- **Component testing, multi-language bindings:** as Tier 3, low fit.
- **Retiring `CdpTransport` for BiDi-only:** browsers' BiDi coverage is not yet complete (CPU, coverage, screencast). Revisit at Tier 5.
- **`evaluate()` multi-provider re-templating:** documented limitation (Δ145c); revisit only if a real script hits it.
