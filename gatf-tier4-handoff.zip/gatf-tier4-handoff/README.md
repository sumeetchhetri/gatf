# GATF Tier 4 handoff kit

**Sumeet:** attach this zip and the latest `gatf-src-<date>.zip` to each developer account, then paste the card's prompt (template in `PROMPTS.md`; the orchestrator issues each card's constraints). The session does its own setup.

| File | For |
|---|---|
| `CLAUDE.md` | The session's working rules (copied into the repo root by the session, never shipped). |
| `TIER4-CARDS.md` | Cards Δ164–Δ183, the four lanes, ownership and shared-file rules. |
| `PROMPTS.md` | Builder prompt template. |
| `devkit/` | The session's own checks: `eol.sh` (line endings), `ParseCheck.java` (Java parses), `run-shim-tests.sh` + `junit5-shim/` (JUnit 5 without Maven), `pack.sh` (zip + sha256 + DELTA md), `chaincheck.sh` (source + deltas = tree). |
| `examples/` | Two reference DELTA mds. |

**Gate:** send each delta's zip, sha256 and DELTA md to the orchestrator session. It reviews, 3-way merges the lanes, and returns repacked zips plus a merge order. Merge, then run `mvn -B clean verify`, e2e and smoke.
