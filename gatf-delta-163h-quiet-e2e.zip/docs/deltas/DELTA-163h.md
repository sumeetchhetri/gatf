# DELTA-163h: a debug session no longer deletes a live run's reports + quieter e2e logs

Session Tier 3 · Δ163h (orchestrator) · 2026-10-15

Base: the tree through Δ163g.

## Summary
The e2e suite passes against the Grid, but its log had three kinds of exceptions. One was a real bug.

1. **Bug: starting a debug session deleted the running workflow's reports.**
   - **What you saw.** `java.io.FileNotFoundException: …/out/<runId>/LRun-1-1-1-1-chrome-0.html (No such file or directory)` and the same for the PDF, `LRun-1-1-selenium-index.html` and `selenium-index.html`. They appeared only when `app-debugger.spec.ts` ran beside `app-workflow-grid.spec.ts`.
   - **Why.** `AcceptanceTestContext.validateAndInit(true)` cleans the out dir. When no run is registered in `ReportHandler`, it deletes the whole `out/`; otherwise it deletes the unregistered 36-character dirs. That registry is per JVM.
     - The debugger's debuggee is a separate JVM (`SeleniumTest.main`). It has nothing registered, so it deleted `out/` and the live run's `out/<runId>/` with it, and every later report write failed.
     - `Command.validateSel` (`-validate-sel`, and the record, import, crawl and reports handlers) and `SelSuiteGate` (`gatf generate`, MCP generate) call the same method. They can do the same when their JVM has no run registered.
   - **Fix.**
     - New overload `validateAndInit(boolean flag, boolean cleanOut)`. With `cleanOut=false` it deletes nothing under the out dir and only creates the dir if it's missing.
     - `validateAndInit(flag)` is `validateAndInit(flag, true)`, so the run paths are unchanged.
     - The debuggee, `validateSel` and `SelSuiteGate` pass `(true, false)`.
2. **Stop printed a `WebDriverException`.**
   - **What you saw.** `Unable to execute request for an existing session … executeScript … SeleniumTest.main`.
   - **Why.** Δ163g's shutdown hook quits the browser while the script thread is mid-command, so that command fails and prints. The failure is expected.
   - **Fix.** The hook first points `System.out` and `System.err` at a null stream, then calls `quitAll()`. The JVM is exiting, so nothing useful is lost.
3. **Each failed step printed three stack traces, plus a fourth for the run.**
   - **What you saw** for one `ERR_NAME_NOT_RESOLVED`:
     - a raw `WebDriverException` trace;
     - an `InvocationTargetException` trace;
     - `Error occurred on line no 6` with a `FailureException` trace that repeats the same message;
     - then, at the end of the run, a bare `GatfRunTimeErrors` trace.
   - **Fixes:**
     - `___invoke_sub_test_dyn___` had a leftover `e.printStackTrace()` on `InvocationTargetException` (the cause is rethrown anyway). It's removed.
     - When the outer `FailureException` wraps a plain `RuntimeException` whose trace the sub-test's result already printed (`SeleniumTestResult.stackAlreadyPrinted`), it prints the line number, the message's first line and the screenshot path, without the trace.
     - In `GatfPluginExecutionHandler`, `GatfRunTimeErrors` (the run's "some scripts failed" signal) prints `N seleasy script failure(s) in this run: see above and the run's report` instead of a stack trace. Every other exception still prints its trace.
   - **Now:** one trace per failure, then `Error occurred on line no N`, the first line of the message, and the screenshot path.
   - **Not changed:** what's recorded in the report, the UI's error JSON, a top-level failure, a `GatfRunTimeError` failure (fail/subtest/xpath), and a checked exception. All of these still print their trace as before.
4. **Labels.** The Δ163g changes were labelled "Δ163h" in four code comments and two release-note lines; they now say Δ163g.

The `ERR_NAME_NOT_RESOLVED` failures themselves are expected: the e2e sample scripts point at `https://demo.gatf.example`, and the spec only checks that the run reaches a terminal state.

## Changes
| Path | A/M/D | Note |
|---|---|---|
| `alldep-jar/src/main/java/com/gatf/executor/core/AcceptanceTestContext.java` | M | CRLF kept. `validateAndInit(flag, cleanOut)`; the old signature delegates with `cleanOut=true` |
| `alldep-jar/src/main/java/com/gatf/selenium/SeleniumTest.java` | M | `main`: `(true, false)`, and the hook silences output; `___invoke_sub_test_dyn___`: stray print removed; `SeleniumTestResult`: `stackAlreadyPrinted` / `firstLine` |
| `alldep-jar/src/main/java/com/gatf/selenium/Command.java` | M | CRLF kept. `validateSel`: `(true, false)` |
| `alldep-jar/src/main/java/com/gatf/selenium/SelSuiteGate.java` | M | `(true, false)` |
| `alldep-jar/src/main/java/com/gatf/ui/GatfPluginExecutionHandler.java` | M | CRLF kept. One line for `GatfRunTimeErrors` |
| `alldep-jar/src/main/java/com/gatf/selenium/DriverInitCodegen.java` | M | CRLF kept. Label only |
| `alldep-jar/src/main/java/com/gatf/selenium/gatfjdb/GatfSelDebugger.java` | M | Label only |
| `alldep-jar/src/test/java/com/gatf/selenium/CommandTest.java` | M | Label only |
| `alldep-jar/src/test/java/com/gatf/selenium/OutDirNoCleanTest.java` | A | 3 tests (below) |
| `docs/release-notes/tier-3.md` | M | Labels only |

## How to apply
```
unzip -oq gatf-delta-163h-quiet-e2e.zip && git add -A && git commit -m "Δ163h: debug sessions keep a live run's reports; quieter failure logs" && git push
mvn -B clean verify                      # OutDirNoCleanTest is new
cd e2e && GATF_SELENIUM_GRID=http://localhost:4444 npm test
```
Expected e2e log: no `FileNotFoundException`, no trace at debugger Stop, and one trace per `ERR_NAME_NOT_RESOLVED` step.

## Verification
- **Cause, from the code and the log.**
  - The debuggee calls `validateAndInit(true)` (`SeleniumTest.main`). With the registry empty, that path is `removeFolder(out)`.
  - The first `FileNotFoundException` (16:04:26) comes right after `Started debug session` (16:04:26.006) and the run's `trace-smoke.sel`. All later report writes for `out/749021159845833/` fail.
- **New tests** in `OutDirNoCleanTest`:
  - `cleanOut=false` keeps `out/<runId>/` and its report, and a 36-character dir as well;
  - it creates a missing `out/`;
  - `stackAlreadyPrinted` is true only for a `FailureException` wrapping a plain `RuntimeException`, and `firstLine` behaves as described.
- **R4:** `ParseCheck`: 9 files, 0 errors.
- **eol.sh:** `eol ok`.
- **Not run here:** `SeleniumTest`, `AcceptanceTestContext` and the handlers can't be compiled in this container (Maven Central is blocked; their dependency set isn't available). So `OutDirNoCleanTest`, the build and the e2e are Sumeet's run. Each call site was checked by reading:
  - the `FailureException.err` field and the `GatfRunTimeError` hierarchy;
  - the `GatfRunTimeErrors` import in the handler;
  - `pushResult` being the only place a `FailureException` is created.

## Gaps
- With a run registered in the server JVM, an in-server `validateAndInit(true)` still deletes unregistered 36-character dirs, and with none registered it deletes `out/`. Examples are the debug dispatcher's and the reports handler's `initilaizeContext(…, true)`. Old reports therefore still don't survive the first run after a server restart. That's pre-existing, and keeping report history is Δ181's `history/` work.
