function syntaxHighlight(json) {
	json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
	return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
		var cls = 'number';
		if (/^"/.test(match)) {
			if (/:$/.test(match)) {
				cls = 'key';
			} else {
				cls = 'string';
			}
		} else if (/true|false/.test(match)) {
			cls = 'boolean';
		} else if (/null/.test(match)) {
			cls = 'null';
		}
		return '<span class="' + cls + '">' + match + '</span>';
	});
}

function escapeHtml(s) {
	return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function printResponse(msg, contentTypeHeader)
{
	var resp = msg;
	if(contentTypeHeader!=null && contentTypeHeader.indexOf('application/json')!=-1)
	{
		resp = syntaxHighlight(msg);
	}
	else if(contentTypeHeader!=null && contentTypeHeader.indexOf('xml')!=-1)
	{
		resp = vkbeautify.xml(resp);
		resp = escapeHtml(resp);
		resp = prettyPrintOne(resp);
	}
	return resp;
}

var dtdatatable = null;
function showTable(reportType, type)
{
	if(dtdatatable)
	{
		dtdatatable.fnDestroy();
	}
	var reports = getTableVals(reportType, type);
	$('#dataTables-example tbody').html('');
	$.each(reports, function(i, item) {
		var reqHeaders = reports[i].testCase.headers;
		var reqhdrsVal = '';
		if(undefined == reqHeaders  || reqHeaders == null)
		{
			reqhdrsVal = 'NA';
		}
		else
		{						
			for (var key in reqHeaders) {
				if (reqHeaders.hasOwnProperty(key)) {
					reqhdrsVal += (key + ": " + reqHeaders[key] + "<br/>");
				}
			}
		}

		if(reqhdrsVal=='')
			reqhdrsVal = 'NA';

		var rescnttyp = 'text/plain';
		var responseHeaders = getData(reports[i].responseHeaders, 'text/plain');
		var reshdrprt = responseHeaders.split('\n');
		for (var j=0;j<reshdrprt.length;j++)
		{
			var resphdr = reshdrprt[j].split("=");
			if(resphdr[0]=='Content-Type' || resphdr[0]=='content-Type'
				|| resphdr[0]=='Content-type' || resphdr[0]=='content-type')
			{
				rescnttyp = resphdr[1];
			}
		}
		responseHeaders = responseHeaders.replace(/=/g, ': ');
		
		var reqcnttyp = reports[i].testCase.headers['Content-Type'];
		if(undefined == reqcnttyp || reqcnttyp==null)
		   reqcnttyp = reports[i].testCase.headers['Content-type'];
		if(reqcnttyp==null)
		   reqcnttyp = reports[i].testCase.headers['content-type'];
		if(reqcnttyp==null)
		   reqcnttyp = reports[i].testCase.headers['content-Type'];
						
		var perfcont = '';					
		var execTimedis = reports[i].executionTime;
		if(undefined!=reports[i].averageExecutionTime && reports[i].averageExecutionTime!=null)
		{
			execTimedis += '<br/><u style="color:black">' + reports[i].numberOfRuns + ' runs<u>';
			execTimedis += '<br/><u style="color:black">' + reports[i].averageExecutionTime + ' ms (avg)<u>';

			perfcont += '<div><p>Statistics: <u style="color:black;font-size:0.90em">Note: For Performance Tests, Request/Response details are taken from the first execution only</u></p><pre>Number of Runs: '+reports[i].numberOfRuns+'</pre>';
			perfcont += '<pre>Total Execution Time: '+reports[i].executionTime+' ms</pre>';
			perfcont += '<pre>Execution Times: '+reports[i].executionTimes.join(' ms, ')+' ms</pre>';
			perfcont += '<pre>Average Execution Time: '+reports[i].averageExecutionTime+' ms</pre></div>';
		}

		var content = '<div id="tddatah-'+i+'">Request, Response Details...</div><div id="tddata-'+i+'" style="display:none">'+perfcont+'<div><p>Request:</p><pre>Actual Url: '+reports[i].actualUrl+'</pre><pre>Template Url: '+reports[i].testCase.url+'</pre><pre>'+reqhdrsVal+'</pre>';
		content += '<pre>'+getData(reports[i].requestContent, reqcnttyp)+'</pre></div>';
		content += '<div><p>Response:</p><pre>'+responseHeaders+'</pre>';
		content += '<pre>'+getData(reports[i].responseContent, rescnttyp)+'</pre></div>';

		var error = getData(reports[i].error, 'text/plain');
		if(error!='NA')
		{
			error = escapeHtml(error);
			content += '<div><p>Errors:</p><pre>'+error+'</pre>';
			content += '<pre>'+escapeHtml(getData(reports[i].errorText, 'text/plain'))+'</pre></div>';
		}
		content += '</div>';

		var identi = reports[i].testIdentifier;
		var idenprt = identi.split("\n");
		identi = '<b>' + idenprt[0] + '</b><br/>' + idenprt[1];

		var glyph = 'glyphicon glyphicon-ok';
		var tr = '<tr>';
		if(reports[i].status=='Failed')
		{
			glyph = 'glyphicon glyphicon-remove';
			tr = '<tr id="dttbtd-'+i+'">';
		}

		$(tr).html(
		"<td>" + identi + "</td><td><span class=\""+glyph+"\"></span>&nbsp;" + reports[i].status + "</td><td>" + execTimedis + "</td><td data-id=\"tddata-"+i+"\" data-hid=\"tddatah-"+i+"\">"+content+"</td>").appendTo('#dataTables-example');					
	});
	dtdatatable = $('#dataTables-example').dataTable({
		"aoColumns": [
						{"sWidth" : "20%"},
						{"sWidth" : "8%"},
						{"sWidth" : "9%"},
						{"sWidth" : "63%"}
					 ],
		"bPaginate": true,
		"bFilter": true,
		"bSort": true,
		"bJQueryUI": true,
		"fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
			if(undefined != $(nRow).attr('id'))
			{
				$(nRow).css("color", "red");
			}
			else
			{
				$(nRow).css("color", "green");
			}
		}
	});
	shortHandTableHeaders('dataTables-example', 20, 'td');
}

function getData(value, contentType)
{
	if(undefined == value  || value == null || value == '')
		return 'NA';
	else
	{
		var jsonobj = null;
		try {
		  jsonobj = JSON.parse(value);
		  value = JSON.stringify(jsonobj, undefined, 4);
		  contentType = 'application/json';
		} catch (e) {
		  //console.error("Parsing error:", e); 
		}
		return printResponse(value, contentType);				
	}
}

function shortHandTableHeaders(tableID, limit, wh) {

	var ths = $('#' + tableID + ' tbody tr '+wh);        
	var content;
	
	ths.each (function () {
		var $this = $(this);						
		$this.click (
		   function() {
				var id = $(this).attr('data-id');
				var hid = $(this).attr('data-hid');
				if($('#'+id).is(":visible"))
				{
					$('#'+id).hide();
					$('#'+hid).show();
				}
				else
				{
					$('#'+id).show();
					$('#'+hid).hide();
				}
		   }
		);
	});						
}

function shortHandHeaderTxt(txt, limit) {
	return txt.substring(0, limit - 2) + "..";
}

function statPie(reportType, type) {
	var sin = getPieVals(reportType, type);	
	var data = [{
		label: "Success",
		data: sin.totalTestCount - sin.failedTestCount, 
		color : 'green'
	}, {
		label: "Failed",
		data: sin.failedTestCount, 
		color : 'red'
	}];

	var plotObj = $.plot($("#flot-pie-chart"), data, {
		series: {
			pie: {
				show: true,
				label: {
					show: true,
					radius: 1.5 / 3,
					formatter: function (label, series) {
						return '<div style="font-size:8pt;text-align:center;color:white;">' + label + '<br/>'+ series.data[0][1] + '</div>';
					},
					threshold: 0.1
				}
			}
		},
		grid: {
			hoverable: true,
			clickable: true
		},
		tooltip: true,
		tooltipOpts: {
			content: "%p.0%, %s", // show percentages, rounding to 2 decimal places
			shifts: {
				x: 20,
				y: 0
			},
			defaultTheme: false
		}
	});
	$("#flot-pie-chart").bind("plotclick", function(event, pos, obj) {
		if(!obj)return;
		statLine(reportType,true,obj.series.label);
		showTable(reportType,obj.series.label);
	});
}

function statLine(reportType, isLine, type) {
	var test = getLineVals(reportType, type);	
	var sin = [];
	for (var i = 0; i < test.length; i++) {
		sin.push([test[i].sourceFileName + "\n" + test[i].testCaseName, test[i].executionTime]);
	} 

	if(isLine)
	{
		$.plot("#flot-line-chart", [ sin ], {
			series: {
				lines: {
					show: true
				},
				points: {
					show: true
				}
			},
			xaxis: {
				mode: "categories",
				tickLength: 0
			}
		});
	}
	else
	{
		$.plot("#flot-line-chart", [ sin ], {
			series: {
				bars: {
					show: true,
					barWidth: 0.005,
					align: "center"
				}
			},
			xaxis: {
				mode: "categories",
				tickLength: 0
			}
		});
	}
}

function loadStats(value)
{
	statPie(value,'All');
	statLine(value,true,'All');
	showTable(value,'All');

	var tot = 0, succ = 0, fail = 0, totTime = 0, totruns = 0;
	if(value=='All')
	{
		tot = suiteStats.totalTestCount;
		fail = suiteStats.failedTestCount;
		succ = tot - fail;		
		totTime = suiteStats.executionTime;
		totruns = suiteStats.totalRuns;
	}
	else
	{
		for(var i=0;i<suiteStats.groupStats.length;i++)
		{
			if(suiteStats.groupStats[i].sourceFile==value)
			{
				tot = suiteStats.groupStats[i].totalTestCount;
				fail = suiteStats.groupStats[i].failedTestCount;
				succ = tot - fail;		
				totTime = suiteStats.groupStats[i].executionTime;
				totruns = suiteStats.groupStats[i].totalRuns;
			}
		}
	}

	$('#stats-pre-ele').html('<li>Total Testcases : '+tot+'</li> \
		<li>Total Success : '+succ+'</li> \
		<li>Total Failed : '+fail+'</li> \
		<li>Total ExecutionTime : '+totTime+'ms</li> \
		<li>Total Runs : '+totruns+'</li>'
	   );
}

function getPieVals(reportType)
{
	if(reportType=="All")
	{
		return suiteStats;
	}
	else
	{
		var total = 0, failed = 0;
		for (var i=0;i<testcaseStats.length;i++) {
			if (testcaseStats[i].sourceFileName==reportType) {
				if(testcaseStats[i].status=='Failed')
				{
					failed++;
				}
				total++;
			}
		}
		return {"totalTestCount":total, "failedTestCount":failed};
	}
}

function getLineVals(reportType, type)
{
	var reports = [];
	if(reportType=="All")
	{
		for (var i=0;i<testcaseStats.length;i++) {
			if(type=='All' || testcaseStats[i].status==type) {
				reports.push(testcaseStats[i]);
			}
		}
	}
	else
	{
		for (var i=0;i<testcaseStats.length;i++) {
			if (testcaseStats[i].sourceFileName==reportType && (type=='All' || testcaseStats[i].status==type)) {
				reports.push(testcaseStats[i]);
			}
		}					
	}
	return reports;
}

function getTableVals(reportType, type)
{
	var reports = [];				
	if(reportType=="All")
	{
		for (var key in testcaseReports) {
			if (testcaseReports.hasOwnProperty(key)) {
				for(var i=0;i<testcaseReports[key].length;i++)
				{
					if(type=='All' || testcaseReports[key][i].status==type)
						reports.push(testcaseReports[key][i]);
				}							
			}
		}
	}
	else
	{
		for (var key in testcaseReports) {
			if (testcaseReports.hasOwnProperty(key)) {
				if(key==reportType)
				{
					for(var i=0;i<testcaseReports[key].length;i++)
					{
						if(type=='All' || testcaseReports[key][i].status==type)
							reports.push(testcaseReports[key][i]);
					}
				}
			}
		}
	}
	return reports;
}

$(document).ready(function() {
	for(var i=0;i<suiteStats.groupStats.length;i++)
	{
		$('#groupFilesSelect').append('<option value="'+suiteStats.groupStats[i].sourceFile+'">'+suiteStats.groupStats[i].sourceFile+'</option>');
	}
	loadStats('All');	
});