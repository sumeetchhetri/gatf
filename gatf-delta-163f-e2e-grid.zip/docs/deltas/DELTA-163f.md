# DELTA-163f: e2e debugger step-over timeout on CI

Session Tier 3 · Δ163f (orchestrator) · 2026-10-15

Base: the tree through Δ163e.

## Summary
`app-debugger.spec.ts › breakpoint toggle, pause, F6 step-over…` failed on CI only: F6 did not move past line 1 (`open chrome`) within 60 s.

Step-over sets a temporary breakpoint on the next line and resumes, so the step finishes only once `open chrome` has a browser. The cause:
- `fullyParallel: false` serialises tests *within* a file, but Playwright still runs files in parallel workers.
- `app-workflow-grid.spec.ts` uses the same Grid as the debugger spec.
- The CI service `selenium/standalone-chrome` has one browser slot by default, so the debugger's session waited in the Grid queue.

Fixes:
- `e2e/playwright.config.ts`: `workers: process.env.CI ? 1 : undefined`. Files run one at a time on CI; local runs are unchanged.
- `ci-build.yml` Grid service: `SE_NODE_MAX_SESSIONS: '4'` and `SE_NODE_OVERRIDE_MAX_SESSIONS: 'true'`.

## Changes
| Path | A/M | Note |
|---|---|---|
| `e2e/playwright.config.ts` | M | `workers` on CI |
| `.github/workflows/ci-build.yml` | M | Grid session slots |

## How to apply
```
unzip -oq gatf-delta-163f-e2e-grid.zip && git add -A && git commit -m "Δ163f: e2e serial on CI + 4 Grid slots" && git push
```

## Verification
- `actionlint` clean.
- `tsc` on the Playwright config clean.
- **Not run:** the e2e suite. The diagnosis comes from the log (the failure follows the other Grid user's session) and the Grid default of one slot.
- If it still fails, the server log around "Debug" for that test, plus `test-results/…/error-context.md`, will show whether `open chrome` threw.
