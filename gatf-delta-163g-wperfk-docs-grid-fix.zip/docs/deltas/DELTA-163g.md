# DELTA-163g: wperfk availability in the docs + plain browser keys on a requested Grid (CI e2e debugger fix)

Session Tier 3 · Δ163g (orchestrator) · 2026-10-15

Base: the tree through Δ163f.

## Summary
wperfk's first release publishes prebuilt binaries. This delta updates the docs to match.

The release workflow strips the tag's leading `v`, so tag **`v0.1-alpha`** gives:
- version **`0.1-alpha`** (`wperfk --version` prints `wperfk 0.1-alpha [...]`);
- files `wperfk_0.1-alpha_<os>_<arch>.tar.gz|.zip` and `wperfk_0.1-alpha_checksums.txt`.

URLs keep the tag: `…/releases/download/v0.1-alpha/<file>`.

- **`docs/load-tools.md`:**
  - the wperfk row lists per-OS prebuilt binaries;
  - a new **Installing wperfk** section covers the platforms, the asset naming and checksums file, the note that pre-releases are missing from `/releases/latest`, and verify-and-extract commands into GATF's tools cache (`~/.gatf/tools/<os-arch>/wperfk/`, found with no config) for bash and PowerShell. It also covers the macOS quarantine note.
- **`README.md`:**
  - the load-testing bullet no longer claims every tool is auto-provisioned: only vegeta and autocannon are;
  - it links the wperfk releases and the install section.

## Part 2: plain browser keys on a requested Grid (the e2e debugger failure)
**The failure.** `app-debugger.spec.ts › … F6 step-over …` failed on CI only (Δ163f's serial run and extra Grid slots did not fix it).

**The real cause.**
- `DriverInitCodegen.plainLocal` kept `open chrome|firefox|edge|ie` on a local driver whatever the Grid setting. Only the `-dkr` keys go through `getDockerDriver` → `BrowserDrivers.create`, which honours `SELENIUM_REMOTE_URL`.
- The e2e server gets `SELENIUM_REMOTE_URL` = the CI Grid, and the debug script (`trace-smoke.sel`) starts with plain `open chrome`.
- On the runner, the local Chrome can't start (no display), so the script ends during step-over and the highlight never leaves line 1.
- On a Mac the local Chrome starts, so the test passed there.
- `app-workflow-grid › runs a selenium script to a terminal state` passed too, because a failed run is also a terminal state.

**The fix.** `plainLocal` is also false when a Grid is requested: `SeleniumGrid.explicitRemoteUrl()` (`SELENIUM_REMOTE_URL` / `-Dgatf.selenium.remoteUrl`) or `SeleniumGrid.withGridRequest()` (`GATF_WITH_GRID` / `-Dgatf.withGrid`).
- These are the inputs `BrowserDrivers.create` already honours, and docs/browser-modes.md (Mode C, resolution order) already says plain runs use the Grid.
- With nothing set, the generated code and the goldens are unchanged.
- It is listed under Behaviour changes in the release notes.

**Caveat.** The decision is made at transpile time, as Δ157's GATF_CLOUD routing is. A shell that exports `SELENIUM_REMOTE_URL` while running `mvn verify` would see different driver lines (the new test assume-skips in that case; `openEdgeAndEdgeDkr…` would fail there, as it already would with GATF_CLOUD).

## Changes
| Path | A/M | Note |
|---|---|---|
| `docs/load-tools.md` | M | row + install section |
| `README.md` | M | one bullet edited |
| `alldep-jar/src/main/java/com/gatf/selenium/DriverInitCodegen.java` | M | CRLF kept. `plainLocal`: a requested Grid routes plain keys |
| `alldep-jar/src/test/java/com/gatf/selenium/CommandTest.java` | M | `aRequestedGridRoutesPlainKeysThroughGetDockerDriver` |
| `docs/release-notes/tier-3.md` | M | one behaviour-change line |

## How to apply
```
unzip -oq gatf-delta-163g-wperfk-docs.zip && git add -A && git commit -m "Δ163g: wperfk docs + plain keys on a requested Grid" && git push
```

## Verification
The dry-run assets were checked:
- the checksums file covers all 8 archives;
- each binary has the right OS and architecture;
- `wperfk --version` and a closed- and open-model run of the Linux amd64 binary against a local HTTP server succeeded.

The documented bash install (curl → sha256sum → extract into the tools cache → `--version`) ran end to end against a local server holding the dry-run archives renamed to the `0.1-alpha` names. The PowerShell commands were not run.

Part 2 checks:
- **Harness (R3):** the `plainLocal` condition and `SeleniumGrid`'s two methods were copied verbatim and compiled with javac. Results:
  - nothing set → local;
  - `-Dgatf.selenium.remoteUrl` → Grid;
  - `-Dgatf.withGrid=chrome` → Grid;
  - `withGrid=false` → local;
  - env `SELENIUM_REMOTE_URL` (the CI case) → Grid;
  - `chrome-dkr` → never local.
- **ParseCheck** 0 errors; `eol ok`.
- **Not run here:** the new CommandTest test (AssertJ, full classpath) and the e2e suite. CI's e2e job is the real check.
